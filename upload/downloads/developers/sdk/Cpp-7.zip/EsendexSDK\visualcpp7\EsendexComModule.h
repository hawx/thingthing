// EsendexComModule.h: interface for the EsendexComModule class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ESENDEXCOMMODULE_H__BE1705BE_D04C_4790_871A_BD99808FDF57__INCLUDED_)
#define AFX_ESENDEXCOMMODULE_H__BE1705BE_D04C_4790_871A_BD99808FDF57__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class EsendexComModule : public CComModule  
{
public:
	EsendexComModule();
	virtual ~EsendexComModule();

	CComBSTR m_bstrSoapEndPoint;
};

#endif // !defined(AFX_ESENDEXCOMMODULE_H__BE1705BE_D04C_4790_871A_BD99808FDF57__INCLUDED_)
