// InboxDlg.cpp : implementation file
// Esendex: Dialog box that displays the contents of an Esendex user's inbox.

#include "stdafx.h"
#include "EsendexMessenger.h"
#include "InboxDlg.h"
#include "SendDialog.h"
#include "SendFullDialog.h"
#include "LoginDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInboxDlg dialog

CInboxDlg::CInboxDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CInboxDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CInboxDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CInboxDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInboxDlg)
	DDX_Control(pDX, IDC_LIST1, m_wndList);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CInboxDlg, CDialog)
	//{{AFX_MSG_MAP(CInboxDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_BN_CLICKED(IDC_SEND, OnSend)
	ON_BN_CLICKED(IDC_REFRESH, OnRefresh)
	ON_BN_CLICKED(IDC_SEND_FULL, OnSendFull)
	ON_BN_CLICKED(IDC_ACCOUNT, OnAccount)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInboxDlg message handlers

void CInboxDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CInboxDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CInboxDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CInboxDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_wndList.SetExtendedStyle(m_wndList.GetExtendedStyle()|LVS_EX_FULLROWSELECT);

	//Esendex: Add some columns to the list view control.
	m_wndList.InsertColumn(0, "From", LVCFMT_LEFT, 100);
	m_wndList.InsertColumn(1, "Message", LVCFMT_LEFT, 300);
	m_wndList.InsertColumn(2, "Received At", LVCFMT_LEFT, 150);

	//Esendex: Initialise the Inbox COM component.
	InitialiseInboxService();

	//Esendex: Place the inbox messages into the list view control.
	PopulateList();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

//Esendex: Create and initialise the Inbox COM component.
void CInboxDlg::InitialiseInboxService()
{
	try
	{
		//Esendex: Create the Inbox COM component.
		m_spInbox.CreateInstance(__uuidof(EsendexLib::InboxService2));

		//Esendex: Pass the user's account information to the Inbox COM component.
		//The Username, Password and Account values use the LPCTSTR overload of 
		//_bstr_t to convert a character string to a wide character string. There
		//is an optional fourth parameter that is used only when running within an
		//ASP page. In this case we are able to leave it empty and use the default
		//_variant_t(VT_ERROR) to assume a default parameter value in the COM component.
		CEsendexMessengerApp* pApp = (CEsendexMessengerApp*)AfxGetApp();
		m_spInbox->Initialise((LPCTSTR)pApp->m_strUsername, (LPCTSTR)pApp->m_strPassword, (LPCTSTR)pApp->m_strAccount);
	}
	catch(_com_error& ex)
	{
		//Esendex: The COM component may throw an _com_error, which we catch here and report to the user.
		CString strMessage;
		strMessage.Format("Unable to create Esendex Inbox component\n\n%s", (TCHAR*)ex.Description());
		AfxMessageBox(strMessage, MB_OK|MB_ICONERROR);
	}
}

//Esendex: Place the inbox messages into the list view control.
void CInboxDlg::PopulateList()
{
	try
	{
		//Esendex: Delete the contents of the list view control.
		m_wndList.DeleteAllItems();

		//Esendex: Retrieve the messages list from the Inbox component.
		m_spMessages = m_spInbox->GetMessages();

		//Esendex: Populate the list view control
		for (int i=0; i<m_spMessages->Count; i++)
		{
			//Esendex: Get the message component.
			EsendexLib::ISMSMessage2Ptr spMessage = m_spMessages->GetItem(long(i+1));

			//Esendex: Add the originator, message body and received date to the 
			//list view control.
			m_wndList.InsertItem(i, spMessage->Originator);
			m_wndList.SetItemText(i, 1, spMessage->Body);
			COleDateTime date(spMessage->ReceivedAt);
			m_wndList.SetItemText(i, 2, date.Format(0, LANG_USER_DEFAULT));
		}
	}
	catch(_com_error& ex)
	{
		//Esendex: The COM component may throw an _com_error, which we catch here and report to the user.
		CString strMessage;
		strMessage.Format("There was a problem retrieving messages\n\n%s", (TCHAR*)ex.Description());
		AfxMessageBox(strMessage, MB_OK|MB_ICONERROR);
	}
}

void CInboxDlg::OnDelete() 
{
	try
	{
		//Esendex: Create a list of items to delete.
		EsendexLib::IObjectCollectionPtr spMessagesToDelete;
		spMessagesToDelete.CreateInstance(__uuidof(EsendexLib::ObjectCollection));

		//Esendex: Iterate through the items in the list view control.
		for (int i=0; i<m_wndList.GetItemCount(); i++)
		{
			//Esendex: See whether the item is selected.
			if (m_wndList.GetItemState(i, LVIS_SELECTED))
			{
				//Esendex: Get the item's message ID from the messages collection
				//and add it to the strings collection. 
				EsendexLib::ISMSMessage2Ptr spMessage = m_spMessages->GetItem(i+1);
				spMessagesToDelete->Add(spMessage);
			}
		}
		//Esendex: Delete the selected messages. 
		m_spInbox->DeleteMessages(spMessagesToDelete->IDs);

		//Esendex: Repopulate the list view control with the changes.
		PopulateList();
	}
	catch(_com_error& ex)
	{
		//Esendex: The COM component may throw an _com_error, which we catch here and report to the user.
		CString strMessage;
		strMessage.Format("There was a problem deleting messages\n\n%s", (TCHAR*)ex.Description());
		AfxMessageBox(strMessage, MB_OK|MB_ICONERROR);
	}		
}

//Esendex: Display a dialog box enable the user to send an SMS message.
void CInboxDlg::OnSend() 
{
	CSendDialog dlg;
	dlg.DoModal();
}

//Esendex: Display a dialog box enable the user to send an SMS message
//with extra details.
void CInboxDlg::OnSendFull() 
{
	CSendFullDialog dlg;
	dlg.DoModal();	
}

//Esendex: Update the list view control.
void CInboxDlg::OnRefresh() 
{
	PopulateList();	
}

//Esendex: Display a dialog box that enables the user to change their
//login details.
void CInboxDlg::OnAccount() 
{
	CLoginDialog dlg;
	if (dlg.DoModal()==IDOK)
	{
		InitialiseInboxService();
		PopulateList();
	}
}
