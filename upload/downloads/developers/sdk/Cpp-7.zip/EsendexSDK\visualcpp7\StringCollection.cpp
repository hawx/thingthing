// StringCollection.cpp : Implementation of CStringCollection
#include "stdafx.h"
#include "EsendexSDK.h"
#include "StringCollection.h"

/////////////////////////////////////////////////////////////////////////////
// CStringCollection

STDMETHODIMP CStringCollection::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IStringCollection2
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CStringCollection::get_Count(long* pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_Count"); 
	try
	{
		CHECK_INIT_PTR(pVal);

		*pVal = m_coll.size();

		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CStringCollection::get_Item(long Index, BSTR *pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_Item"); 
	try
	{
		CHECK_INIT_PTR(pVal);

		if (Index <= 0 || Index > (long)m_coll.size())
			return E_INVALIDARG;

		// Get the iterator.
		ContainerType::iterator it = m_coll.begin();
		std::advance(it, Index - 1);

		//Get the item from the iterator
		CComBSTR& cItem = *it;

		//Copy to the caller
		CHECK_HR(cItem.CopyTo(pVal));

		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CStringCollection::put_Item(long Index, BSTR newVal)
{
	ESENDEX_METHOD_PROLOGUE("put_Item"); 
	try
	{
		if (Index <= 0 || Index > (long)m_coll.size())
			return E_INVALIDARG;

		//Replace the item
		m_coll[Index] = newVal;

		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CStringCollection::Add(BSTR newVal)
{
	ESENDEX_METHOD_PROLOGUE("Add"); 
	try
	{
		m_coll.push_back(newVal);
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CStringCollection::Remove(long Index)
{
	ESENDEX_METHOD_PROLOGUE("Remove"); 
	try
	{
		if (Index <= 0 || Index > (long)m_coll.size())
			ReportError(IDS_ERR_INDEX_OUT_OF_RANGE);

		// Get the iterator and erase the item
		ContainerType::iterator it = m_coll.begin();
		std::advance(it, Index - 1);
		m_coll.erase(it);

		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP::CStringCollection::get__NewEnum(IUnknown** pVal)
{
	ESENDEX_METHOD_PROLOGUE("get__NewEnum"); 
	try
	{
		CHECK_INIT_PTR(pVal);
		CHECK_HR(QueryInterface(IID_IUnknown, (void**)pVal));
		m_iter = m_coll.begin();
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CStringCollection::Next(ULONG celt, VARIANT* rgelt, ULONG* pceltFetched)
{
	ESENDEX_METHOD_PROLOGUE("Next"); 
	try
	{
		if (rgelt == NULL || (celt != 1 && pceltFetched == NULL))
			return E_POINTER;

		ULONG nActual = 0;
		HRESULT hr = S_OK;
		VARIANT* pelt = rgelt;
		while (SUCCEEDED(hr) && m_iter != m_coll.end() && nActual < celt)
		{
			//Get the item from the iterator
			CComBSTR& cItem = *m_iter;

			//Copy to the caller
			hr = cItem.CopyTo(&pelt->bstrVal);

			if (FAILED(hr))
			{
				while (rgelt < pelt)
					VariantClear(rgelt++);
				nActual = 0;
			}
			else
			{
				pelt->vt = VT_BSTR;
				pelt++;
				m_iter++;
				nActual++;
			}
		}
		if (pceltFetched)
			*pceltFetched = nActual;
		if (SUCCEEDED(hr) && (nActual < celt))
			hr = S_FALSE;
		return hr;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CStringCollection::Skip(ULONG celt)
{
	ESENDEX_METHOD_PROLOGUE("Skip"); 
	try
	{
		HRESULT hr = S_OK;
		while (celt--)
		{
			if (m_iter != m_coll.end())
				m_iter++;
			else
			{
				hr = S_FALSE;
				break;
			}
		}
		return hr;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CStringCollection::Reset()
{
	ESENDEX_METHOD_PROLOGUE("Reset"); 
	try
	{
		m_iter = m_coll.begin();
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CStringCollection::Clone(IEnumVARIANT** pVal)
{
	return E_NOTIMPL;
}
