// Contact.h : Declaration of the CContact

#ifndef __CONTACT_H_
#define __CONTACT_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CContact
class ATL_NO_VTABLE CContact : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CContact, &CLSID_Contact>,
	public ISupportErrorInfo,
	public IDispatchImpl<IContact, &IID_IContact, &LIBID_EsendexLib, 2>,
	public IDomainObject,
	public ILocalObject
{
public:
	CContact()
	{
		m_contactType = CONTACT_TYPE_CONTACT;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CONTACT)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CContact)
	COM_INTERFACE_ENTRY(IContact)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IDomainObject)
	COM_INTERFACE_ENTRY(ILocalObject)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ILocalObject
public:
	STDMETHOD(GetLocalObject)(/*[out, retval]*/ LPUNKNOWN *pVal);
	

// IDomainObject
public:
	STDMETHOD(get_ID)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_ID)(/*[in]*/ BSTR newVal);

// IContact
public:
	STDMETHOD(get_ContactType)(/*[out, retval]*/ CONTACT_TYPE *pVal);
	STDMETHOD(put_ContactType)(/*[in]*/ CONTACT_TYPE newVal);
	STDMETHOD(get_Country)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Country)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Postcode)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Postcode)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_County)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_County)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Town)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Town)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_StreetAddress2)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_StreetAddress2)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_StreetAddress1)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_StreetAddress1)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_MobileNumber)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_MobileNumber)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_TelephoneNumber)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_TelephoneNumber)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_LastName)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_LastName)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_FirstName)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_FirstName)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_QuickName)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_QuickName)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_EmailAddress)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_EmailAddress)(/*[in]*/ BSTR newVal);

	CComBSTR m_bstrID;
	CComBSTR m_bstrQuickName;
	CComBSTR m_bstrFirstName;
	CComBSTR m_bstrLastName;
	CComBSTR m_bstrTelephoneNumber;
	CComBSTR m_bstrMobileNumber;
	CComBSTR m_bstrStreetAddress1;
	CComBSTR m_bstrStreetAddress2;
	CComBSTR m_bstrTown;
	CComBSTR m_bstrCounty;
	CComBSTR m_bstrCountry;
	CComBSTR m_bstrPostcode;
	CComBSTR m_bstrEmailAddress;
	CONTACT_TYPE m_contactType;
};

#endif //__CONTACT_H_
