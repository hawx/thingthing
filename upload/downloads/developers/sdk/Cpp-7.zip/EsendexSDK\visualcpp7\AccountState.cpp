// AccountState.cpp : Implementation of CAccountState
#include "stdafx.h"
#include "Esendex.h"
#include "AccountState.h"

/////////////////////////////////////////////////////////////////////////////
// CAccountState

STDMETHODIMP CAccountState::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IAccountState
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CAccountState::get_ID(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrID.CopyTo(pVal);
}

STDMETHODIMP CAccountState::put_ID(BSTR newVal)
{
	m_bstrID = newVal;
	return S_OK;
}

STDMETHODIMP CAccountState::get_Reference(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrReference.CopyTo(pVal);
}

STDMETHODIMP CAccountState::put_Reference(BSTR newVal)
{
	m_bstrReference = newVal;
	return S_OK;
}

STDMETHODIMP CAccountState::get_Address(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrAddress.CopyTo(pVal);
}

STDMETHODIMP CAccountState::put_Address(BSTR newVal)
{
	m_bstrAddress = newVal;
	return S_OK;
}

STDMETHODIMP CAccountState::get_ServiceAlias(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrServiceAlias.CopyTo(pVal);
}

STDMETHODIMP CAccountState::put_ServiceAlias(BSTR newVal)
{
	m_bstrServiceAlias = newVal;
	return S_OK;
}

STDMETHODIMP CAccountState::get_MessageLimit(long *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	*pVal = m_iMessageLimit;
	return S_OK;
}

STDMETHODIMP CAccountState::put_MessageLimit(long newVal)
{
	m_iMessageLimit = newVal;
	return S_OK;
}

STDMETHODIMP CAccountState::get_Features(long *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	*pVal = m_iFeatures;
	return S_OK;
}

STDMETHODIMP CAccountState::put_Features(long newVal)
{
	m_iFeatures = newVal;
	return S_OK;
}
