// AccountState.h : Declaration of the CAccountState

#ifndef __ACCOUNTSTATE_H_
#define __ACCOUNTSTATE_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CAccountState
class ATL_NO_VTABLE CAccountState : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CAccountState, &CLSID_AccountState>,
	public ISupportErrorInfo,
	public IDispatchImpl<IAccountState, &IID_IAccountState, &LIBID_EsendexLib, 2>
{
public:
	CAccountState()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_ACCOUNTSTATE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CAccountState)
	COM_INTERFACE_ENTRY(IAccountState)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IAccountState
public:
	STDMETHOD(get_Features)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_Features)(/*[in]*/ long newVal);
	STDMETHOD(get_MessageLimit)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_MessageLimit)(/*[in]*/ long newVal);
	STDMETHOD(get_ServiceAlias)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_ServiceAlias)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Address)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Address)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Reference)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Reference)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_ID)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_ID)(/*[in]*/ BSTR newVal);

	CComBSTR m_bstrID;
	CComBSTR m_bstrAddress;
	CComBSTR m_bstrReference;
	CComBSTR m_bstrServiceAlias;
	long m_iFeatures;
	long m_iMessageLimit;
};

#endif //__ACCOUNTSTATE_H_
