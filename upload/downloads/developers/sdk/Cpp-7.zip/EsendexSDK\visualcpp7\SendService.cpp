// SendService.cpp : Implementation of CSendService
#include "stdafx.h"
#include "EsendexSDK.h"
#include "SendService.h"
#include "XMLUtils.h"
#include "Utils.h"


/////////////////////////////////////////////////////////////////////////////
// CSendService

STDMETHODIMP CSendService::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISendService2
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CSendService::Initialise(BSTR UserName, BSTR Password, BSTR Account, VARIANT IsServerSide)
{
	return CSOAPService::Initialise(UserName, Password, Account, IsServerSide);
}


STDMETHODIMP CSendService::SendMessageFull(BSTR Originator, BSTR Recipient, BSTR Body, MESSAGE_TYPE Type, long ValidityPeriod, BSTR *pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("SendMessageFull"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_STRING_PARAM("Originator", Originator);
		CHECK_STRING_PARAM("Recipient", Recipient);
		CHECK_STRING_PARAM("Body", Body);
		
		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_SEND_MESSAGE_FULL)));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementValue(spDoc, L"originator", Originator);
		CXmlUtils::SetElementValue(spDoc, L"recipient", Recipient);
		CXmlUtils::SetElementValue(spDoc, L"body", Body);
		CXmlUtils::SetElementValue(spDoc, L"validityperiod", ValidityPeriod);
		SetMessageType(spDoc, Type);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result.
		_bstr_t bstrResult = CXmlUtils::GetElementValue(spDoc, L"SendMessageFullResult");

		//Return the result to the caller.
		*pVal = bstrResult.copy();
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CSendService::SendMessage(BSTR Recipient, BSTR Body, MESSAGE_TYPE Type, BSTR *pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("SendMessage"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_STRING_PARAM("Recipient", Recipient);
		CHECK_STRING_PARAM("Body", Body);
		
		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_SEND_MESSAGE)));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementValue(spDoc, L"recipient", Recipient);
		CXmlUtils::SetElementValue(spDoc, L"body", Body);
		SetMessageType(spDoc, Type);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result.
		_bstr_t bstrResult = CXmlUtils::GetElementValue(spDoc, L"SendMessageResult");

		//Return the result to the caller.
		*pVal = bstrResult.copy();
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

HRESULT CSendService::SetMessageType(MSXML::IXMLDOMDocumentPtr spDoc, MESSAGE_TYPE Type)
{
		switch(Type)
		{
		case MESSAGE_TYPE_TEXT:
			CXmlUtils::SetElementValue(spDoc, L"type", L"Text");
			break;
		case MESSAGE_TYPE_SMARTMESSAGE:
			CXmlUtils::SetElementValue(spDoc, L"type", L"SmartMessage");
			break;
		case MESSAGE_TYPE_BINARY:
			CXmlUtils::SetElementValue(spDoc, L"type", L"Binary");
			break;
		case MESSAGE_TYPE_UNICODE:
			CXmlUtils::SetElementValue(spDoc, L"type", L"Unicode");
			break;
		default:
			return E_INVALIDARG;
		}
		return S_OK;
}

STDMETHODIMP CSendService::GetMessageStatus(BSTR MessageID, MESSAGE_STATUS *pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetMessageStatus"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_PARAM("MessageID", MessageID);

		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR((long*)pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_MESSAGE_STATUS)));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementValue(spDoc, L"id", MessageID);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result.
		_bstr_t bstrResult = CXmlUtils::GetElementValue(spDoc, L"GetMessageStatusResult");

		//Return the result to the caller.
		*pVal = StringToMessageStatus(bstrResult);
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CSendService::SendMessageMultipleRecipients(BSTR Recipients, BSTR Body, MESSAGE_TYPE Type, IStringCollection2* *pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("SendMessageMultipleRecipients"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_PARAM("Recipients", Recipients);

		CHECK_STRING_PARAM("Body", Body);
		
		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_SEND_MESSAGE_MULTIPLE_RECIPIENTS)));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementArrayValue(spDoc, L"recipients", Recipients);
		CXmlUtils::SetElementValue(spDoc, L"body", Body);
		SetMessageType(spDoc, Type);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result.
		CXmlUtils::GetElementArrayValue(spDoc, L"SendMessageMultipleRecipientsResult", pVal);
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CSendService::SendMessageMultipleRecipientsFull(BSTR Originator, BSTR Recipients, BSTR Body, MESSAGE_TYPE Type, long ValidityPeriod, IStringCollection2* *pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("SendMessageMultipleRecipientsFull"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_STRING_PARAM("Originator", Originator);
		CHECK_PARAM("Recipients", Recipients);
		CHECK_STRING_PARAM("Body", Body);
		
		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_SEND_MESSAGE_MULTIPLE_RECIPIENTS_FULL)));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementValue(spDoc, L"originator", Originator);
		CXmlUtils::SetElementArrayValue(spDoc, L"recipients", Recipients);
		CXmlUtils::SetElementValue(spDoc, L"body", Body);
		CXmlUtils::SetElementValue(spDoc, L"validityperiod", ValidityPeriod);
		SetMessageType(spDoc, Type);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result.
		CXmlUtils::GetElementArrayValue(spDoc, L"SendMessageMultipleRecipientsFullResult", pVal);
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CSendService::Dummy(ERROR_CODE x)
{
	return E_NOTIMPL;
}
