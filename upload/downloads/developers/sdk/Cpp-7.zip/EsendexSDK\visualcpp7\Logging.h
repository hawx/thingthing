#pragma once

#define DECLARE_CLASS \
	const TCHAR* m_pszClassName;

#define DECLARE_STATIC_CLASS \
	static const TCHAR* m_pszClassName;

#define INIT_CLASS(ClassName) \
	m_pszClassName = ClassName

#define INIT_STATIC_CLASS(Class, ClassName) \
	const TCHAR* Class::m_pszClassName = ClassName

#define GET_LOGGER(category) log4cpp::Category& log = log4cpp::Category::getInstance(std::string(m_pszClassName))

#define ESENDEX_METHOD_PROLOGUE(MethodName) \
	const TCHAR* pszMethodName = MethodName; \
	GET_LOGGER(m_pszClassName); \
	log.debug("Entering %s::%s", m_pszClassName, pszMethodName);

#define ESENDEX_METHOD_PROLOGUE_1(MethodName) \
	const TCHAR* pszMethodName = MethodName; \
	GET_LOGGER(m_pszClassName); \
	log.debug("Entering %s::%s", m_pszClassName, pszMethodName);