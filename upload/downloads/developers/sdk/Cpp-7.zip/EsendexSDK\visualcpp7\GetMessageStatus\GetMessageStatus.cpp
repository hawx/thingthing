// SendMessage.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <objbase.h>
#include <iostream>

#import "..\bin\EsendexSDK2.dll"

//Forward declarations for error reporting functions.
static int ReportError(const char* pszMessage, HRESULT hr);
static int ReportError(const char* pszMessage);

//Helper class to make sure CoUnitialize gets called even
//if an exception occurs.
class CCom
{
public:
	CCom() { }
	HRESULT Initialize() { return ::CoInitialize(NULL); }
	~CCom() { ::CoUninitialize(); }
};

int main(int argc, char* argv[])
{
	HRESULT hr;
	
	//Intialize COM
	CCom com;
	hr = com.Initialize();
	if (FAILED(hr))
		ReportError("Failed to initialize COM subsystem", hr);

	//Instantiate the Esendex Service.
	EsendexLib::ISendService2Ptr spSendService;
	hr = spSendService.CreateInstance(__uuidof(EsendexLib::SendService2));
	if (FAILED(hr))
		return ReportError("Failed to create SendService object", hr);

	try
	{
		//Pass credentials to the service.
		spSendService->Initialise("", "", "", false);

		//Get message status.
		EsendexLib::MESSAGE_STATUS status = spSendService->GetMessageStatus(L"");

		const char* pszStatusName;
		switch(status)
		{
		case EsendexLib::MESSAGE_STATUS_SENT: 
			pszStatusName = "sent";
			break;
		case EsendexLib::MESSAGE_STATUS_QUEUED: 
			pszStatusName = "queued";
			break;
		case EsendexLib::MESSAGE_STATUS_FAILED: 
			pszStatusName = "failed";
			break;
		case EsendexLib::MESSAGE_STATUS_DELIVERED: 
			pszStatusName = "delivered";
			break;
		}

		std::cout << "Message status is: " << pszStatusName << std::endl;
	}
	catch(_com_error& ex)
	{
		ReportError(ex.Description());
	}

	//COM will get unitialized by the CCom clas destructor.

	return 0;
}

static int ReportError(const char* pszMessage, HRESULT hr)
{
	std::cout << "Error: " << pszMessage << " Code: " << hr << std::endl;
	return 0;
}

static int ReportError(const char* pszMessage)
{
	std::cout << "Error: " << pszMessage << std::endl;
	return 0;
}

