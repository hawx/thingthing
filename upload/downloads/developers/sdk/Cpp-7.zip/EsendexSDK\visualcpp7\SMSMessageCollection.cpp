// SMSMessages.cpp : Implementation of CSMSMessageCollection
#include "stdafx.h"
#include "Esendex.h"
#include "SMSMessageCollection.h"

/////////////////////////////////////////////////////////////////////////////
// CSMSMessageCollection

STDMETHODIMP CSMSMessageCollection::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISMSMessageCollection
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CSMSMessageCollection::get_Count(long* pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_Count"); 
	try
	{
		CHECK_INIT_PTR(pVal);

		*pVal = m_coll.size();

		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessageCollection::get_Item(VARIANT Index, ISMSMessage* *pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_Item"); 
	try
	{
		CHECK_VARIANT_LONG_PARAM("Index", Index);
		CHECK_INIT_PTR(pVal);

		if (Index.lVal <= 0 || Index.lVal > (long)m_coll.size())
			return E_INVALIDARG;

		// Get the iterator.
		ContainerType::iterator it = m_coll.begin();
		std::advance(it, Index.lVal - 1);

		//Get the item from the iterator
		ItemType& cItem = *it;

		//Copy to the caller
		CHECK_HR(cItem.CopyTo(pVal));

		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessageCollection::put_Item(VARIANT Index, ISMSMessage* newVal)
{
	ESENDEX_METHOD_PROLOGUE("put_Item"); 
	try
	{
		CHECK_VARIANT_LONG_PARAM("Index", Index);
		
		if (Index.lVal <= 0 || Index.lVal > (long)m_coll.size())
			return E_INVALIDARG;

		//Replace the item
		m_coll[Index.lVal] = newVal;

		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessageCollection::Add(ISMSMessage* newVal)
{
	ESENDEX_METHOD_PROLOGUE("Add"); 
	try
	{
		m_coll.push_back(newVal);
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessageCollection::Remove(VARIANT Index)
{
	ESENDEX_METHOD_PROLOGUE("Remove"); 
	try
	{
		CHECK_VARIANT_LONG_PARAM("Index", Index);

		if (Index.lVal <= 0 || Index.lVal > (long)m_coll.size())
			ReportError(IDS_ERR_INDEX_OUT_OF_RANGE);

		// Get the iterator and erase the item
		ContainerType::iterator it = m_coll.begin();
		std::advance(it, Index.lVal - 1);
		m_coll.erase(it);

		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP::CSMSMessageCollection::get__NewEnum(IUnknown** pVal)
{
	ESENDEX_METHOD_PROLOGUE("get__NewEnum"); 
	try
	{
		CHECK_INIT_PTR(pVal);
		CHECK_HR(QueryInterface(IID_IUnknown, (void**)pVal));
		m_iter = m_coll.begin();
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessageCollection::Next(ULONG celt, VARIANT* rgelt, ULONG* pceltFetched)
{
	ESENDEX_METHOD_PROLOGUE("Next"); 
	try
	{
		if (rgelt == NULL || (celt != 1 && pceltFetched == NULL))
			return E_POINTER;

		ULONG nActual = 0;
		HRESULT hr = S_OK;
		VARIANT* pelt = rgelt;
		while (SUCCEEDED(hr) && m_iter != m_coll.end() && nActual < celt)
		{
			//Get the item from the iterator
			ItemType& cItem = *m_iter;

			//Copy to the caller
			hr = cItem.CopyTo( (ISMSMessage**)&pelt->pdispVal );

			if (FAILED(hr))
			{
				while (rgelt < pelt)
					VariantClear(rgelt++);
				nActual = 0;
			}
			else
			{
				pelt->vt = VT_DISPATCH;
				pelt++;
				m_iter++;
				nActual++;
			}
		}
		if (pceltFetched)
			*pceltFetched = nActual;
		if (SUCCEEDED(hr) && (nActual < celt))
			hr = S_FALSE;
		return hr;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessageCollection::Skip(ULONG celt)
{
	ESENDEX_METHOD_PROLOGUE("Skip"); 
	try
	{
		HRESULT hr = S_OK;
		while (celt--)
		{
			if (m_iter != m_coll.end())
				m_iter++;
			else
			{
				hr = S_FALSE;
				break;
			}
		}
		return hr;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessageCollection::Reset()
{
	ESENDEX_METHOD_PROLOGUE("Reset"); 
	try
	{
		m_iter = m_coll.begin();
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessageCollection::Clone(IEnumVARIANT** pVal)
{
	return E_NOTIMPL;
}
