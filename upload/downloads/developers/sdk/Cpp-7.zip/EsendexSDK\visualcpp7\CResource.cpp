//CResource.cpp

#include "stdafx.h"
#include "CResource.h"
#include "Esendex.h"
#include "resource.h"

CResource::CResource() 
{	
	INIT_CLASS("CSendService");
	m_hrsrc = NULL;
	m_pResource = NULL;
}

HRESULT CResource::Load(LPCTSTR pszResource, LPCTSTR pszType)
{
	ESENDEX_METHOD_PROLOGUE("Load");
	try
	{
		//Get the resource file.
		m_hrsrc = FindResource(_Module.GetResourceInstance(), pszResource, pszType);
		if (!m_hrsrc)
			ReportError(IDS_ERR_LOAD_XML); 
		HGLOBAL hg = LoadResource(_Module.GetResourceInstance(), m_hrsrc);
		if (!hg)
			ReportError(IDS_ERR_LOAD_XML); 
		m_pResource = LockResource(hg);
		if (!m_pResource)
			ReportError(IDS_ERR_LOAD_XML); 
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

HRESULT CResource::Load(UINT nResource, LPCTSTR pszType)
{
	return Load(MAKEINTRESOURCE(nResource), pszType);
}

HRESULT CResource::GetString(std::string& str)
{
	if (!m_hrsrc)
		return E_FAIL;
	str.assign((LPCTSTR)m_pResource, SizeofResource(_Module.GetResourceInstance(), m_hrsrc));
	return S_OK;
}

HRESULT CResource::GetBSTR(_bstr_t& buffer)
{
	if (!m_hrsrc)
		return E_FAIL;
	DWORD dwLen = SizeofResource(_Module.GetResourceInstance(), m_hrsrc);
	buffer = A2WBSTR((LPCTSTR)m_pResource, dwLen);
	return S_OK;
}

HRESULT CResource::Extract(LPCTSTR pszFileName)
{
	if (!m_hrsrc)
		return E_FAIL;
	DWORD dwLen = SizeofResource(_Module.GetResourceInstance(), m_hrsrc);

	HANDLE hFile = CreateFile(pszFileName, GENERIC_WRITE, 0, 0, CREATE_NEW, 0, 0);
	if (!hFile)
		return HRESULT_FROM_WIN32(GetLastError());

	DWORD dwBytesWritten;
	if (!WriteFile(hFile, m_pResource, dwLen, &dwBytesWritten, NULL))
		return HRESULT_FROM_WIN32(GetLastError());

	CloseHandle(hFile);

	return S_OK;
}


