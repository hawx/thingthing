// TestService.h : Declaration of the CTestService

#ifndef __TESTSERVICE_H_
#define __TESTSERVICE_H_

#include "resource.h"       // main symbols
#include "SOAPService.h"

/////////////////////////////////////////////////////////////////////////////
// CTestService
class ATL_NO_VTABLE CTestService : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CTestService, &CLSID_TestService>,
	public ISupportErrorInfo,
	public IDispatchImpl<ITestService, &IID_ITestService, &LIBID_EsendexLib, 2>,
	public CSOAPService
{
public:
	CTestService() : CSOAPService(L"TestService", true)
	{
		INIT_CLASS("CTestService");
	}

DECLARE_REGISTRY_RESOURCEID(IDR_TESTSERVICE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CTestService)
	COM_INTERFACE_ENTRY(ITestService)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ITestService
	STDMETHOD(SetupContactTests)();

public:
	STDMETHOD(SetupSignupTests)();
	STDMETHOD(SetupInboxTests)();
	STDMETHOD(SetupSendTests)();
	STDMETHOD(SetupAccountTests)();
	STDMETHOD(SetSoapEndPoints)(BSTR URI, BSTR MockURI);

	DECLARE_CLASS;

protected:
	HRESULT SetupTests(LPCTSTR pszMethodName);

};

#endif //__TESTSERVICE_H_
