// AccountService.h : Declaration of the CAccountService

#ifndef __ACCOUNTSERVICE_H_
#define __ACCOUNTSERVICE_H_

#include "resource.h"       // main symbols
#include "SOAPService.h"

/////////////////////////////////////////////////////////////////////////////
// CAccountService
class ATL_NO_VTABLE CAccountService : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CAccountService, &CLSID_AccountService>,
	public ISupportErrorInfo,
	public IDispatchImpl<IAccountService, &IID_IAccountService, &LIBID_EsendexLib, 2>,
	public CSOAPService
{
public:
	CAccountService() : CSOAPService(L"AccountService")
	{
		INIT_CLASS("CAccountService");
	}

DECLARE_REGISTRY_RESOURCEID(IDR_ACCOUNTSERVICE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CAccountService)
	COM_INTERFACE_ENTRY(IAccountService)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IAccountService
public:
	STDMETHOD(GetAccountState)(/*[out, retval]*/ IAccountState** pVal);
	STDMETHOD(Dummy)(ACCOUNT_FEATURES x);
	STDMETHOD(GetAccountFeatures)(/*[out, retval]*/ long* pVal);
	STDMETHOD(GetMessageLimit)(long* pVal);
	STDMETHOD(Initialise)(BSTR Username, BSTR Password, BSTR Account, VARIANT IsServerSide);

	HRESULT GetAccountStateFromNode(MSXML::IXMLDOMNodePtr spXmlElement, IAccountState** pVal);
	long ParseAccountFeatures(BSTR pwszFeatures);

	DECLARE_CLASS;

};

#endif //__ACCOUNTSERVICE_H_
