// SignupCompletionElements.h : Declaration of the CSignupCompletionElements

#ifndef __SIGNUPCOMPLETIONELEMENTS_H_
#define __SIGNUPCOMPLETIONELEMENTS_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSignupCompletionElements
class ATL_NO_VTABLE CSignupCompletionElements : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSignupCompletionElements, &CLSID_SignupCompletionElements>,
	public ISupportErrorInfo,
	public IDispatchImpl<ISignupCompletionElements, &IID_ISignupCompletionElements, &LIBID_EsendexLib, 2>
{
public:
	CSignupCompletionElements()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SIGNUPCOMPLETIONELEMENTS)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSignupCompletionElements)
	COM_INTERFACE_ENTRY(ISignupCompletionElements)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ISignupCompletionElements
public:
	STDMETHOD(get_WelcomeMessage)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_WelcomeMessage)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_AccountReference)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_AccountReference)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Username)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Username)(/*[in]*/ BSTR newVal);

	CComBSTR m_bstrUsername;
	CComBSTR m_bstrAccountReference;
	CComBSTR m_bstrWelcomeMessage;
};

#endif //__SIGNUPCOMPLETIONELEMENTS_H_
