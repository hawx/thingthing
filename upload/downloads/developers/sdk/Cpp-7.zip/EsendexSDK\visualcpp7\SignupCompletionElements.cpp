// SignupCompletionElements.cpp : Implementation of CSignupCompletionElements
#include "stdafx.h"
#include "Esendex.h"
#include "SignupCompletionElements.h"

/////////////////////////////////////////////////////////////////////////////
// CSignupCompletionElements

STDMETHODIMP CSignupCompletionElements::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISignupCompletionElements
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CSignupCompletionElements::get_Username(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrUsername.CopyTo(pVal);
}

STDMETHODIMP CSignupCompletionElements::put_Username(BSTR newVal)
{
	m_bstrUsername = newVal;
	return S_OK;
}

STDMETHODIMP CSignupCompletionElements::get_AccountReference(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrAccountReference.CopyTo(pVal);
}

STDMETHODIMP CSignupCompletionElements::put_AccountReference(BSTR newVal)
{
	m_bstrAccountReference = newVal;
	return S_OK;
}

STDMETHODIMP CSignupCompletionElements::get_WelcomeMessage(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrWelcomeMessage.CopyTo(pVal);
}

STDMETHODIMP CSignupCompletionElements::put_WelcomeMessage(BSTR newVal)
{
	m_bstrWelcomeMessage = newVal;
	return S_OK;
}
