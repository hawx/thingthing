//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by EsendexSDK.rc
//
#define IDS_PROJNAME                    100
#define IDR_SENDSERVICE                 101
#define IDR_STRINGCOLLECTION            102
#define IDR_INBOXSERVICE                103
#define IDR_ACCOUNTSERVICE              104
#define IDR_SMSMESSAGE                  106
#define IDR_SMSMESSAGECOLLECTION        107
#define IDR_CONTACTSERVICE              108
#define IDR_SIGNUPSERVICE               109
#define IDR_OBJECTCOLLECTION            110
#define IDR_CONTACT                     111
#define IDR_CONTACTGROUP                112
#define IDR_TESTSERVICE                 113
#define IDR_SIGNUPCOMPLETIONELEMENTS    114
#define IDR_ACCOUNTSTATE                115
#define IDR_MESSENGERSERVICE            116
#define IDR_SEND_MESSAGE_FULL           202
#define IDR_SEND_MESSAGE                203
#define IDR_GET_MESSAGE_STATUS          204
#define IDR_SEND_MESSAGE_MULTIPLE_RECIPIENTS 205
#define IDR_SEND_MESSAGE_MULTIPLE_RECIPIENTS_FULL 206
#define IDR_SEND_MESSAGE_BATCH          207
#define IDR_GET_MESSAGES                209
#define IDR_GET_DELETE_MESSAGE          210
#define IDR_DELETE_MESSAGE              210
#define IDR_GET_DELETE_MESSAGES         211
#define IDR_DELETE_MESSAGES             211
#define IDR_GET_MESSAGE_LIMIT           212
#define IDR_GET_MESSAGES_BY_ID          215
#define IDR_GET_MESSAGES_FOR_DATE_RANGE 216
#define IDR_GET_MESSAGES_FOR_DAY        217
#define IDR_XML1                        218
#define IDR_GET_MESSAGE_BY_ID           218
#define IDR_UPDATE_GROUP                219
#define IDR_ADD_CONTACT                 220
#define IDR_ADD_CONTACTS                221
#define IDR_ADD_GROUP                   222
#define IDR_DELETE_CONTACT              223
#define IDR_DELETE_CONTACTS             224
#define IDR_DELETE_GROUP                225
#define IDR_DELETE_GROUPS               226
#define IDR_GET_CONTACT                 227
#define IDR_GET_CONTACTS                228
#define IDR_GET_GROUP                   229
#define IDR_GET_GROUP_MEMBERS           230
#define IDR_GET_GROUPS                  231
#define IDR_UPDATE_CONTACT              232
#define IDR_SETUP_TESTS                 233
#define IDR_DEFAULT_EVALUATION_SIGNUP   234
#define IDR_GET_ACCOUNT_FEATURES        236
#define IDR_GET_LATEST_MESSAGES         237
#define IDR_GET_ACCOUNT_STATE           238
#define IDR_GET_CURRENT_VERSION         239
#define IDR_GET_CONTACT_BY_NAME         240
#define IDR_GET_GROUP_BY_NAME           241
#define IDS_ERR_LOAD_XML                5000
#define IDS_ERR_TEXT_NODE_NOT_FOUND     5001
#define IDS_ERR_CREATE_SERVER_XML_HTTP  5002
#define IDS_ERR_MUST_INITIALISE         5003
#define IDS_ERR_EMPTY_PARAM             5004
#define IDS_ERR_DOM_FROM_XML            5005
#define IDS_ERR_VARIANT_NOT_STRING      5006
#define IDS_ERR_VARIANT_NOT_INT         5007
#define IDS_ERR_VARIANT_NOT_STRING_COLLECTION 5008
#define IDS_ERR_PARSE_DATE              5009
#define IDS_ERR_VARIANT_NOT_MESSAGES_COLLECTION 5010
#define IDS_ERR_VARIANT_NOT_MESSAGE     5011
#define IDS_ERR_PARSE_XML_RESPONSE      5012
#define IDS_ERR_HTTP_STATUS             5013
#define IDS_ERR_INDEX_OUT_OF_RANGE      5014
#define IDS_ERR_VARIANT_NOT_CONTACT     5015
#define IDS_ERR_VARIANT_NOT_GROUP       5016
#define IDS_ERR_ELEMENT_NOT_FOUND       5017
#define IDS_ERR_OBJECT_NOT_LOCAL        5018
#define IDS_ERR_NOT_DOMAINOBJECT        5019
#define IDS_ERR_MSXML                   5020
#define IDS_ERR_MSXML2                  5021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        242
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           117
#endif
#endif
