// ObjectCollection.h : Declaration of the CObjectCollection

#ifndef __OBJECTCOLLECTION_H_
#define __OBJECTCOLLECTION_H_

#include "resource.h"       // main symbols
#include <vector>

/////////////////////////////////////////////////////////////////////////////
// CObjectCollection
class ATL_NO_VTABLE CObjectCollection : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CObjectCollection, &CLSID_ObjectCollection>,
	public ISupportErrorInfo,
	public IDispatchImpl<IObjectCollection, &IID_IObjectCollection, &LIBID_EsendexLib, 2>,
	public IEnumVARIANT
{
public:
	CObjectCollection()
	{
		INIT_CLASS("CObjectCollection");
	}

DECLARE_REGISTRY_RESOURCEID(IDR_OBJECTCOLLECTION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CObjectCollection)
	COM_INTERFACE_ENTRY(IObjectCollection)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IEnumVARIANT)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IObjectCollection
public:
	STDMETHOD(get__NewEnum)(IUnknown** pVal);
	STDMETHOD(get_Item)(long Index, /*[out, retval]*/ IDispatch* *pVal);
	STDMETHOD(put_Item)(long Index, /*[in]*/ IDispatch* newVal);
	STDMETHOD(Add)(IDispatch* newVal);
	STDMETHOD(Remove)(long Index);
	STDMETHOD(get_Count)(long* pVal);
	STDMETHOD(get_IDs)(BSTR* pVal);

//IEnumVARIANT
	STDMETHOD(Next)(ULONG celt, VARIANT*, ULONG* pceltFetched);
	STDMETHOD(Skip)(ULONG celt);
	STDMETHOD(Reset)(void);
	STDMETHOD(Clone)(IEnumVARIANT** pVal);

	DECLARE_CLASS;

	typedef CComPtr<IDispatch> ItemType;
	typedef std::vector< ItemType >	ContainerType;
	ContainerType m_coll;
	ContainerType::iterator m_iter;
};

#endif //__OBJECTCOLLECTION_H_
