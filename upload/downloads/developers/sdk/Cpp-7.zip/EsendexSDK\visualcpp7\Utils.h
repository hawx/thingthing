// Utils.h: interface for the CUtils class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include "EsendexSDK.h"

MESSAGE_TYPE StringToMessageType(LPCWSTR pwszType);
MESSAGE_STATUS StringToMessageStatus(LPCWSTR pwszStatus);
CONTACT_GROUP_TYPE StringToGroupType(LPCWSTR pwszType);
CONTACT_TYPE StringToContactType(LPCWSTR pwszType);
_bstr_t GroupTypeToString(CONTACT_GROUP_TYPE type);
_bstr_t ContactTypeToString(CONTACT_TYPE type);


class CHGlobal
{
public:
	CHGlobal(UINT uFlags, SIZE_T dwBytes)
	{
		m_hg = GlobalAlloc(uFlags, dwBytes);
		m_bLocked = false;
	}

	~CHGlobal()
	{
		if (m_bLocked)
			Unlock();
		if (m_hg)
			GlobalFree(m_hg);
	}

	void* Lock()
	{
		m_bLocked = true;
		return GlobalLock(m_hg);
	}

	void Unlock()
	{
		GlobalUnlock(m_hg);
		m_bLocked = false;
	}

	void CreateStream(IStream** pVal)
	{
		CreateStreamOnHGlobal(m_hg, TRUE, pVal);
	}

private:
	HGLOBAL m_hg;
	bool m_bLocked;
};


long GetLongFromVariant(VARIANT var);
