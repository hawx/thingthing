// Contact.cpp : Implementation of CContact
#include "stdafx.h"
#include "EsendexSDK.h"
#include "Contact.h"

/////////////////////////////////////////////////////////////////////////////
// CContact

STDMETHODIMP CContact::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IContact
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CContact::GetLocalObject(IUnknown**pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	*pVal = (LPUNKNOWN)(void*)this;
	return S_OK;
}

STDMETHODIMP CContact::get_QuickName(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrQuickName.CopyTo(pVal);
}

STDMETHODIMP CContact::put_QuickName(BSTR newVal)
{
	m_bstrQuickName = newVal;
	return S_OK;
}

STDMETHODIMP CContact::get_FirstName(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrFirstName.CopyTo(pVal);
}

STDMETHODIMP CContact::put_FirstName(BSTR newVal)
{
	m_bstrFirstName = newVal;
	return S_OK;
}

STDMETHODIMP CContact::get_LastName(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrLastName.CopyTo(pVal);
}

STDMETHODIMP CContact::put_LastName(BSTR newVal)
{
	m_bstrLastName = newVal;
	return S_OK;
}

STDMETHODIMP CContact::get_TelephoneNumber(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrTelephoneNumber.CopyTo(pVal);
}

STDMETHODIMP CContact::put_TelephoneNumber(BSTR newVal)
{
	m_bstrTelephoneNumber = newVal;
	return S_OK;
}

STDMETHODIMP CContact::get_MobileNumber(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrMobileNumber.CopyTo(pVal);
}

STDMETHODIMP CContact::put_MobileNumber(BSTR newVal)
{
	m_bstrMobileNumber = newVal;
	return S_OK;
}

STDMETHODIMP CContact::get_StreetAddress1(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrStreetAddress1.CopyTo(pVal);
}

STDMETHODIMP CContact::put_StreetAddress1(BSTR newVal)
{
	m_bstrStreetAddress1 = newVal;
	return S_OK;
}

STDMETHODIMP CContact::get_StreetAddress2(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrStreetAddress2.CopyTo(pVal);
}

STDMETHODIMP CContact::put_StreetAddress2(BSTR newVal)
{
	m_bstrStreetAddress2 = newVal;
	return S_OK;
}

STDMETHODIMP CContact::get_Town(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrTown.CopyTo(pVal);
}

STDMETHODIMP CContact::put_Town(BSTR newVal)
{
	m_bstrTown = newVal;
	return S_OK;
}

STDMETHODIMP CContact::get_County(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrCounty.CopyTo(pVal);
}

STDMETHODIMP CContact::put_County(BSTR newVal)
{
	m_bstrCounty = newVal;
	return S_OK;
}

STDMETHODIMP CContact::get_Postcode(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrPostcode.CopyTo(pVal);
}

STDMETHODIMP CContact::put_Postcode(BSTR newVal)
{
	m_bstrPostcode = newVal;
	return S_OK;
}

STDMETHODIMP CContact::get_Country(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrCountry.CopyTo(pVal);
}

STDMETHODIMP CContact::put_Country(BSTR newVal)
{
	m_bstrCountry = newVal;
	return S_OK;
}

STDMETHODIMP CContact::get_ID(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrID.CopyTo(pVal);
}

STDMETHODIMP CContact::put_ID(BSTR newVal)
{
	m_bstrID = newVal;
	return S_OK;
}

STDMETHODIMP CContact::get_EmailAddress(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrEmailAddress.CopyTo(pVal);
}

STDMETHODIMP CContact::put_EmailAddress(BSTR newVal)
{
	m_bstrEmailAddress = newVal;
	return S_OK;
}

STDMETHODIMP CContact::get_ContactType(CONTACT_TYPE *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	*pVal = m_contactType;
	return S_OK;
}

STDMETHODIMP CContact::put_ContactType(CONTACT_TYPE newVal)
{
	m_contactType = newVal;
	return S_OK;
}
