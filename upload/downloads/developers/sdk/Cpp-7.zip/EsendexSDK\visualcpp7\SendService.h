// SendService.h : Declaration of the CSendService

#ifndef __SENDSERVICE_H_
#define __SENDSERVICE_H_

#include "resource.h"       // main symbols
#include "SOAPService.h"

/////////////////////////////////////////////////////////////////////////////
// CSendService
class ATL_NO_VTABLE CSendService : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSendService, &CLSID_SendService2>,
	public ISupportErrorInfo,
	public IDispatchImpl<ISendService2, &IID_ISendService2, &LIBID_EsendexLib, 2>,
	public CSOAPService
{
public:
	CSendService() : CSOAPService(L"SendService")
	{
		INIT_CLASS("CSendService");
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SENDSERVICE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSendService)
	COM_INTERFACE_ENTRY(ISendService2)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ISendService
public:
	STDMETHOD(Dummy)(ERROR_CODE x);
	STDMETHOD(SendMessageMultipleRecipientsFull)(BSTR Originator, BSTR Recipients, BSTR Body, MESSAGE_TYPE Type, long ValidityPeriod, IStringCollection2* *pVal);
	STDMETHOD(SendMessageMultipleRecipients)(BSTR Recipients, BSTR Body, MESSAGE_TYPE Type, /*[out, retval]*/ IStringCollection2** pVal);
	STDMETHOD(GetMessageStatus)(BSTR MessageID, /*[out, retval]*/ MESSAGE_STATUS*  pVal);
	STDMETHOD(Initialise)(BSTR Username, BSTR Password, BSTR Account, VARIANT IsServerSide);
	STDMETHOD(SendMessageFull)(BSTR Originator, BSTR Recipient, BSTR Body, MESSAGE_TYPE Type, long ValidityPeriod, /*[out, retval]*/ BSTR* pVal);
	STDMETHOD(SendMessage)(BSTR Recipient, BSTR Body, MESSAGE_TYPE Type, BSTR *pVal);

	static HRESULT SetMessageType(MSXML::IXMLDOMDocumentPtr spDoc, MESSAGE_TYPE Type);

	DECLARE_CLASS;
};

#endif //__SENDSERVICE_H_
