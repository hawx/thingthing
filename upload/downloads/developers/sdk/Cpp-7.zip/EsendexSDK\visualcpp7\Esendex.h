

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Wed Aug 11 17:33:07 2004
 */
/* Compiler settings for .\Esendex.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __Esendex_h__
#define __Esendex_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IDomainObject_FWD_DEFINED__
#define __IDomainObject_FWD_DEFINED__
typedef interface IDomainObject IDomainObject;
#endif 	/* __IDomainObject_FWD_DEFINED__ */


#ifndef __ILocalObject_FWD_DEFINED__
#define __ILocalObject_FWD_DEFINED__
typedef interface ILocalObject ILocalObject;
#endif 	/* __ILocalObject_FWD_DEFINED__ */


#ifndef __IStringCollection_FWD_DEFINED__
#define __IStringCollection_FWD_DEFINED__
typedef interface IStringCollection IStringCollection;
#endif 	/* __IStringCollection_FWD_DEFINED__ */


#ifndef __ISMSMessage_FWD_DEFINED__
#define __ISMSMessage_FWD_DEFINED__
typedef interface ISMSMessage ISMSMessage;
#endif 	/* __ISMSMessage_FWD_DEFINED__ */


#ifndef __ISMSMessageCollection_FWD_DEFINED__
#define __ISMSMessageCollection_FWD_DEFINED__
typedef interface ISMSMessageCollection ISMSMessageCollection;
#endif 	/* __ISMSMessageCollection_FWD_DEFINED__ */


#ifndef __ISendService_FWD_DEFINED__
#define __ISendService_FWD_DEFINED__
typedef interface ISendService ISendService;
#endif 	/* __ISendService_FWD_DEFINED__ */


#ifndef __IInboxService_FWD_DEFINED__
#define __IInboxService_FWD_DEFINED__
typedef interface IInboxService IInboxService;
#endif 	/* __IInboxService_FWD_DEFINED__ */


#ifndef __IAccountState_FWD_DEFINED__
#define __IAccountState_FWD_DEFINED__
typedef interface IAccountState IAccountState;
#endif 	/* __IAccountState_FWD_DEFINED__ */


#ifndef __IAccountService_FWD_DEFINED__
#define __IAccountService_FWD_DEFINED__
typedef interface IAccountService IAccountService;
#endif 	/* __IAccountService_FWD_DEFINED__ */


#ifndef __IObjectCollection_FWD_DEFINED__
#define __IObjectCollection_FWD_DEFINED__
typedef interface IObjectCollection IObjectCollection;
#endif 	/* __IObjectCollection_FWD_DEFINED__ */


#ifndef __IContact_FWD_DEFINED__
#define __IContact_FWD_DEFINED__
typedef interface IContact IContact;
#endif 	/* __IContact_FWD_DEFINED__ */


#ifndef __IContactGroup_FWD_DEFINED__
#define __IContactGroup_FWD_DEFINED__
typedef interface IContactGroup IContactGroup;
#endif 	/* __IContactGroup_FWD_DEFINED__ */


#ifndef __IContactService_FWD_DEFINED__
#define __IContactService_FWD_DEFINED__
typedef interface IContactService IContactService;
#endif 	/* __IContactService_FWD_DEFINED__ */


#ifndef __ISignupCompletionElements_FWD_DEFINED__
#define __ISignupCompletionElements_FWD_DEFINED__
typedef interface ISignupCompletionElements ISignupCompletionElements;
#endif 	/* __ISignupCompletionElements_FWD_DEFINED__ */


#ifndef __ISignupService_FWD_DEFINED__
#define __ISignupService_FWD_DEFINED__
typedef interface ISignupService ISignupService;
#endif 	/* __ISignupService_FWD_DEFINED__ */


#ifndef __ITestService_FWD_DEFINED__
#define __ITestService_FWD_DEFINED__
typedef interface ITestService ITestService;
#endif 	/* __ITestService_FWD_DEFINED__ */


#ifndef __IMessengerService_FWD_DEFINED__
#define __IMessengerService_FWD_DEFINED__
typedef interface IMessengerService IMessengerService;
#endif 	/* __IMessengerService_FWD_DEFINED__ */


#ifndef __SendService_FWD_DEFINED__
#define __SendService_FWD_DEFINED__

#ifdef __cplusplus
typedef class SendService SendService;
#else
typedef struct SendService SendService;
#endif /* __cplusplus */

#endif 	/* __SendService_FWD_DEFINED__ */


#ifndef __StringCollection_FWD_DEFINED__
#define __StringCollection_FWD_DEFINED__

#ifdef __cplusplus
typedef class StringCollection StringCollection;
#else
typedef struct StringCollection StringCollection;
#endif /* __cplusplus */

#endif 	/* __StringCollection_FWD_DEFINED__ */


#ifndef __InboxService_FWD_DEFINED__
#define __InboxService_FWD_DEFINED__

#ifdef __cplusplus
typedef class InboxService InboxService;
#else
typedef struct InboxService InboxService;
#endif /* __cplusplus */

#endif 	/* __InboxService_FWD_DEFINED__ */


#ifndef __AccountService_FWD_DEFINED__
#define __AccountService_FWD_DEFINED__

#ifdef __cplusplus
typedef class AccountService AccountService;
#else
typedef struct AccountService AccountService;
#endif /* __cplusplus */

#endif 	/* __AccountService_FWD_DEFINED__ */


#ifndef __SMSMessage_FWD_DEFINED__
#define __SMSMessage_FWD_DEFINED__

#ifdef __cplusplus
typedef class SMSMessage SMSMessage;
#else
typedef struct SMSMessage SMSMessage;
#endif /* __cplusplus */

#endif 	/* __SMSMessage_FWD_DEFINED__ */


#ifndef __SMSMessageCollection_FWD_DEFINED__
#define __SMSMessageCollection_FWD_DEFINED__

#ifdef __cplusplus
typedef class SMSMessageCollection SMSMessageCollection;
#else
typedef struct SMSMessageCollection SMSMessageCollection;
#endif /* __cplusplus */

#endif 	/* __SMSMessageCollection_FWD_DEFINED__ */


#ifndef __ContactService_FWD_DEFINED__
#define __ContactService_FWD_DEFINED__

#ifdef __cplusplus
typedef class ContactService ContactService;
#else
typedef struct ContactService ContactService;
#endif /* __cplusplus */

#endif 	/* __ContactService_FWD_DEFINED__ */


#ifndef __SignupService_FWD_DEFINED__
#define __SignupService_FWD_DEFINED__

#ifdef __cplusplus
typedef class SignupService SignupService;
#else
typedef struct SignupService SignupService;
#endif /* __cplusplus */

#endif 	/* __SignupService_FWD_DEFINED__ */


#ifndef __ObjectCollection_FWD_DEFINED__
#define __ObjectCollection_FWD_DEFINED__

#ifdef __cplusplus
typedef class ObjectCollection ObjectCollection;
#else
typedef struct ObjectCollection ObjectCollection;
#endif /* __cplusplus */

#endif 	/* __ObjectCollection_FWD_DEFINED__ */


#ifndef __Contact_FWD_DEFINED__
#define __Contact_FWD_DEFINED__

#ifdef __cplusplus
typedef class Contact Contact;
#else
typedef struct Contact Contact;
#endif /* __cplusplus */

#endif 	/* __Contact_FWD_DEFINED__ */


#ifndef __ContactGroup_FWD_DEFINED__
#define __ContactGroup_FWD_DEFINED__

#ifdef __cplusplus
typedef class ContactGroup ContactGroup;
#else
typedef struct ContactGroup ContactGroup;
#endif /* __cplusplus */

#endif 	/* __ContactGroup_FWD_DEFINED__ */


#ifndef __TestService_FWD_DEFINED__
#define __TestService_FWD_DEFINED__

#ifdef __cplusplus
typedef class TestService TestService;
#else
typedef struct TestService TestService;
#endif /* __cplusplus */

#endif 	/* __TestService_FWD_DEFINED__ */


#ifndef __SignupCompletionElements_FWD_DEFINED__
#define __SignupCompletionElements_FWD_DEFINED__

#ifdef __cplusplus
typedef class SignupCompletionElements SignupCompletionElements;
#else
typedef struct SignupCompletionElements SignupCompletionElements;
#endif /* __cplusplus */

#endif 	/* __SignupCompletionElements_FWD_DEFINED__ */


#ifndef __AccountState_FWD_DEFINED__
#define __AccountState_FWD_DEFINED__

#ifdef __cplusplus
typedef class AccountState AccountState;
#else
typedef struct AccountState AccountState;
#endif /* __cplusplus */

#endif 	/* __AccountState_FWD_DEFINED__ */


#ifndef __MessengerService_FWD_DEFINED__
#define __MessengerService_FWD_DEFINED__

#ifdef __cplusplus
typedef class MessengerService MessengerService;
#else
typedef struct MessengerService MessengerService;
#endif /* __cplusplus */

#endif 	/* __MessengerService_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

/* interface __MIDL_itf_Esendex_0000 */
/* [local] */ 

typedef 
enum MESSAGE_TYPE
    {	MESSAGE_TYPE_TEXT	= 1,
	MESSAGE_TYPE_BINARY	= 2,
	MESSAGE_TYPE_SMARTMESSAGE	= 3,
	MESSAGE_TYPE_UNICODE	= 4
    } 	MESSAGE_TYPE;

typedef 
enum MESSAGE_STATUS
    {	MESSAGE_STATUS_QUEUED	= 1,
	MESSAGE_STATUS_SENT	= 2,
	MESSAGE_STATUS_DELIVERED	= 3,
	MESSAGE_STATUS_FAILED	= 4
    } 	MESSAGE_STATUS;

typedef 
enum ACCOUNT_FEATURES
    {	ACCOUNT_FEATURE_NONE	= 0,
	ACCOUNT_FEATURE_SERVICE_ALIASING	= 1,
	ACCOUNT_FEATURE_INBOX	= 2
    } 	ACCOUNT_FEATURES;

typedef 
enum ERROR_CODE
    {	ERROR_CODE_UNEXPECTED	= 1,
	ERROR_CODE_AUTHENTICATION_FAILED	= 2,
	ERROR_CODE_MISSING_HEADER	= 3,
	ERROR_CODE_RECIPIENT_MISSING	= 4,
	ERROR_CODE_ACCOUNT_NOT_LIVE	= 5,
	ERROR_CODE_METHOD_NOT_ENABLED	= 6,
	ERROR_CODE_FEATURE_NOT_SUPPORTED	= 7,
	ERROR_CODE_MESSAGE_NOT_FOUND	= 8,
	ERROR_CODE_RECIPIENT_INVALID	= 9,
	ERROR_CODE_MESSAGE_LIMIT_EXCEEDED	= 10,
	ERROR_CODE_MESSAGE_ID_FORMAT_INVALID	= 11,
	ERROR_CODE_USERNAME_ALREADY_EXISTS	= 12,
	ERROR_CODE_CONTACT_ALREADY_EXISTS	= 13,
	ERROR_CODE_CONTACT_GROUP_ALREADY_EXISTS	= 14,
	ERROR_CODE_CONTACT_OR_GROUP_ALREADY_EXISTS	= 15
    } 	ERROR_CODE;



extern RPC_IF_HANDLE __MIDL_itf_Esendex_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_Esendex_0000_v0_0_s_ifspec;

#ifndef __IDomainObject_INTERFACE_DEFINED__
#define __IDomainObject_INTERFACE_DEFINED__

/* interface IDomainObject */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IDomainObject;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("E4D0FAEE-2D16-4543-8995-971A615E1AC5")
    IDomainObject : public IUnknown
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ID( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ID( 
            /* [in] */ BSTR newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDomainObjectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IDomainObject * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IDomainObject * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IDomainObject * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ID )( 
            IDomainObject * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ID )( 
            IDomainObject * This,
            /* [in] */ BSTR newVal);
        
        END_INTERFACE
    } IDomainObjectVtbl;

    interface IDomainObject
    {
        CONST_VTBL struct IDomainObjectVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDomainObject_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDomainObject_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDomainObject_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDomainObject_get_ID(This,pVal)	\
    (This)->lpVtbl -> get_ID(This,pVal)

#define IDomainObject_put_ID(This,newVal)	\
    (This)->lpVtbl -> put_ID(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDomainObject_get_ID_Proxy( 
    IDomainObject * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IDomainObject_get_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDomainObject_put_ID_Proxy( 
    IDomainObject * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IDomainObject_put_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDomainObject_INTERFACE_DEFINED__ */


#ifndef __ILocalObject_INTERFACE_DEFINED__
#define __ILocalObject_INTERFACE_DEFINED__

/* interface ILocalObject */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_ILocalObject;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("E5F0C6D3-5228-445e-8A69-0AF4155AB359")
    ILocalObject : public IUnknown
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetLocalObject( 
            /* [retval][out] */ IUnknown **pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ILocalObjectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ILocalObject * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ILocalObject * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ILocalObject * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetLocalObject )( 
            ILocalObject * This,
            /* [retval][out] */ IUnknown **pVal);
        
        END_INTERFACE
    } ILocalObjectVtbl;

    interface ILocalObject
    {
        CONST_VTBL struct ILocalObjectVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ILocalObject_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ILocalObject_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ILocalObject_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ILocalObject_GetLocalObject(This,pVal)	\
    (This)->lpVtbl -> GetLocalObject(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILocalObject_GetLocalObject_Proxy( 
    ILocalObject * This,
    /* [retval][out] */ IUnknown **pVal);


void __RPC_STUB ILocalObject_GetLocalObject_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ILocalObject_INTERFACE_DEFINED__ */


#ifndef __IStringCollection_INTERFACE_DEFINED__
#define __IStringCollection_INTERFACE_DEFINED__

/* interface IStringCollection */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IStringCollection;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("2E411932-076D-4367-8185-B29EA0FF697E")
    IStringCollection : public IDispatch
    {
    public:
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown **ppUnk) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ VARIANT Index,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_Item( 
            /* [in] */ VARIANT Index,
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Add( 
            BSTR newVal) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Remove( 
            VARIANT Index) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IStringCollectionVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IStringCollection * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IStringCollection * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IStringCollection * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IStringCollection * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IStringCollection * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IStringCollection * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IStringCollection * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE *get__NewEnum )( 
            IStringCollection * This,
            /* [retval][out] */ IUnknown **ppUnk);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IStringCollection * This,
            /* [in] */ VARIANT Index,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Item )( 
            IStringCollection * This,
            /* [in] */ VARIANT Index,
            /* [in] */ BSTR newVal);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            IStringCollection * This,
            /* [retval][out] */ long *pVal);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *Add )( 
            IStringCollection * This,
            BSTR newVal);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *Remove )( 
            IStringCollection * This,
            VARIANT Index);
        
        END_INTERFACE
    } IStringCollectionVtbl;

    interface IStringCollection
    {
        CONST_VTBL struct IStringCollectionVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IStringCollection_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IStringCollection_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IStringCollection_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IStringCollection_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IStringCollection_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IStringCollection_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IStringCollection_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IStringCollection_get__NewEnum(This,ppUnk)	\
    (This)->lpVtbl -> get__NewEnum(This,ppUnk)

#define IStringCollection_get_Item(This,Index,pVal)	\
    (This)->lpVtbl -> get_Item(This,Index,pVal)

#define IStringCollection_put_Item(This,Index,newVal)	\
    (This)->lpVtbl -> put_Item(This,Index,newVal)

#define IStringCollection_get_Count(This,pVal)	\
    (This)->lpVtbl -> get_Count(This,pVal)

#define IStringCollection_Add(This,newVal)	\
    (This)->lpVtbl -> Add(This,newVal)

#define IStringCollection_Remove(This,Index)	\
    (This)->lpVtbl -> Remove(This,Index)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget][id] */ HRESULT STDMETHODCALLTYPE IStringCollection_get__NewEnum_Proxy( 
    IStringCollection * This,
    /* [retval][out] */ IUnknown **ppUnk);


void __RPC_STUB IStringCollection_get__NewEnum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IStringCollection_get_Item_Proxy( 
    IStringCollection * This,
    /* [in] */ VARIANT Index,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IStringCollection_get_Item_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IStringCollection_put_Item_Proxy( 
    IStringCollection * This,
    /* [in] */ VARIANT Index,
    /* [in] */ BSTR newVal);


void __RPC_STUB IStringCollection_put_Item_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IStringCollection_get_Count_Proxy( 
    IStringCollection * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB IStringCollection_get_Count_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IStringCollection_Add_Proxy( 
    IStringCollection * This,
    BSTR newVal);


void __RPC_STUB IStringCollection_Add_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IStringCollection_Remove_Proxy( 
    IStringCollection * This,
    VARIANT Index);


void __RPC_STUB IStringCollection_Remove_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IStringCollection_INTERFACE_DEFINED__ */


#ifndef __ISMSMessage_INTERFACE_DEFINED__
#define __ISMSMessage_INTERFACE_DEFINED__

/* interface ISMSMessage */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISMSMessage;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("33C152F6-7B35-4329-B762-EA7C4B2F28DA")
    ISMSMessage : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_MessageID( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_MessageID( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Originator( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Originator( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Recipient( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Recipient( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Body( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Body( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SentAt( 
            /* [retval][out] */ DATE *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SentAt( 
            /* [in] */ DATE newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ReceivedAt( 
            /* [retval][out] */ DATE *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ReceivedAt( 
            /* [in] */ DATE newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Type( 
            /* [retval][out] */ MESSAGE_TYPE *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Type( 
            /* [in] */ MESSAGE_TYPE newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Status( 
            /* [retval][out] */ MESSAGE_STATUS *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Status( 
            /* [in] */ MESSAGE_STATUS newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Username( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Username( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_MessageIndex( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_MessageIndex( 
            /* [in] */ long newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISMSMessageVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISMSMessage * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISMSMessage * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISMSMessage * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISMSMessage * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISMSMessage * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISMSMessage * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISMSMessage * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_MessageID )( 
            ISMSMessage * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_MessageID )( 
            ISMSMessage * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Originator )( 
            ISMSMessage * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Originator )( 
            ISMSMessage * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Recipient )( 
            ISMSMessage * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Recipient )( 
            ISMSMessage * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Body )( 
            ISMSMessage * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Body )( 
            ISMSMessage * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_SentAt )( 
            ISMSMessage * This,
            /* [retval][out] */ DATE *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_SentAt )( 
            ISMSMessage * This,
            /* [in] */ DATE newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ReceivedAt )( 
            ISMSMessage * This,
            /* [retval][out] */ DATE *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ReceivedAt )( 
            ISMSMessage * This,
            /* [in] */ DATE newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Type )( 
            ISMSMessage * This,
            /* [retval][out] */ MESSAGE_TYPE *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Type )( 
            ISMSMessage * This,
            /* [in] */ MESSAGE_TYPE newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Status )( 
            ISMSMessage * This,
            /* [retval][out] */ MESSAGE_STATUS *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Status )( 
            ISMSMessage * This,
            /* [in] */ MESSAGE_STATUS newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Username )( 
            ISMSMessage * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Username )( 
            ISMSMessage * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_MessageIndex )( 
            ISMSMessage * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_MessageIndex )( 
            ISMSMessage * This,
            /* [in] */ long newVal);
        
        END_INTERFACE
    } ISMSMessageVtbl;

    interface ISMSMessage
    {
        CONST_VTBL struct ISMSMessageVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISMSMessage_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISMSMessage_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISMSMessage_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISMSMessage_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISMSMessage_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISMSMessage_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISMSMessage_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISMSMessage_get_MessageID(This,pVal)	\
    (This)->lpVtbl -> get_MessageID(This,pVal)

#define ISMSMessage_put_MessageID(This,newVal)	\
    (This)->lpVtbl -> put_MessageID(This,newVal)

#define ISMSMessage_get_Originator(This,pVal)	\
    (This)->lpVtbl -> get_Originator(This,pVal)

#define ISMSMessage_put_Originator(This,newVal)	\
    (This)->lpVtbl -> put_Originator(This,newVal)

#define ISMSMessage_get_Recipient(This,pVal)	\
    (This)->lpVtbl -> get_Recipient(This,pVal)

#define ISMSMessage_put_Recipient(This,newVal)	\
    (This)->lpVtbl -> put_Recipient(This,newVal)

#define ISMSMessage_get_Body(This,pVal)	\
    (This)->lpVtbl -> get_Body(This,pVal)

#define ISMSMessage_put_Body(This,newVal)	\
    (This)->lpVtbl -> put_Body(This,newVal)

#define ISMSMessage_get_SentAt(This,pVal)	\
    (This)->lpVtbl -> get_SentAt(This,pVal)

#define ISMSMessage_put_SentAt(This,newVal)	\
    (This)->lpVtbl -> put_SentAt(This,newVal)

#define ISMSMessage_get_ReceivedAt(This,pVal)	\
    (This)->lpVtbl -> get_ReceivedAt(This,pVal)

#define ISMSMessage_put_ReceivedAt(This,newVal)	\
    (This)->lpVtbl -> put_ReceivedAt(This,newVal)

#define ISMSMessage_get_Type(This,pVal)	\
    (This)->lpVtbl -> get_Type(This,pVal)

#define ISMSMessage_put_Type(This,newVal)	\
    (This)->lpVtbl -> put_Type(This,newVal)

#define ISMSMessage_get_Status(This,pVal)	\
    (This)->lpVtbl -> get_Status(This,pVal)

#define ISMSMessage_put_Status(This,newVal)	\
    (This)->lpVtbl -> put_Status(This,newVal)

#define ISMSMessage_get_Username(This,pVal)	\
    (This)->lpVtbl -> get_Username(This,pVal)

#define ISMSMessage_put_Username(This,newVal)	\
    (This)->lpVtbl -> put_Username(This,newVal)

#define ISMSMessage_get_MessageIndex(This,pVal)	\
    (This)->lpVtbl -> get_MessageIndex(This,pVal)

#define ISMSMessage_put_MessageIndex(This,newVal)	\
    (This)->lpVtbl -> put_MessageIndex(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage_get_MessageID_Proxy( 
    ISMSMessage * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISMSMessage_get_MessageID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage_put_MessageID_Proxy( 
    ISMSMessage * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISMSMessage_put_MessageID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage_get_Originator_Proxy( 
    ISMSMessage * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISMSMessage_get_Originator_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage_put_Originator_Proxy( 
    ISMSMessage * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISMSMessage_put_Originator_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage_get_Recipient_Proxy( 
    ISMSMessage * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISMSMessage_get_Recipient_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage_put_Recipient_Proxy( 
    ISMSMessage * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISMSMessage_put_Recipient_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage_get_Body_Proxy( 
    ISMSMessage * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISMSMessage_get_Body_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage_put_Body_Proxy( 
    ISMSMessage * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISMSMessage_put_Body_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage_get_SentAt_Proxy( 
    ISMSMessage * This,
    /* [retval][out] */ DATE *pVal);


void __RPC_STUB ISMSMessage_get_SentAt_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage_put_SentAt_Proxy( 
    ISMSMessage * This,
    /* [in] */ DATE newVal);


void __RPC_STUB ISMSMessage_put_SentAt_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage_get_ReceivedAt_Proxy( 
    ISMSMessage * This,
    /* [retval][out] */ DATE *pVal);


void __RPC_STUB ISMSMessage_get_ReceivedAt_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage_put_ReceivedAt_Proxy( 
    ISMSMessage * This,
    /* [in] */ DATE newVal);


void __RPC_STUB ISMSMessage_put_ReceivedAt_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage_get_Type_Proxy( 
    ISMSMessage * This,
    /* [retval][out] */ MESSAGE_TYPE *pVal);


void __RPC_STUB ISMSMessage_get_Type_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage_put_Type_Proxy( 
    ISMSMessage * This,
    /* [in] */ MESSAGE_TYPE newVal);


void __RPC_STUB ISMSMessage_put_Type_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage_get_Status_Proxy( 
    ISMSMessage * This,
    /* [retval][out] */ MESSAGE_STATUS *pVal);


void __RPC_STUB ISMSMessage_get_Status_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage_put_Status_Proxy( 
    ISMSMessage * This,
    /* [in] */ MESSAGE_STATUS newVal);


void __RPC_STUB ISMSMessage_put_Status_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage_get_Username_Proxy( 
    ISMSMessage * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISMSMessage_get_Username_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage_put_Username_Proxy( 
    ISMSMessage * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISMSMessage_put_Username_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage_get_MessageIndex_Proxy( 
    ISMSMessage * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB ISMSMessage_get_MessageIndex_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage_put_MessageIndex_Proxy( 
    ISMSMessage * This,
    /* [in] */ long newVal);


void __RPC_STUB ISMSMessage_put_MessageIndex_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISMSMessage_INTERFACE_DEFINED__ */


#ifndef __ISMSMessageCollection_INTERFACE_DEFINED__
#define __ISMSMessageCollection_INTERFACE_DEFINED__

/* interface ISMSMessageCollection */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISMSMessageCollection;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("55241232-84C9-4608-8FD9-54EF8EDF00CC")
    ISMSMessageCollection : public IDispatch
    {
    public:
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown **ppUnk) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ VARIANT Index,
            /* [retval][out] */ ISMSMessage **pVal) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_Item( 
            /* [in] */ VARIANT Index,
            /* [in] */ ISMSMessage *newVal) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Add( 
            ISMSMessage *newVal) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Remove( 
            VARIANT Index) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISMSMessageCollectionVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISMSMessageCollection * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISMSMessageCollection * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISMSMessageCollection * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISMSMessageCollection * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISMSMessageCollection * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISMSMessageCollection * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISMSMessageCollection * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE *get__NewEnum )( 
            ISMSMessageCollection * This,
            /* [retval][out] */ IUnknown **ppUnk);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            ISMSMessageCollection * This,
            /* [in] */ VARIANT Index,
            /* [retval][out] */ ISMSMessage **pVal);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Item )( 
            ISMSMessageCollection * This,
            /* [in] */ VARIANT Index,
            /* [in] */ ISMSMessage *newVal);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            ISMSMessageCollection * This,
            /* [retval][out] */ long *pVal);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *Add )( 
            ISMSMessageCollection * This,
            ISMSMessage *newVal);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *Remove )( 
            ISMSMessageCollection * This,
            VARIANT Index);
        
        END_INTERFACE
    } ISMSMessageCollectionVtbl;

    interface ISMSMessageCollection
    {
        CONST_VTBL struct ISMSMessageCollectionVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISMSMessageCollection_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISMSMessageCollection_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISMSMessageCollection_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISMSMessageCollection_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISMSMessageCollection_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISMSMessageCollection_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISMSMessageCollection_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISMSMessageCollection_get__NewEnum(This,ppUnk)	\
    (This)->lpVtbl -> get__NewEnum(This,ppUnk)

#define ISMSMessageCollection_get_Item(This,Index,pVal)	\
    (This)->lpVtbl -> get_Item(This,Index,pVal)

#define ISMSMessageCollection_put_Item(This,Index,newVal)	\
    (This)->lpVtbl -> put_Item(This,Index,newVal)

#define ISMSMessageCollection_get_Count(This,pVal)	\
    (This)->lpVtbl -> get_Count(This,pVal)

#define ISMSMessageCollection_Add(This,newVal)	\
    (This)->lpVtbl -> Add(This,newVal)

#define ISMSMessageCollection_Remove(This,Index)	\
    (This)->lpVtbl -> Remove(This,Index)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget][id] */ HRESULT STDMETHODCALLTYPE ISMSMessageCollection_get__NewEnum_Proxy( 
    ISMSMessageCollection * This,
    /* [retval][out] */ IUnknown **ppUnk);


void __RPC_STUB ISMSMessageCollection_get__NewEnum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE ISMSMessageCollection_get_Item_Proxy( 
    ISMSMessageCollection * This,
    /* [in] */ VARIANT Index,
    /* [retval][out] */ ISMSMessage **pVal);


void __RPC_STUB ISMSMessageCollection_get_Item_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE ISMSMessageCollection_put_Item_Proxy( 
    ISMSMessageCollection * This,
    /* [in] */ VARIANT Index,
    /* [in] */ ISMSMessage *newVal);


void __RPC_STUB ISMSMessageCollection_put_Item_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE ISMSMessageCollection_get_Count_Proxy( 
    ISMSMessageCollection * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB ISMSMessageCollection_get_Count_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE ISMSMessageCollection_Add_Proxy( 
    ISMSMessageCollection * This,
    ISMSMessage *newVal);


void __RPC_STUB ISMSMessageCollection_Add_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE ISMSMessageCollection_Remove_Proxy( 
    ISMSMessageCollection * This,
    VARIANT Index);


void __RPC_STUB ISMSMessageCollection_Remove_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISMSMessageCollection_INTERFACE_DEFINED__ */


#ifndef __ISendService_INTERFACE_DEFINED__
#define __ISendService_INTERFACE_DEFINED__

/* interface ISendService */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISendService;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("9EAD024D-543D-4676-B93D-13DE62848EED")
    ISendService : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Initialise( 
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SendMessageFull( 
            BSTR Originator,
            BSTR Recipient,
            BSTR Body,
            MESSAGE_TYPE Type,
            long ValidityPeriod,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SendMessage( 
            BSTR Recipient,
            BSTR Body,
            MESSAGE_TYPE Type,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetMessageStatus( 
            VARIANT Message,
            /* [retval][out] */ MESSAGE_STATUS *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SendMessageMultipleRecipients( 
            VARIANT Recipients,
            BSTR Body,
            MESSAGE_TYPE Type,
            /* [retval][out] */ IStringCollection **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SendMessageMultipleRecipientsFull( 
            BSTR Originator,
            VARIANT Recipients,
            BSTR Body,
            MESSAGE_TYPE Type,
            long ValidityPeriod,
            /* [retval][out] */ IStringCollection **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Dummy( 
            ERROR_CODE x) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISendServiceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISendService * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISendService * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISendService * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISendService * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISendService * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISendService * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISendService * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Initialise )( 
            ISendService * This,
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SendMessageFull )( 
            ISendService * This,
            BSTR Originator,
            BSTR Recipient,
            BSTR Body,
            MESSAGE_TYPE Type,
            long ValidityPeriod,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SendMessage )( 
            ISendService * This,
            BSTR Recipient,
            BSTR Body,
            MESSAGE_TYPE Type,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetMessageStatus )( 
            ISendService * This,
            VARIANT Message,
            /* [retval][out] */ MESSAGE_STATUS *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SendMessageMultipleRecipients )( 
            ISendService * This,
            VARIANT Recipients,
            BSTR Body,
            MESSAGE_TYPE Type,
            /* [retval][out] */ IStringCollection **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SendMessageMultipleRecipientsFull )( 
            ISendService * This,
            BSTR Originator,
            VARIANT Recipients,
            BSTR Body,
            MESSAGE_TYPE Type,
            long ValidityPeriod,
            /* [retval][out] */ IStringCollection **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Dummy )( 
            ISendService * This,
            ERROR_CODE x);
        
        END_INTERFACE
    } ISendServiceVtbl;

    interface ISendService
    {
        CONST_VTBL struct ISendServiceVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISendService_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISendService_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISendService_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISendService_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISendService_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISendService_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISendService_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISendService_Initialise(This,Username,Password,Account,IsServerSide)	\
    (This)->lpVtbl -> Initialise(This,Username,Password,Account,IsServerSide)

#define ISendService_SendMessageFull(This,Originator,Recipient,Body,Type,ValidityPeriod,pVal)	\
    (This)->lpVtbl -> SendMessageFull(This,Originator,Recipient,Body,Type,ValidityPeriod,pVal)

#define ISendService_SendMessage(This,Recipient,Body,Type,pVal)	\
    (This)->lpVtbl -> SendMessage(This,Recipient,Body,Type,pVal)

#define ISendService_GetMessageStatus(This,Message,pVal)	\
    (This)->lpVtbl -> GetMessageStatus(This,Message,pVal)

#define ISendService_SendMessageMultipleRecipients(This,Recipients,Body,Type,pVal)	\
    (This)->lpVtbl -> SendMessageMultipleRecipients(This,Recipients,Body,Type,pVal)

#define ISendService_SendMessageMultipleRecipientsFull(This,Originator,Recipients,Body,Type,ValidityPeriod,pVal)	\
    (This)->lpVtbl -> SendMessageMultipleRecipientsFull(This,Originator,Recipients,Body,Type,ValidityPeriod,pVal)

#define ISendService_Dummy(This,x)	\
    (This)->lpVtbl -> Dummy(This,x)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISendService_Initialise_Proxy( 
    ISendService * This,
    BSTR Username,
    BSTR Password,
    BSTR Account,
    /* [optional] */ VARIANT IsServerSide);


void __RPC_STUB ISendService_Initialise_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISendService_SendMessageFull_Proxy( 
    ISendService * This,
    BSTR Originator,
    BSTR Recipient,
    BSTR Body,
    MESSAGE_TYPE Type,
    long ValidityPeriod,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISendService_SendMessageFull_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISendService_SendMessage_Proxy( 
    ISendService * This,
    BSTR Recipient,
    BSTR Body,
    MESSAGE_TYPE Type,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISendService_SendMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISendService_GetMessageStatus_Proxy( 
    ISendService * This,
    VARIANT Message,
    /* [retval][out] */ MESSAGE_STATUS *pVal);


void __RPC_STUB ISendService_GetMessageStatus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISendService_SendMessageMultipleRecipients_Proxy( 
    ISendService * This,
    VARIANT Recipients,
    BSTR Body,
    MESSAGE_TYPE Type,
    /* [retval][out] */ IStringCollection **pVal);


void __RPC_STUB ISendService_SendMessageMultipleRecipients_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISendService_SendMessageMultipleRecipientsFull_Proxy( 
    ISendService * This,
    BSTR Originator,
    VARIANT Recipients,
    BSTR Body,
    MESSAGE_TYPE Type,
    long ValidityPeriod,
    /* [retval][out] */ IStringCollection **pVal);


void __RPC_STUB ISendService_SendMessageMultipleRecipientsFull_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISendService_Dummy_Proxy( 
    ISendService * This,
    ERROR_CODE x);


void __RPC_STUB ISendService_Dummy_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISendService_INTERFACE_DEFINED__ */


#ifndef __IInboxService_INTERFACE_DEFINED__
#define __IInboxService_INTERFACE_DEFINED__

/* interface IInboxService */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IInboxService;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("59D5EA44-F770-4052-834A-EE681F3E1E57")
    IInboxService : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Initialise( 
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteMessage( 
            VARIANT Message) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteMessages( 
            VARIANT Messages) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetMessages( 
            /* [retval][out] */ ISMSMessageCollection **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetMessage( 
            /* [in] */ VARIANT ID,
            /* [retval][out] */ ISMSMessage **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetMessagesForDay( 
            /* [in] */ long Year,
            /* [in] */ long Month,
            /* [in] */ long Day,
            /* [retval][out] */ ISMSMessageCollection **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetMessagesForDateRange( 
            DATE StartDate,
            DATE EndDate,
            /* [retval][out] */ ISMSMessageCollection **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetMessagesByID( 
            /* [in] */ VARIANT Messages,
            /* [retval][out] */ ISMSMessageCollection **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetLatestMessages( 
            /* [optional] */ VARIANT LastMessageIndex,
            /* [optional] */ VARIANT MaxMessages,
            /* [retval][out] */ ISMSMessageCollection **pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IInboxServiceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IInboxService * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IInboxService * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IInboxService * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IInboxService * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IInboxService * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IInboxService * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IInboxService * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Initialise )( 
            IInboxService * This,
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DeleteMessage )( 
            IInboxService * This,
            VARIANT Message);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DeleteMessages )( 
            IInboxService * This,
            VARIANT Messages);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetMessages )( 
            IInboxService * This,
            /* [retval][out] */ ISMSMessageCollection **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetMessage )( 
            IInboxService * This,
            /* [in] */ VARIANT ID,
            /* [retval][out] */ ISMSMessage **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetMessagesForDay )( 
            IInboxService * This,
            /* [in] */ long Year,
            /* [in] */ long Month,
            /* [in] */ long Day,
            /* [retval][out] */ ISMSMessageCollection **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetMessagesForDateRange )( 
            IInboxService * This,
            DATE StartDate,
            DATE EndDate,
            /* [retval][out] */ ISMSMessageCollection **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetMessagesByID )( 
            IInboxService * This,
            /* [in] */ VARIANT Messages,
            /* [retval][out] */ ISMSMessageCollection **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetLatestMessages )( 
            IInboxService * This,
            /* [optional] */ VARIANT LastMessageIndex,
            /* [optional] */ VARIANT MaxMessages,
            /* [retval][out] */ ISMSMessageCollection **pVal);
        
        END_INTERFACE
    } IInboxServiceVtbl;

    interface IInboxService
    {
        CONST_VTBL struct IInboxServiceVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IInboxService_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IInboxService_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IInboxService_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IInboxService_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IInboxService_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IInboxService_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IInboxService_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IInboxService_Initialise(This,Username,Password,Account,IsServerSide)	\
    (This)->lpVtbl -> Initialise(This,Username,Password,Account,IsServerSide)

#define IInboxService_DeleteMessage(This,Message)	\
    (This)->lpVtbl -> DeleteMessage(This,Message)

#define IInboxService_DeleteMessages(This,Messages)	\
    (This)->lpVtbl -> DeleteMessages(This,Messages)

#define IInboxService_GetMessages(This,pVal)	\
    (This)->lpVtbl -> GetMessages(This,pVal)

#define IInboxService_GetMessage(This,ID,pVal)	\
    (This)->lpVtbl -> GetMessage(This,ID,pVal)

#define IInboxService_GetMessagesForDay(This,Year,Month,Day,pVal)	\
    (This)->lpVtbl -> GetMessagesForDay(This,Year,Month,Day,pVal)

#define IInboxService_GetMessagesForDateRange(This,StartDate,EndDate,pVal)	\
    (This)->lpVtbl -> GetMessagesForDateRange(This,StartDate,EndDate,pVal)

#define IInboxService_GetMessagesByID(This,Messages,pVal)	\
    (This)->lpVtbl -> GetMessagesByID(This,Messages,pVal)

#define IInboxService_GetLatestMessages(This,LastMessageIndex,MaxMessages,pVal)	\
    (This)->lpVtbl -> GetLatestMessages(This,LastMessageIndex,MaxMessages,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService_Initialise_Proxy( 
    IInboxService * This,
    BSTR Username,
    BSTR Password,
    BSTR Account,
    /* [optional] */ VARIANT IsServerSide);


void __RPC_STUB IInboxService_Initialise_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService_DeleteMessage_Proxy( 
    IInboxService * This,
    VARIANT Message);


void __RPC_STUB IInboxService_DeleteMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService_DeleteMessages_Proxy( 
    IInboxService * This,
    VARIANT Messages);


void __RPC_STUB IInboxService_DeleteMessages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService_GetMessages_Proxy( 
    IInboxService * This,
    /* [retval][out] */ ISMSMessageCollection **pVal);


void __RPC_STUB IInboxService_GetMessages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService_GetMessage_Proxy( 
    IInboxService * This,
    /* [in] */ VARIANT ID,
    /* [retval][out] */ ISMSMessage **pVal);


void __RPC_STUB IInboxService_GetMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService_GetMessagesForDay_Proxy( 
    IInboxService * This,
    /* [in] */ long Year,
    /* [in] */ long Month,
    /* [in] */ long Day,
    /* [retval][out] */ ISMSMessageCollection **pVal);


void __RPC_STUB IInboxService_GetMessagesForDay_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService_GetMessagesForDateRange_Proxy( 
    IInboxService * This,
    DATE StartDate,
    DATE EndDate,
    /* [retval][out] */ ISMSMessageCollection **pVal);


void __RPC_STUB IInboxService_GetMessagesForDateRange_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService_GetMessagesByID_Proxy( 
    IInboxService * This,
    /* [in] */ VARIANT Messages,
    /* [retval][out] */ ISMSMessageCollection **pVal);


void __RPC_STUB IInboxService_GetMessagesByID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService_GetLatestMessages_Proxy( 
    IInboxService * This,
    /* [optional] */ VARIANT LastMessageIndex,
    /* [optional] */ VARIANT MaxMessages,
    /* [retval][out] */ ISMSMessageCollection **pVal);


void __RPC_STUB IInboxService_GetLatestMessages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IInboxService_INTERFACE_DEFINED__ */


#ifndef __IAccountState_INTERFACE_DEFINED__
#define __IAccountState_INTERFACE_DEFINED__

/* interface IAccountState */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IAccountState;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("1684AE92-1721-4B3C-98D2-3914F7BB3B0F")
    IAccountState : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ID( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ID( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Reference( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Reference( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Address( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Address( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ServiceAlias( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ServiceAlias( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_MessageLimit( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_MessageLimit( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Features( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Features( 
            /* [in] */ long newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAccountStateVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IAccountState * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IAccountState * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IAccountState * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IAccountState * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IAccountState * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IAccountState * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IAccountState * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ID )( 
            IAccountState * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ID )( 
            IAccountState * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Reference )( 
            IAccountState * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Reference )( 
            IAccountState * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Address )( 
            IAccountState * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Address )( 
            IAccountState * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ServiceAlias )( 
            IAccountState * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ServiceAlias )( 
            IAccountState * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_MessageLimit )( 
            IAccountState * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_MessageLimit )( 
            IAccountState * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Features )( 
            IAccountState * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Features )( 
            IAccountState * This,
            /* [in] */ long newVal);
        
        END_INTERFACE
    } IAccountStateVtbl;

    interface IAccountState
    {
        CONST_VTBL struct IAccountStateVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAccountState_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IAccountState_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IAccountState_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IAccountState_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IAccountState_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IAccountState_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IAccountState_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IAccountState_get_ID(This,pVal)	\
    (This)->lpVtbl -> get_ID(This,pVal)

#define IAccountState_put_ID(This,newVal)	\
    (This)->lpVtbl -> put_ID(This,newVal)

#define IAccountState_get_Reference(This,pVal)	\
    (This)->lpVtbl -> get_Reference(This,pVal)

#define IAccountState_put_Reference(This,newVal)	\
    (This)->lpVtbl -> put_Reference(This,newVal)

#define IAccountState_get_Address(This,pVal)	\
    (This)->lpVtbl -> get_Address(This,pVal)

#define IAccountState_put_Address(This,newVal)	\
    (This)->lpVtbl -> put_Address(This,newVal)

#define IAccountState_get_ServiceAlias(This,pVal)	\
    (This)->lpVtbl -> get_ServiceAlias(This,pVal)

#define IAccountState_put_ServiceAlias(This,newVal)	\
    (This)->lpVtbl -> put_ServiceAlias(This,newVal)

#define IAccountState_get_MessageLimit(This,pVal)	\
    (This)->lpVtbl -> get_MessageLimit(This,pVal)

#define IAccountState_put_MessageLimit(This,newVal)	\
    (This)->lpVtbl -> put_MessageLimit(This,newVal)

#define IAccountState_get_Features(This,pVal)	\
    (This)->lpVtbl -> get_Features(This,pVal)

#define IAccountState_put_Features(This,newVal)	\
    (This)->lpVtbl -> put_Features(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAccountState_get_ID_Proxy( 
    IAccountState * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IAccountState_get_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAccountState_put_ID_Proxy( 
    IAccountState * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IAccountState_put_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAccountState_get_Reference_Proxy( 
    IAccountState * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IAccountState_get_Reference_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAccountState_put_Reference_Proxy( 
    IAccountState * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IAccountState_put_Reference_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAccountState_get_Address_Proxy( 
    IAccountState * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IAccountState_get_Address_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAccountState_put_Address_Proxy( 
    IAccountState * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IAccountState_put_Address_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAccountState_get_ServiceAlias_Proxy( 
    IAccountState * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IAccountState_get_ServiceAlias_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAccountState_put_ServiceAlias_Proxy( 
    IAccountState * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IAccountState_put_ServiceAlias_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAccountState_get_MessageLimit_Proxy( 
    IAccountState * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB IAccountState_get_MessageLimit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAccountState_put_MessageLimit_Proxy( 
    IAccountState * This,
    /* [in] */ long newVal);


void __RPC_STUB IAccountState_put_MessageLimit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAccountState_get_Features_Proxy( 
    IAccountState * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB IAccountState_get_Features_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAccountState_put_Features_Proxy( 
    IAccountState * This,
    /* [in] */ long newVal);


void __RPC_STUB IAccountState_put_Features_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IAccountState_INTERFACE_DEFINED__ */


#ifndef __IAccountService_INTERFACE_DEFINED__
#define __IAccountService_INTERFACE_DEFINED__

/* interface IAccountService */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IAccountService;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("95605B05-3760-4211-9EEB-F6D928325031")
    IAccountService : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Initialise( 
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetMessageLimit( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetAccountFeatures( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Dummy( 
            ACCOUNT_FEATURES x) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetAccountState( 
            /* [retval][out] */ IAccountState **pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAccountServiceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IAccountService * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IAccountService * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IAccountService * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IAccountService * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IAccountService * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IAccountService * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IAccountService * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Initialise )( 
            IAccountService * This,
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetMessageLimit )( 
            IAccountService * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetAccountFeatures )( 
            IAccountService * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Dummy )( 
            IAccountService * This,
            ACCOUNT_FEATURES x);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetAccountState )( 
            IAccountService * This,
            /* [retval][out] */ IAccountState **pVal);
        
        END_INTERFACE
    } IAccountServiceVtbl;

    interface IAccountService
    {
        CONST_VTBL struct IAccountServiceVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAccountService_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IAccountService_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IAccountService_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IAccountService_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IAccountService_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IAccountService_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IAccountService_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IAccountService_Initialise(This,Username,Password,Account,IsServerSide)	\
    (This)->lpVtbl -> Initialise(This,Username,Password,Account,IsServerSide)

#define IAccountService_GetMessageLimit(This,pVal)	\
    (This)->lpVtbl -> GetMessageLimit(This,pVal)

#define IAccountService_GetAccountFeatures(This,pVal)	\
    (This)->lpVtbl -> GetAccountFeatures(This,pVal)

#define IAccountService_Dummy(This,x)	\
    (This)->lpVtbl -> Dummy(This,x)

#define IAccountService_GetAccountState(This,pVal)	\
    (This)->lpVtbl -> GetAccountState(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAccountService_Initialise_Proxy( 
    IAccountService * This,
    BSTR Username,
    BSTR Password,
    BSTR Account,
    /* [optional] */ VARIANT IsServerSide);


void __RPC_STUB IAccountService_Initialise_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAccountService_GetMessageLimit_Proxy( 
    IAccountService * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB IAccountService_GetMessageLimit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAccountService_GetAccountFeatures_Proxy( 
    IAccountService * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB IAccountService_GetAccountFeatures_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAccountService_Dummy_Proxy( 
    IAccountService * This,
    ACCOUNT_FEATURES x);


void __RPC_STUB IAccountService_Dummy_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAccountService_GetAccountState_Proxy( 
    IAccountService * This,
    /* [retval][out] */ IAccountState **pVal);


void __RPC_STUB IAccountService_GetAccountState_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IAccountService_INTERFACE_DEFINED__ */


#ifndef __IObjectCollection_INTERFACE_DEFINED__
#define __IObjectCollection_INTERFACE_DEFINED__

/* interface IObjectCollection */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IObjectCollection;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("D1CF7E2D-BFBB-4277-AC8D-2C427B738B4F")
    IObjectCollection : public IDispatch
    {
    public:
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown **ppUnk) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ VARIANT Index,
            /* [retval][out] */ IDispatch **pVal) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_Item( 
            /* [in] */ VARIANT Index,
            /* [in] */ IDispatch *newVal) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Add( 
            IDispatch *newVal) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Remove( 
            VARIANT Index) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IObjectCollectionVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IObjectCollection * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IObjectCollection * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IObjectCollection * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IObjectCollection * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IObjectCollection * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IObjectCollection * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IObjectCollection * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE *get__NewEnum )( 
            IObjectCollection * This,
            /* [retval][out] */ IUnknown **ppUnk);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IObjectCollection * This,
            /* [in] */ VARIANT Index,
            /* [retval][out] */ IDispatch **pVal);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Item )( 
            IObjectCollection * This,
            /* [in] */ VARIANT Index,
            /* [in] */ IDispatch *newVal);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            IObjectCollection * This,
            /* [retval][out] */ long *pVal);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *Add )( 
            IObjectCollection * This,
            IDispatch *newVal);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *Remove )( 
            IObjectCollection * This,
            VARIANT Index);
        
        END_INTERFACE
    } IObjectCollectionVtbl;

    interface IObjectCollection
    {
        CONST_VTBL struct IObjectCollectionVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IObjectCollection_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IObjectCollection_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IObjectCollection_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IObjectCollection_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IObjectCollection_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IObjectCollection_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IObjectCollection_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IObjectCollection_get__NewEnum(This,ppUnk)	\
    (This)->lpVtbl -> get__NewEnum(This,ppUnk)

#define IObjectCollection_get_Item(This,Index,pVal)	\
    (This)->lpVtbl -> get_Item(This,Index,pVal)

#define IObjectCollection_put_Item(This,Index,newVal)	\
    (This)->lpVtbl -> put_Item(This,Index,newVal)

#define IObjectCollection_get_Count(This,pVal)	\
    (This)->lpVtbl -> get_Count(This,pVal)

#define IObjectCollection_Add(This,newVal)	\
    (This)->lpVtbl -> Add(This,newVal)

#define IObjectCollection_Remove(This,Index)	\
    (This)->lpVtbl -> Remove(This,Index)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget][id] */ HRESULT STDMETHODCALLTYPE IObjectCollection_get__NewEnum_Proxy( 
    IObjectCollection * This,
    /* [retval][out] */ IUnknown **ppUnk);


void __RPC_STUB IObjectCollection_get__NewEnum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IObjectCollection_get_Item_Proxy( 
    IObjectCollection * This,
    /* [in] */ VARIANT Index,
    /* [retval][out] */ IDispatch **pVal);


void __RPC_STUB IObjectCollection_get_Item_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IObjectCollection_put_Item_Proxy( 
    IObjectCollection * This,
    /* [in] */ VARIANT Index,
    /* [in] */ IDispatch *newVal);


void __RPC_STUB IObjectCollection_put_Item_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IObjectCollection_get_Count_Proxy( 
    IObjectCollection * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB IObjectCollection_get_Count_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IObjectCollection_Add_Proxy( 
    IObjectCollection * This,
    IDispatch *newVal);


void __RPC_STUB IObjectCollection_Add_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IObjectCollection_Remove_Proxy( 
    IObjectCollection * This,
    VARIANT Index);


void __RPC_STUB IObjectCollection_Remove_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IObjectCollection_INTERFACE_DEFINED__ */


#ifndef __IContact_INTERFACE_DEFINED__
#define __IContact_INTERFACE_DEFINED__

/* interface IContact */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IContact;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("790CF8C5-14A7-45CA-BEEA-9BF6C8B7B9CB")
    IContact : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ID( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ID( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_QuickName( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_QuickName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FirstName( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FirstName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_LastName( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_LastName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_TelephoneNumber( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_TelephoneNumber( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_MobileNumber( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_MobileNumber( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_StreetAddress1( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_StreetAddress1( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_StreetAddress2( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_StreetAddress2( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Town( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Town( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_County( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_County( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Postcode( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Postcode( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Country( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Country( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_EmailAddress( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_EmailAddress( 
            /* [in] */ BSTR newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IContactVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IContact * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IContact * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IContact * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IContact * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IContact * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IContact * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IContact * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ID )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ID )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_QuickName )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_QuickName )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_FirstName )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_FirstName )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_LastName )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_LastName )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_TelephoneNumber )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_TelephoneNumber )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_MobileNumber )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_MobileNumber )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_StreetAddress1 )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_StreetAddress1 )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_StreetAddress2 )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_StreetAddress2 )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Town )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Town )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_County )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_County )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Postcode )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Postcode )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Country )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Country )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_EmailAddress )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_EmailAddress )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        END_INTERFACE
    } IContactVtbl;

    interface IContact
    {
        CONST_VTBL struct IContactVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IContact_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IContact_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IContact_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IContact_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IContact_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IContact_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IContact_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IContact_get_ID(This,pVal)	\
    (This)->lpVtbl -> get_ID(This,pVal)

#define IContact_put_ID(This,newVal)	\
    (This)->lpVtbl -> put_ID(This,newVal)

#define IContact_get_QuickName(This,pVal)	\
    (This)->lpVtbl -> get_QuickName(This,pVal)

#define IContact_put_QuickName(This,newVal)	\
    (This)->lpVtbl -> put_QuickName(This,newVal)

#define IContact_get_FirstName(This,pVal)	\
    (This)->lpVtbl -> get_FirstName(This,pVal)

#define IContact_put_FirstName(This,newVal)	\
    (This)->lpVtbl -> put_FirstName(This,newVal)

#define IContact_get_LastName(This,pVal)	\
    (This)->lpVtbl -> get_LastName(This,pVal)

#define IContact_put_LastName(This,newVal)	\
    (This)->lpVtbl -> put_LastName(This,newVal)

#define IContact_get_TelephoneNumber(This,pVal)	\
    (This)->lpVtbl -> get_TelephoneNumber(This,pVal)

#define IContact_put_TelephoneNumber(This,newVal)	\
    (This)->lpVtbl -> put_TelephoneNumber(This,newVal)

#define IContact_get_MobileNumber(This,pVal)	\
    (This)->lpVtbl -> get_MobileNumber(This,pVal)

#define IContact_put_MobileNumber(This,newVal)	\
    (This)->lpVtbl -> put_MobileNumber(This,newVal)

#define IContact_get_StreetAddress1(This,pVal)	\
    (This)->lpVtbl -> get_StreetAddress1(This,pVal)

#define IContact_put_StreetAddress1(This,newVal)	\
    (This)->lpVtbl -> put_StreetAddress1(This,newVal)

#define IContact_get_StreetAddress2(This,pVal)	\
    (This)->lpVtbl -> get_StreetAddress2(This,pVal)

#define IContact_put_StreetAddress2(This,newVal)	\
    (This)->lpVtbl -> put_StreetAddress2(This,newVal)

#define IContact_get_Town(This,pVal)	\
    (This)->lpVtbl -> get_Town(This,pVal)

#define IContact_put_Town(This,newVal)	\
    (This)->lpVtbl -> put_Town(This,newVal)

#define IContact_get_County(This,pVal)	\
    (This)->lpVtbl -> get_County(This,pVal)

#define IContact_put_County(This,newVal)	\
    (This)->lpVtbl -> put_County(This,newVal)

#define IContact_get_Postcode(This,pVal)	\
    (This)->lpVtbl -> get_Postcode(This,pVal)

#define IContact_put_Postcode(This,newVal)	\
    (This)->lpVtbl -> put_Postcode(This,newVal)

#define IContact_get_Country(This,pVal)	\
    (This)->lpVtbl -> get_Country(This,pVal)

#define IContact_put_Country(This,newVal)	\
    (This)->lpVtbl -> put_Country(This,newVal)

#define IContact_get_EmailAddress(This,pVal)	\
    (This)->lpVtbl -> get_EmailAddress(This,pVal)

#define IContact_put_EmailAddress(This,newVal)	\
    (This)->lpVtbl -> put_EmailAddress(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_ID_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_ID_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_QuickName_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_QuickName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_QuickName_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_QuickName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_FirstName_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_FirstName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_FirstName_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_FirstName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_LastName_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_LastName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_LastName_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_LastName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_TelephoneNumber_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_TelephoneNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_TelephoneNumber_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_TelephoneNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_MobileNumber_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_MobileNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_MobileNumber_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_MobileNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_StreetAddress1_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_StreetAddress1_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_StreetAddress1_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_StreetAddress1_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_StreetAddress2_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_StreetAddress2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_StreetAddress2_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_StreetAddress2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_Town_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_Town_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_Town_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_Town_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_County_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_County_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_County_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_County_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_Postcode_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_Postcode_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_Postcode_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_Postcode_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_Country_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_Country_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_Country_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_Country_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_EmailAddress_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_EmailAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_EmailAddress_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_EmailAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IContact_INTERFACE_DEFINED__ */


#ifndef __IContactGroup_INTERFACE_DEFINED__
#define __IContactGroup_INTERFACE_DEFINED__

/* interface IContactGroup */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IContactGroup;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("17E0F07A-E3EB-47D2-A683-86C0EA7CDA8B")
    IContactGroup : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ID( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ID( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Name( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Name( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Description( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Description( 
            /* [in] */ BSTR newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IContactGroupVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IContactGroup * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IContactGroup * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IContactGroup * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IContactGroup * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IContactGroup * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IContactGroup * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IContactGroup * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ID )( 
            IContactGroup * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ID )( 
            IContactGroup * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Name )( 
            IContactGroup * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Name )( 
            IContactGroup * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Description )( 
            IContactGroup * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Description )( 
            IContactGroup * This,
            /* [in] */ BSTR newVal);
        
        END_INTERFACE
    } IContactGroupVtbl;

    interface IContactGroup
    {
        CONST_VTBL struct IContactGroupVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IContactGroup_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IContactGroup_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IContactGroup_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IContactGroup_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IContactGroup_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IContactGroup_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IContactGroup_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IContactGroup_get_ID(This,pVal)	\
    (This)->lpVtbl -> get_ID(This,pVal)

#define IContactGroup_put_ID(This,newVal)	\
    (This)->lpVtbl -> put_ID(This,newVal)

#define IContactGroup_get_Name(This,pVal)	\
    (This)->lpVtbl -> get_Name(This,pVal)

#define IContactGroup_put_Name(This,newVal)	\
    (This)->lpVtbl -> put_Name(This,newVal)

#define IContactGroup_get_Description(This,pVal)	\
    (This)->lpVtbl -> get_Description(This,pVal)

#define IContactGroup_put_Description(This,newVal)	\
    (This)->lpVtbl -> put_Description(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContactGroup_get_ID_Proxy( 
    IContactGroup * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContactGroup_get_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContactGroup_put_ID_Proxy( 
    IContactGroup * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContactGroup_put_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContactGroup_get_Name_Proxy( 
    IContactGroup * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContactGroup_get_Name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContactGroup_put_Name_Proxy( 
    IContactGroup * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContactGroup_put_Name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContactGroup_get_Description_Proxy( 
    IContactGroup * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContactGroup_get_Description_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContactGroup_put_Description_Proxy( 
    IContactGroup * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContactGroup_put_Description_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IContactGroup_INTERFACE_DEFINED__ */


#ifndef __IContactService_INTERFACE_DEFINED__
#define __IContactService_INTERFACE_DEFINED__

/* interface IContactService */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IContactService;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("7D90CD80-9E3F-48B7-89BE-75E9C4B824C3")
    IContactService : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Initialise( 
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetContacts( 
            /* [retval][out] */ IObjectCollection **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetGroups( 
            /* [retval][out] */ IObjectCollection **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddContact( 
            IContact *Contact,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddContacts( 
            IObjectCollection *Contacts,
            /* [retval][out] */ IStringCollection **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddGroup( 
            IContactGroup *Group,
            /* [optional] */ VARIANT Members,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteContact( 
            VARIANT Contact) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteContacts( 
            VARIANT Contacts) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteGroup( 
            VARIANT Groups,
            /* [optional] */ VARIANT IncludeMembers) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteGroups( 
            VARIANT Groups) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE UpdateContact( 
            IContact *Contact) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE UpdateGroup( 
            IContactGroup *Group,
            VARIANT Members) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetContact( 
            BSTR ID,
            /* [retval][out] */ IContact **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetGroup( 
            BSTR ID,
            /* [retval][out] */ IContactGroup **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetGroupMembers( 
            BSTR ID,
            /* [retval][out] */ IObjectCollection **pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IContactServiceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IContactService * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IContactService * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IContactService * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IContactService * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IContactService * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IContactService * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IContactService * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Initialise )( 
            IContactService * This,
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetContacts )( 
            IContactService * This,
            /* [retval][out] */ IObjectCollection **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetGroups )( 
            IContactService * This,
            /* [retval][out] */ IObjectCollection **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *AddContact )( 
            IContactService * This,
            IContact *Contact,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *AddContacts )( 
            IContactService * This,
            IObjectCollection *Contacts,
            /* [retval][out] */ IStringCollection **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *AddGroup )( 
            IContactService * This,
            IContactGroup *Group,
            /* [optional] */ VARIANT Members,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DeleteContact )( 
            IContactService * This,
            VARIANT Contact);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DeleteContacts )( 
            IContactService * This,
            VARIANT Contacts);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DeleteGroup )( 
            IContactService * This,
            VARIANT Groups,
            /* [optional] */ VARIANT IncludeMembers);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DeleteGroups )( 
            IContactService * This,
            VARIANT Groups);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *UpdateContact )( 
            IContactService * This,
            IContact *Contact);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *UpdateGroup )( 
            IContactService * This,
            IContactGroup *Group,
            VARIANT Members);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetContact )( 
            IContactService * This,
            BSTR ID,
            /* [retval][out] */ IContact **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetGroup )( 
            IContactService * This,
            BSTR ID,
            /* [retval][out] */ IContactGroup **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetGroupMembers )( 
            IContactService * This,
            BSTR ID,
            /* [retval][out] */ IObjectCollection **pVal);
        
        END_INTERFACE
    } IContactServiceVtbl;

    interface IContactService
    {
        CONST_VTBL struct IContactServiceVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IContactService_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IContactService_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IContactService_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IContactService_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IContactService_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IContactService_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IContactService_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IContactService_Initialise(This,Username,Password,Account,IsServerSide)	\
    (This)->lpVtbl -> Initialise(This,Username,Password,Account,IsServerSide)

#define IContactService_GetContacts(This,pVal)	\
    (This)->lpVtbl -> GetContacts(This,pVal)

#define IContactService_GetGroups(This,pVal)	\
    (This)->lpVtbl -> GetGroups(This,pVal)

#define IContactService_AddContact(This,Contact,pVal)	\
    (This)->lpVtbl -> AddContact(This,Contact,pVal)

#define IContactService_AddContacts(This,Contacts,pVal)	\
    (This)->lpVtbl -> AddContacts(This,Contacts,pVal)

#define IContactService_AddGroup(This,Group,Members,pVal)	\
    (This)->lpVtbl -> AddGroup(This,Group,Members,pVal)

#define IContactService_DeleteContact(This,Contact)	\
    (This)->lpVtbl -> DeleteContact(This,Contact)

#define IContactService_DeleteContacts(This,Contacts)	\
    (This)->lpVtbl -> DeleteContacts(This,Contacts)

#define IContactService_DeleteGroup(This,Groups,IncludeMembers)	\
    (This)->lpVtbl -> DeleteGroup(This,Groups,IncludeMembers)

#define IContactService_DeleteGroups(This,Groups)	\
    (This)->lpVtbl -> DeleteGroups(This,Groups)

#define IContactService_UpdateContact(This,Contact)	\
    (This)->lpVtbl -> UpdateContact(This,Contact)

#define IContactService_UpdateGroup(This,Group,Members)	\
    (This)->lpVtbl -> UpdateGroup(This,Group,Members)

#define IContactService_GetContact(This,ID,pVal)	\
    (This)->lpVtbl -> GetContact(This,ID,pVal)

#define IContactService_GetGroup(This,ID,pVal)	\
    (This)->lpVtbl -> GetGroup(This,ID,pVal)

#define IContactService_GetGroupMembers(This,ID,pVal)	\
    (This)->lpVtbl -> GetGroupMembers(This,ID,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_Initialise_Proxy( 
    IContactService * This,
    BSTR Username,
    BSTR Password,
    BSTR Account,
    /* [optional] */ VARIANT IsServerSide);


void __RPC_STUB IContactService_Initialise_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_GetContacts_Proxy( 
    IContactService * This,
    /* [retval][out] */ IObjectCollection **pVal);


void __RPC_STUB IContactService_GetContacts_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_GetGroups_Proxy( 
    IContactService * This,
    /* [retval][out] */ IObjectCollection **pVal);


void __RPC_STUB IContactService_GetGroups_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_AddContact_Proxy( 
    IContactService * This,
    IContact *Contact,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContactService_AddContact_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_AddContacts_Proxy( 
    IContactService * This,
    IObjectCollection *Contacts,
    /* [retval][out] */ IStringCollection **pVal);


void __RPC_STUB IContactService_AddContacts_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_AddGroup_Proxy( 
    IContactService * This,
    IContactGroup *Group,
    /* [optional] */ VARIANT Members,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContactService_AddGroup_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_DeleteContact_Proxy( 
    IContactService * This,
    VARIANT Contact);


void __RPC_STUB IContactService_DeleteContact_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_DeleteContacts_Proxy( 
    IContactService * This,
    VARIANT Contacts);


void __RPC_STUB IContactService_DeleteContacts_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_DeleteGroup_Proxy( 
    IContactService * This,
    VARIANT Groups,
    /* [optional] */ VARIANT IncludeMembers);


void __RPC_STUB IContactService_DeleteGroup_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_DeleteGroups_Proxy( 
    IContactService * This,
    VARIANT Groups);


void __RPC_STUB IContactService_DeleteGroups_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_UpdateContact_Proxy( 
    IContactService * This,
    IContact *Contact);


void __RPC_STUB IContactService_UpdateContact_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_UpdateGroup_Proxy( 
    IContactService * This,
    IContactGroup *Group,
    VARIANT Members);


void __RPC_STUB IContactService_UpdateGroup_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_GetContact_Proxy( 
    IContactService * This,
    BSTR ID,
    /* [retval][out] */ IContact **pVal);


void __RPC_STUB IContactService_GetContact_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_GetGroup_Proxy( 
    IContactService * This,
    BSTR ID,
    /* [retval][out] */ IContactGroup **pVal);


void __RPC_STUB IContactService_GetGroup_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_GetGroupMembers_Proxy( 
    IContactService * This,
    BSTR ID,
    /* [retval][out] */ IObjectCollection **pVal);


void __RPC_STUB IContactService_GetGroupMembers_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IContactService_INTERFACE_DEFINED__ */


#ifndef __ISignupCompletionElements_INTERFACE_DEFINED__
#define __ISignupCompletionElements_INTERFACE_DEFINED__

/* interface ISignupCompletionElements */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISignupCompletionElements;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("5CD56000-830A-4701-AFA5-C25C13C00669")
    ISignupCompletionElements : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Username( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Username( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_AccountReference( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_AccountReference( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_WelcomeMessage( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_WelcomeMessage( 
            /* [in] */ BSTR newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISignupCompletionElementsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISignupCompletionElements * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISignupCompletionElements * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISignupCompletionElements * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISignupCompletionElements * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISignupCompletionElements * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISignupCompletionElements * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISignupCompletionElements * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Username )( 
            ISignupCompletionElements * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Username )( 
            ISignupCompletionElements * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_AccountReference )( 
            ISignupCompletionElements * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_AccountReference )( 
            ISignupCompletionElements * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_WelcomeMessage )( 
            ISignupCompletionElements * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_WelcomeMessage )( 
            ISignupCompletionElements * This,
            /* [in] */ BSTR newVal);
        
        END_INTERFACE
    } ISignupCompletionElementsVtbl;

    interface ISignupCompletionElements
    {
        CONST_VTBL struct ISignupCompletionElementsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISignupCompletionElements_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISignupCompletionElements_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISignupCompletionElements_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISignupCompletionElements_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISignupCompletionElements_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISignupCompletionElements_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISignupCompletionElements_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISignupCompletionElements_get_Username(This,pVal)	\
    (This)->lpVtbl -> get_Username(This,pVal)

#define ISignupCompletionElements_put_Username(This,newVal)	\
    (This)->lpVtbl -> put_Username(This,newVal)

#define ISignupCompletionElements_get_AccountReference(This,pVal)	\
    (This)->lpVtbl -> get_AccountReference(This,pVal)

#define ISignupCompletionElements_put_AccountReference(This,newVal)	\
    (This)->lpVtbl -> put_AccountReference(This,newVal)

#define ISignupCompletionElements_get_WelcomeMessage(This,pVal)	\
    (This)->lpVtbl -> get_WelcomeMessage(This,pVal)

#define ISignupCompletionElements_put_WelcomeMessage(This,newVal)	\
    (This)->lpVtbl -> put_WelcomeMessage(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISignupCompletionElements_get_Username_Proxy( 
    ISignupCompletionElements * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISignupCompletionElements_get_Username_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISignupCompletionElements_put_Username_Proxy( 
    ISignupCompletionElements * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISignupCompletionElements_put_Username_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISignupCompletionElements_get_AccountReference_Proxy( 
    ISignupCompletionElements * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISignupCompletionElements_get_AccountReference_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISignupCompletionElements_put_AccountReference_Proxy( 
    ISignupCompletionElements * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISignupCompletionElements_put_AccountReference_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISignupCompletionElements_get_WelcomeMessage_Proxy( 
    ISignupCompletionElements * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISignupCompletionElements_get_WelcomeMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISignupCompletionElements_put_WelcomeMessage_Proxy( 
    ISignupCompletionElements * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISignupCompletionElements_put_WelcomeMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISignupCompletionElements_INTERFACE_DEFINED__ */


#ifndef __ISignupService_INTERFACE_DEFINED__
#define __ISignupService_INTERFACE_DEFINED__

/* interface ISignupService */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISignupService;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B8B6782A-0108-4CFA-BD0A-5C229A520398")
    ISignupService : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Initialise( 
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DefaultEvaluationSignup( 
            BSTR FirstName,
            BSTR LastName,
            BSTR CompanyName,
            BSTR TelephoneNumber,
            BSTR MobileNumber,
            BSTR EmailAddress,
            VARIANT_BOOL MailingAgreement,
            /* [retval][out] */ ISignupCompletionElements **pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISignupServiceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISignupService * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISignupService * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISignupService * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISignupService * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISignupService * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISignupService * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISignupService * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Initialise )( 
            ISignupService * This,
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DefaultEvaluationSignup )( 
            ISignupService * This,
            BSTR FirstName,
            BSTR LastName,
            BSTR CompanyName,
            BSTR TelephoneNumber,
            BSTR MobileNumber,
            BSTR EmailAddress,
            VARIANT_BOOL MailingAgreement,
            /* [retval][out] */ ISignupCompletionElements **pVal);
        
        END_INTERFACE
    } ISignupServiceVtbl;

    interface ISignupService
    {
        CONST_VTBL struct ISignupServiceVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISignupService_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISignupService_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISignupService_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISignupService_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISignupService_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISignupService_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISignupService_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISignupService_Initialise(This,Username,Password,Account,IsServerSide)	\
    (This)->lpVtbl -> Initialise(This,Username,Password,Account,IsServerSide)

#define ISignupService_DefaultEvaluationSignup(This,FirstName,LastName,CompanyName,TelephoneNumber,MobileNumber,EmailAddress,MailingAgreement,pVal)	\
    (This)->lpVtbl -> DefaultEvaluationSignup(This,FirstName,LastName,CompanyName,TelephoneNumber,MobileNumber,EmailAddress,MailingAgreement,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISignupService_Initialise_Proxy( 
    ISignupService * This,
    BSTR Username,
    BSTR Password,
    BSTR Account,
    /* [optional] */ VARIANT IsServerSide);


void __RPC_STUB ISignupService_Initialise_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISignupService_DefaultEvaluationSignup_Proxy( 
    ISignupService * This,
    BSTR FirstName,
    BSTR LastName,
    BSTR CompanyName,
    BSTR TelephoneNumber,
    BSTR MobileNumber,
    BSTR EmailAddress,
    VARIANT_BOOL MailingAgreement,
    /* [retval][out] */ ISignupCompletionElements **pVal);


void __RPC_STUB ISignupService_DefaultEvaluationSignup_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISignupService_INTERFACE_DEFINED__ */


#ifndef __ITestService_INTERFACE_DEFINED__
#define __ITestService_INTERFACE_DEFINED__

/* interface ITestService */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ITestService;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("D21D6F23-1E6D-4DDF-8FF0-C8DF771A8D68")
    ITestService : public IDispatch
    {
    public:
        virtual /* [helpstring][hidden][id] */ HRESULT STDMETHODCALLTYPE SetSoapEndPoints( 
            BSTR URI,
            BSTR MockURI) = 0;
        
        virtual /* [helpstring][restricted][hidden][id] */ HRESULT STDMETHODCALLTYPE SetupContactTests( void) = 0;
        
        virtual /* [helpstring][hidden][id] */ HRESULT STDMETHODCALLTYPE SetupAccountTests( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetupSendTests( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetupInboxTests( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetupSignupTests( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITestServiceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ITestService * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ITestService * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ITestService * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ITestService * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ITestService * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ITestService * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ITestService * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][hidden][id] */ HRESULT ( STDMETHODCALLTYPE *SetSoapEndPoints )( 
            ITestService * This,
            BSTR URI,
            BSTR MockURI);
        
        /* [helpstring][restricted][hidden][id] */ HRESULT ( STDMETHODCALLTYPE *SetupContactTests )( 
            ITestService * This);
        
        /* [helpstring][hidden][id] */ HRESULT ( STDMETHODCALLTYPE *SetupAccountTests )( 
            ITestService * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SetupSendTests )( 
            ITestService * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SetupInboxTests )( 
            ITestService * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SetupSignupTests )( 
            ITestService * This);
        
        END_INTERFACE
    } ITestServiceVtbl;

    interface ITestService
    {
        CONST_VTBL struct ITestServiceVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITestService_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITestService_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITestService_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITestService_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ITestService_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ITestService_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ITestService_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ITestService_SetSoapEndPoints(This,URI,MockURI)	\
    (This)->lpVtbl -> SetSoapEndPoints(This,URI,MockURI)

#define ITestService_SetupContactTests(This)	\
    (This)->lpVtbl -> SetupContactTests(This)

#define ITestService_SetupAccountTests(This)	\
    (This)->lpVtbl -> SetupAccountTests(This)

#define ITestService_SetupSendTests(This)	\
    (This)->lpVtbl -> SetupSendTests(This)

#define ITestService_SetupInboxTests(This)	\
    (This)->lpVtbl -> SetupInboxTests(This)

#define ITestService_SetupSignupTests(This)	\
    (This)->lpVtbl -> SetupSignupTests(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][hidden][id] */ HRESULT STDMETHODCALLTYPE ITestService_SetSoapEndPoints_Proxy( 
    ITestService * This,
    BSTR URI,
    BSTR MockURI);


void __RPC_STUB ITestService_SetSoapEndPoints_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][restricted][hidden][id] */ HRESULT STDMETHODCALLTYPE ITestService_SetupContactTests_Proxy( 
    ITestService * This);


void __RPC_STUB ITestService_SetupContactTests_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][hidden][id] */ HRESULT STDMETHODCALLTYPE ITestService_SetupAccountTests_Proxy( 
    ITestService * This);


void __RPC_STUB ITestService_SetupAccountTests_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITestService_SetupSendTests_Proxy( 
    ITestService * This);


void __RPC_STUB ITestService_SetupSendTests_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITestService_SetupInboxTests_Proxy( 
    ITestService * This);


void __RPC_STUB ITestService_SetupInboxTests_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITestService_SetupSignupTests_Proxy( 
    ITestService * This);


void __RPC_STUB ITestService_SetupSignupTests_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITestService_INTERFACE_DEFINED__ */


#ifndef __IMessengerService_INTERFACE_DEFINED__
#define __IMessengerService_INTERFACE_DEFINED__

/* interface IMessengerService */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IMessengerService;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("F1A54EDF-A417-4ADE-AA38-801BCD899664")
    IMessengerService : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetCurrentVersion( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IMessengerServiceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IMessengerService * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IMessengerService * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IMessengerService * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IMessengerService * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IMessengerService * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IMessengerService * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IMessengerService * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetCurrentVersion )( 
            IMessengerService * This,
            /* [retval][out] */ BSTR *pVal);
        
        END_INTERFACE
    } IMessengerServiceVtbl;

    interface IMessengerService
    {
        CONST_VTBL struct IMessengerServiceVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMessengerService_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMessengerService_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMessengerService_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMessengerService_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IMessengerService_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IMessengerService_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IMessengerService_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IMessengerService_GetCurrentVersion(This,pVal)	\
    (This)->lpVtbl -> GetCurrentVersion(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IMessengerService_GetCurrentVersion_Proxy( 
    IMessengerService * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IMessengerService_GetCurrentVersion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IMessengerService_INTERFACE_DEFINED__ */



#ifndef __EsendexLib_LIBRARY_DEFINED__
#define __EsendexLib_LIBRARY_DEFINED__

/* library EsendexLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_EsendexLib;

EXTERN_C const CLSID CLSID_SendService;

#ifdef __cplusplus

class DECLSPEC_UUID("D810C640-3F00-4F9E-A777-A555D450D188")
SendService;
#endif

EXTERN_C const CLSID CLSID_StringCollection;

#ifdef __cplusplus

class DECLSPEC_UUID("01A76035-0469-4F5A-BF51-6403EAFC62F5")
StringCollection;
#endif

EXTERN_C const CLSID CLSID_InboxService;

#ifdef __cplusplus

class DECLSPEC_UUID("7AA7EDC9-A1ED-4E20-91C9-97CE8FEF3043")
InboxService;
#endif

EXTERN_C const CLSID CLSID_AccountService;

#ifdef __cplusplus

class DECLSPEC_UUID("6964E153-7999-40B0-8A7D-05CDD4D6B7C0")
AccountService;
#endif

EXTERN_C const CLSID CLSID_SMSMessage;

#ifdef __cplusplus

class DECLSPEC_UUID("CF738D0B-581E-4757-BF40-66E989772830")
SMSMessage;
#endif

EXTERN_C const CLSID CLSID_SMSMessageCollection;

#ifdef __cplusplus

class DECLSPEC_UUID("3FDE8096-9DE5-4627-8A8E-B80CF0972A2D")
SMSMessageCollection;
#endif

EXTERN_C const CLSID CLSID_ContactService;

#ifdef __cplusplus

class DECLSPEC_UUID("FC4B1994-DE90-4655-85A8-AADE7C405261")
ContactService;
#endif

EXTERN_C const CLSID CLSID_SignupService;

#ifdef __cplusplus

class DECLSPEC_UUID("E566C526-B40F-4539-B3E2-F6A4C5911B87")
SignupService;
#endif

EXTERN_C const CLSID CLSID_ObjectCollection;

#ifdef __cplusplus

class DECLSPEC_UUID("A2A9134A-5B61-4785-9652-70635F5F67A8")
ObjectCollection;
#endif

EXTERN_C const CLSID CLSID_Contact;

#ifdef __cplusplus

class DECLSPEC_UUID("C4A0F7F2-5BA0-4EBE-AEE9-E65EA63330ED")
Contact;
#endif

EXTERN_C const CLSID CLSID_ContactGroup;

#ifdef __cplusplus

class DECLSPEC_UUID("CD076658-CC44-4FE3-A696-470B50BE2595")
ContactGroup;
#endif

EXTERN_C const CLSID CLSID_TestService;

#ifdef __cplusplus

class DECLSPEC_UUID("C8E14693-88CF-47C2-A802-159AD787545F")
TestService;
#endif

EXTERN_C const CLSID CLSID_SignupCompletionElements;

#ifdef __cplusplus

class DECLSPEC_UUID("3AAA4707-C4EE-441F-8F0F-9D87A9F9E8AC")
SignupCompletionElements;
#endif

EXTERN_C const CLSID CLSID_AccountState;

#ifdef __cplusplus

class DECLSPEC_UUID("DC986047-4EA9-4C08-9ACA-3935B53F8FC3")
AccountState;
#endif

EXTERN_C const CLSID CLSID_MessengerService;

#ifdef __cplusplus

class DECLSPEC_UUID("BFEE1DEB-E2E8-492B-A838-8F7CE4371AE2")
MessengerService;
#endif
#endif /* __EsendexLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long *, BSTR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long *, unsigned long            , VARIANT * ); 
unsigned char * __RPC_USER  VARIANT_UserMarshal(  unsigned long *, unsigned char *, VARIANT * ); 
unsigned char * __RPC_USER  VARIANT_UserUnmarshal(unsigned long *, unsigned char *, VARIANT * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long *, VARIANT * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


