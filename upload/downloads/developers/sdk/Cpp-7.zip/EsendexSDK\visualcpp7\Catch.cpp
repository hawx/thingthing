//Catch.cpp

#include "stdafx.h"
#include "EsendexSDK.h"
#include "Catch.h"
#include <sstream>
#include "resource.h"

HRESULT CatchAll(log4cpp::Category& log, LPCTSTR pszClass, LPCTSTR pszFunction, HRESULT hr)
{
	//Append the class and function to the new error information.
	USES_CONVERSION;
	std::wstringstream strDesc;
	strDesc << L"An error occurred.  " << A2W(pszClass) << L"::" << A2W(pszFunction) << std::ends;
	log.error("%S", strDesc.str().c_str());
	return hr;
}

void ReportMsxmlError(HRESULT hr, UINT nResId, LPCTSTR pszMethod)
{
	USES_CONVERSION;
	IErrorInfo* pInfo;
	if (SUCCEEDED(GetErrorInfo(0, &pInfo)) && pInfo)
	{
		CComBSTR bstrMessage;
		pInfo->GetDescription(&bstrMessage);
		pInfo->Release();
		if (bstrMessage!=NULL || wcslen(bstrMessage)>0)
		{
			ReportErrorVA(MAKE_HRESULT(SEVERITY_ERROR, FACILITY_DISPATCH, ERROR_CODE_CONNECTION_FAILED), nResId, pszMethod, W2A(bstrMessage));
			return;
		}
	}
	ReportErrorVA(MAKE_HRESULT(SEVERITY_ERROR, FACILITY_DISPATCH, ERROR_CODE_CONNECTION_FAILED), nResId, pszMethod, "");
}

void ReportErrorVA(HRESULT hr, UINT nResId, ...)
{
	va_list argList;
	va_start(argList, nResId);

	CComBSTR bstr;
	bstr.LoadString(nResId);

	USES_CONVERSION;
	char* pszMessage=NULL;
	/*
	DWORD dwChars = FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_HMODULE,
		_Module.GetResourceInstance(),
		nResId,
		0, //LOCALE_USER_DEFAULT,
		(TCHAR*)&pszMessage,
		0,
		&argList);
		*/

	DWORD dwChars = FormatMessage(FORMAT_MESSAGE_FROM_STRING|FORMAT_MESSAGE_ALLOCATE_BUFFER,
		W2A(bstr), 0, 0, (LPTSTR)&pszMessage, 0, &argList);

	//ATLASSERT(dwChars>0 && pszMessage);
	if (dwChars==0)
	{
		DWORD dwError = GetLastError();
	}

	AtlReportError(CLSID_NULL, pszMessage, 0, NULL, IID_NULL, hr);

	va_end(argList);

	if (pszMessage)
		LocalFree(pszMessage);

	throw (HRESULT)hr;
}

void ReportError(UINT nResId, HRESULT hr)
{
	CComBSTR bstr;
	bstr.LoadString(nResId);
	ReportError(bstr, hr);
}

void ReportError(LPCWSTR pwszError, HRESULT hr)
{
	AtlReportError(CLSID_NULL, pwszError, 0, NULL, IID_NULL, hr);
	throw (HRESULT)hr;
}

void ReportEmptyParamError(LPCTSTR pszParamName)
{
	ReportErrorVA(E_INVALIDARG, IDS_ERR_EMPTY_PARAM, pszParamName);
}

void ReportVariantMustBeStringError(LPCTSTR pszParamName)
{
	ReportErrorVA(E_INVALIDARG, IDS_ERR_VARIANT_NOT_STRING, pszParamName);
}

void ReportVariantMustBeIntError(LPCTSTR pszParamName)
{
	ReportErrorVA(E_INVALIDARG, IDS_ERR_VARIANT_NOT_INT, pszParamName);
}

void CheckVariantLongParam(LPCTSTR paramName, VARIANT& paramValue)
{
	if (paramValue.vt==VT_I2) 
	{ 
		paramValue.lVal = paramValue.iVal; 
		paramValue.vt=VT_I4; 
	} 
	else if (paramValue.vt==VT_INT) 
	{ 
		paramValue.lVal = paramValue.intVal; 
		paramValue.vt=VT_I4; 
	}
	else if (paramValue.vt==VT_BSTR) 
	{ 
		paramValue.lVal = _wtol(paramValue.bstrVal); 
		paramValue.vt=VT_I4;  
	}
	else if (paramValue.vt!=VT_I4) 
		ReportVariantMustBeIntError(paramName); 
}

void CheckVariantStringArrayParam(LPCTSTR pszParam, VARIANT& paramValue)
{
	if (paramValue.vt==VT_BSTR) 
		return;
	else if (paramValue.vt==VT_DISPATCH)
	{
		CComQIPtr<IStringCollection2> sp(paramValue.pdispVal);
		if (!sp)
			ReportErrorVA(E_INVALIDARG, IDS_ERR_VARIANT_NOT_STRING_COLLECTION, pszParam);
	}
}

void CheckVariantIdArrayParam(LPCTSTR pszParam, VARIANT& paramValue)
{
	if (paramValue.vt==VT_BSTR) 
		return;
	else if (paramValue.vt==VT_DISPATCH)
	{
		CComQIPtr<IStringCollection2> sp(paramValue.pdispVal);
		if (!sp)
		{
			CComQIPtr<IObjectCollection> sp2(paramValue.pdispVal);
			if (!sp2)
				ReportErrorVA(E_INVALIDARG, IDS_ERR_VARIANT_NOT_STRING_COLLECTION, pszParam);
		}
	}
	else
		ReportErrorVA(E_INVALIDARG, IDS_ERR_VARIANT_NOT_STRING_COLLECTION, pszParam);
}

void CheckVariantMessageParam(LPCTSTR pszParam, VARIANT& paramValue)
{
	if (paramValue.vt==VT_BSTR) 
		return;
	else if (paramValue.vt==VT_DISPATCH)
	{
		CComQIPtr<ISMSMessage2> sp(paramValue.pdispVal);
		if (sp)
		{
			CComBSTR bstrMessageID;
			sp->get_ID(&bstrMessageID);
			paramValue.bstrVal = bstrMessageID.Detach();
			paramValue.vt = VT_BSTR;
		}
		else
			ReportErrorVA(E_INVALIDARG, IDS_ERR_VARIANT_NOT_MESSAGE, pszParam);
	}
}

void CheckVariantDomainObjectParam(LPCTSTR pszParam, VARIANT& paramValue, int nErrorResID)
{
	if (paramValue.vt==VT_BSTR) 
		return;
	else if (paramValue.vt==VT_DISPATCH)
	{
		CComQIPtr<IDomainObject> sp(paramValue.pdispVal);
		if (sp)
		{
			CComBSTR bstrID;
			sp->get_ID(&bstrID);
			paramValue.bstrVal = bstrID.Detach();
			paramValue.vt = VT_BSTR;
		}
		else
			ReportErrorVA(E_INVALIDARG, nErrorResID, pszParam);
	}
}

