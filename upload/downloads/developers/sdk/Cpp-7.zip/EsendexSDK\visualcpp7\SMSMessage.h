// SMSMessage.h : Declaration of the CSMSMessage

#ifndef __SMSMESSAGE_H_
#define __SMSMESSAGE_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSMSMessage
class ATL_NO_VTABLE CSMSMessage : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSMSMessage, &CLSID_SMSMessage2>,
	public ISupportErrorInfo,
	public IDispatchImpl<ISMSMessage2, &IID_ISMSMessage2, &LIBID_EsendexLib, 2>
{
public:
	CSMSMessage()
	{
		INIT_CLASS("CSMSMessage");
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SMSMESSAGE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSMSMessage)
	COM_INTERFACE_ENTRY(ISMSMessage2)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ISMSMessage
public:
	STDMETHOD(get_MessageIndex)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_MessageIndex)(/*[in]*/ long newVal);
	STDMETHOD(get_Username)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Username)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Status)(/*[out, retval]*/ MESSAGE_STATUS *pVal);
	STDMETHOD(put_Status)(/*[in]*/ MESSAGE_STATUS newVal);
	STDMETHOD(get_Type)(/*[out, retval]*/ MESSAGE_TYPE *pVal);
	STDMETHOD(put_Type)(/*[in]*/ MESSAGE_TYPE newVal);
	STDMETHOD(get_ReceivedAt)(/*[out, retval]*/ DATE *pVal);
	STDMETHOD(put_ReceivedAt)(/*[in]*/ DATE newVal);
	STDMETHOD(get_SentAt)(/*[out, retval]*/ DATE *pVal);
	STDMETHOD(put_SentAt)(/*[in]*/ DATE newVal);
	STDMETHOD(get_Body)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Body)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Recipient)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Recipient)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Originator)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Originator)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_ID)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_ID)(/*[in]*/ BSTR newVal);

	DECLARE_CLASS;

	CComBSTR m_bstrUsername;
	MESSAGE_STATUS m_messageStatus;
	MESSAGE_TYPE m_messageType;
	DATE m_receivedAt;
	DATE m_sentAt;
	CComBSTR m_bstrBody;
	CComBSTR m_bstrRecipient;
	CComBSTR m_bstrOriginator;
	CComBSTR m_bstrMessageID;
	long m_iMessageIndex;
};

#endif //__SMSMESSAGE_H_
