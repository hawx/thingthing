// SMSMessageCollection.h : Declaration of the CSMSMessageCollection

#ifndef __SMSMESSAGES_H_
#define __SMSMESSAGES_H_

#include "resource.h"       // main symbols

#include <vector>

/////////////////////////////////////////////////////////////////////////////
// CSMSMessages
class ATL_NO_VTABLE CSMSMessageCollection : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSMSMessageCollection, &CLSID_SMSMessageCollection>,
	public ISupportErrorInfo,
	public IDispatchImpl<ISMSMessageCollection, &IID_ISMSMessageCollection, &LIBID_EsendexLib>,
	public IEnumVARIANT
{
public:
	CSMSMessageCollection()
	{
		INIT_CLASS("CSMSMessageCollection");
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SMSMESSAGECOLLECTION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSMSMessageCollection)
	COM_INTERFACE_ENTRY(ISMSMessageCollection)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IEnumVARIANT)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ISMSMessages
public:
	STDMETHOD(get__NewEnum)(IUnknown** pVal);
	STDMETHOD(get_Item)(VARIANT Index, /*[out, retval]*/ ISMSMessage* *pVal);
	STDMETHOD(put_Item)(VARIANT Index, /*[in]*/ ISMSMessage* newVal);
	STDMETHOD(Add)(ISMSMessage* newVal);
	STDMETHOD(Remove)(VARIANT Index);
	STDMETHOD(get_Count)(long* pVal);

//IEnumVARIANT
	STDMETHOD(Next)(ULONG celt, VARIANT*, ULONG* pceltFetched);
	STDMETHOD(Skip)(ULONG celt);
	STDMETHOD(Reset)(void);
	STDMETHOD(Clone)(IEnumVARIANT** pVal);

	DECLARE_CLASS;

	typedef CComPtr<ISMSMessage> ItemType;
	typedef std::vector< ItemType >	ContainerType;
	ContainerType m_coll;
	ContainerType::iterator m_iter;
};

#endif //__SMSMESSAGES_H_
