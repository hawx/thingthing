//Catch.h

#pragma once

//Retrieve any IErrorInfo and append the function name and class name
//so we get a stack trace built up as we go along.
#define ESENDEX_CATCH_ALL() \
	catch(HRESULT hr) { \
		return CatchAll(log, m_pszClassName, pszMethodName, hr); \
	} \
	catch(...) { \
		return CatchAll(log, m_pszClassName, pszMethodName, E_FAIL); \
	} \
	log.debug("Exiting %s::%s", m_pszClassName, pszMethodName);

HRESULT CatchAll(log4cpp::Category& log, LPCTSTR pszClassName, LPCTSTR pszFunction, HRESULT hr);

#define CHECK_PTR(ptr) if (ptr==NULL) throw (HRESULT)E_INVALIDARG;
#define CHECK_INIT_PTR(ptr) if (ptr==NULL) throw (HRESULT)E_INVALIDARG; else *ptr = NULL;
#define CHECK_HR(hr) { HRESULT hresult = hr; if (hresult!=S_OK) throw (HRESULT)hresult; }

#define CHECK_PARAM(paramName, paramValue) if (paramValue==NULL) ReportEmptyParamError(paramName); else log.debug("%s=%s", paramName, paramValue);

#define CHECK_STRING_PARAM(paramName, paramValue) if (paramValue==NULL || wcslen(paramValue)==0)  \
		ReportEmptyParamError(paramName); 

#define CHECK_VARIANT_STRING_PARAM(paramName, paramValue) if (paramValue.vt!=VT_BSTR) \
		ReportVariantMustBeStringError(paramName); \
	CHECK_STRING_PARAM(paramName, paramValue.bstrVal);

#define CHECK_VARIANT_STRING_ARRAY_PARAM(paramName, paramValue) CheckVariantStringArrayParam(paramName, paramValue);

#define CHECK_VARIANT_MESSAGE_PARAM(paramName, paramValue) CheckVariantMessageParam(paramName, paramValue);

#define CHECK_VARIANT_CONTACT_PARAM(paramName, paramValue) CheckVariantDomainObjectParam(paramName, paramValue, IDS_ERR_VARIANT_NOT_CONTACT);

#define CHECK_VARIANT_GROUP_PARAM(paramName, paramValue) CheckVariantDomainObjectParam(paramName, paramValue, IDS_ERR_VARIANT_NOT_GROUP);

#define CHECK_VARIANT_LONG_PARAM(paramName, paramValue) CheckVariantLongParam(paramName, paramValue);

#define CHECK_VARIANT_ID_ARRAY_PARAM(paramName, paramValue) CheckVariantIdArrayParam(paramName, paramValue);

void ReportEmptyParamError(LPCTSTR pszParamName);
void ReportVariantMustBeStringError(LPCTSTR pszParamName);
void ReportVariantMustBeIntError(LPCTSTR pszParamName);
void ReportErrorVA(HRESULT hr, UINT nResId, ...);
void ReportError(LPCWSTR pszError, HRESULT hr=E_FAIL);
void ReportError(UINT nResId, HRESULT hr=E_FAIL);
void CheckVariantStringArrayParam(LPCTSTR pszParam, VARIANT& paramValue);
void CheckVariantMessageParam(LPCTSTR pszParam, VARIANT& paramValue);
void CheckVariantDomainObjectParam(LPCTSTR pszParam, VARIANT& paramValue, int nErrorResID);
void CheckVariantStringOrMessageArrayParam(LPCTSTR pszParam, VARIANT& paramValue);
void CheckVariantIdArrayParam(LPCTSTR pszParam, VARIANT& paramValue);
void CheckVariantLongParam(LPCTSTR pszParam, VARIANT& paramValue);
void ReportMsxmlError(HRESULT hr, UINT nResId, LPCTSTR pszMethod);