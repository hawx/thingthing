//CResource.h

#pragma once

#include <string>

class CResource
{
public:
	CResource();
	HRESULT Load(LPCTSTR pszResource, LPCTSTR pszType);
	HRESULT Load(UINT nResource, LPCTSTR pszType);

	HRESULT GetString(std::string& str);
	HRESULT GetBSTR(_bstr_t& buffer);
	HRESULT Extract(LPCTSTR pszFileName); 	

	operator HRSRC() { return m_hrsrc; }
private:
	HRSRC m_hrsrc;
	void* m_pResource;
	
	DECLARE_CLASS;
};

