// InboxService.cpp : Implementation of CInboxService
#include "stdafx.h"
#include "EsendexSDK.h"
#include "InboxService.h"
#include "XmlUtils.h"
#include "Utils.h"

/////////////////////////////////////////////////////////////////////////////
// CInboxService

STDMETHODIMP CInboxService::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IInboxService2
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CInboxService::Initialise(BSTR UserName, BSTR Password, BSTR Account, VARIANT IsServerSide)
{
	return CSOAPService::Initialise(UserName, Password, Account, IsServerSide);
}

STDMETHODIMP CInboxService::DeleteMessage(BSTR MessageID)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("DeleteMessage"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_PARAM("MessageID", MessageID);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_DELETE_MESSAGE)));

		//Set the value of the elements in the XML.
		CXmlUtils::SetElementValue(spDoc, L"id", MessageID);
	
		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CInboxService::DeleteMessages(BSTR MessageIDs)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("DeleteMessages"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_PARAM("MessageIDs", MessageIDs);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_DELETE_MESSAGES)));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementArrayValue(spDoc, L"ids", MessageIDs);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CInboxService::GetMessages(IObjectCollection **pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetMessages"); 
	try
	{
		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_MESSAGES)));

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result.
		//CXmlUtils::GetElementArrayValue(spDoc, L"GetMessagesResult", pVal);

		//Get the result node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"GetMessagesResult");

		CHECK_HR(GetMessagesFromResult(spNode, pVal));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CInboxService::GetMessage(BSTR MessageID, ISMSMessage2** pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetMessageByID"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_PARAM("MessageID", MessageID);


		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_MESSAGE_BY_ID)));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementValue(spDoc, L"id", MessageID);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"GetMessageByIDResult");

		CHECK_HR(GetMessageFromNode(spNode, pVal));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CInboxService::GetMessagesForDay(long Year, long Month, long Day, IObjectCollection** pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetMessagesForDay"); 
	try
	{
		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_MESSAGES_FOR_DAY)));

		CXmlUtils::SetElementValue(spDoc, L"day", Day);
		CXmlUtils::SetElementValue(spDoc, L"month", Month);
		CXmlUtils::SetElementValue(spDoc, L"year", Year);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"GetMessagesForDayResult");

		CHECK_HR(GetMessagesFromResult(spNode, pVal));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

HRESULT	CInboxService::GetMessagesFromResult(MSXML::IXMLDOMNodePtr spNode, IObjectCollection** pVal)
{
		//Create a messages collection to hold the return values.
		CComPtr<IObjectCollection> spMessages;
		CHECK_HR(spMessages.CoCreateInstance(__uuidof(ObjectCollection)));

		//Get the child values.
		MSXML::IXMLDOMNodePtr spMessageXML = spNode->firstChild;
		while(spMessageXML)
		{
			//Create a message object.
			CComPtr<ISMSMessage2> spMessage;
			GetMessageFromNode(spMessageXML, &spMessage);

			spMessages->Add(spMessage);
			
			spMessageXML = spMessageXML->nextSibling;
		}

	*pVal = spMessages.Detach();
	return S_OK;
}

HRESULT CInboxService::GetMessageFromNode(MSXML::IXMLDOMNodePtr spMessageElement, ISMSMessage2** pVal)
{
	//Create a message object.
	CComPtr<ISMSMessage2> spMessage;
	CHECK_HR(spMessage.CoCreateInstance(__uuidof(SMSMessage2)));

	spMessageElement = spMessageElement->firstChild;
	while (spMessageElement!=NULL)
	{
		if (wcscmp(spMessageElement->baseName, L"id")==0)
			spMessage->put_ID(spMessageElement->text);
		else if (wcscmp(spMessageElement->baseName, L"originator")==0)
			spMessage->put_Originator(spMessageElement->text);
		else if (wcscmp(spMessageElement->baseName, L"recipient")==0)
			spMessage->put_Recipient(spMessageElement->text);
		else if (wcscmp(spMessageElement->baseName, L"body")==0)
			spMessage->put_Body(spMessageElement->text);
		else if (wcscmp(spMessageElement->baseName, L"sentat")==0)
		{
			spMessage->put_SentAt(CXmlUtils::ParseDate(spMessageElement->text));
		}
		else if (wcscmp(spMessageElement->baseName, L"receivedat")==0)
		{
			spMessage->put_ReceivedAt(CXmlUtils::ParseDate(spMessageElement->text));
		}
		else if (wcscmp(spMessageElement->baseName, L"type")==0)
			spMessage->put_Type(StringToMessageType(spMessageElement->text));
		else if (wcscmp(spMessageElement->baseName, L"status")==0)
			spMessage->put_Status(StringToMessageStatus(spMessageElement->text));
		else if (wcscmp(spMessageElement->baseName, L"username")==0)
			spMessage->put_Username(spMessageElement->text);
		else if (wcscmp(spMessageElement->baseName, L"messageIndex")==0)
			spMessage->put_MessageIndex(_wtol(spMessageElement->text));
		else
			ATLASSERT(!"Unknown message field");
		spMessageElement = spMessageElement->nextSibling;
	}
	*pVal = spMessage.Detach();
	return S_OK;
}

STDMETHODIMP CInboxService::GetMessagesForDateRange(DATE StartDate, DATE EndDate, IObjectCollection** pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetMessagesForDateRange"); 
	try
	{
		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_MESSAGES_FOR_DATE_RANGE)));

		CComBSTR bstrStartDate;
		CComBSTR bstrEndDate;
		CXmlUtils::StoreDate(StartDate, &bstrStartDate);
		CXmlUtils::StoreDate(EndDate, &bstrEndDate);
		CXmlUtils::SetElementValue(spDoc, L"startDate", bstrStartDate);
		CXmlUtils::SetElementValue(spDoc, L"endDate", bstrEndDate);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"GetMessagesForDateRangeResult");

		CHECK_HR(GetMessagesFromResult(spNode, pVal));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CInboxService::GetMessagesByID(BSTR Messages, IObjectCollection** pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetMessagesByID"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_PARAM("MessageIDs", Messages);

		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_MESSAGES_BY_ID)));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementArrayValue(spDoc, L"ids", Messages);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"GetMessagesByIDResult");

		CHECK_HR(GetMessagesFromResult(spNode, pVal));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CInboxService::GetLatestMessages(VARIANT LastMessageIndex, VARIANT MaxMessages, IObjectCollection** pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetLatestMessages"); 
	try
	{
		//Use CHECK_STRING_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		long iLastMessageIndex;
		if (LastMessageIndex.vt==VT_EMPTY || LastMessageIndex.vt==VT_ERROR)
			iLastMessageIndex = -1;
		else
			iLastMessageIndex = GetLongFromVariant(LastMessageIndex);

		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_LATEST_MESSAGES)));

		CXmlUtils::SetElementValue(spDoc, L"lastMessageIndex", iLastMessageIndex);

		if (MaxMessages.vt!=VT_I4)
			CXmlUtils::SetElementValue(spDoc, L"maxMessages", (long)MaxMessages.lVal);
		else if (MaxMessages.vt!=VT_I2)
			CXmlUtils::SetElementValue(spDoc, L"maxMessages", (long)MaxMessages.iVal);
		else 
			CXmlUtils::SetElementValue(spDoc, L"maxMessages", (long)100);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"GetLatestMessagesResult");

		CHECK_HR(GetMessagesFromResult(spNode, pVal));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

