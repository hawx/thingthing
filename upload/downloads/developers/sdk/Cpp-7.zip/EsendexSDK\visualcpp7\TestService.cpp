// TestService.cpp : Implementation of CTestService
#include "stdafx.h"
#include "EsendexSDK.h"
#include "TestService.h"
#include "XmlUtils.h"

/////////////////////////////////////////////////////////////////////////////
// CTestService

STDMETHODIMP CTestService::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ITestService
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

HRESULT CTestService::SetupTests(LPCTSTR pszSoapMethodName)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE(pszSoapMethodName); 
	try
	{
		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_SETUP_TESTS)));

		//Rename the SetupTests node by cloning it.
		MSXML::IXMLDOMNodePtr spSetupTestsNode = CXmlUtils::GetElementByName(spDoc, L"SetupTests");
		if (spSetupTestsNode==NULL)
			ReportErrorVA(E_FAIL, IDS_ERR_ELEMENT_NOT_FOUND, "SetupTests");

		MSXML::IXMLDOMNodePtr spNewNode = 
			spDoc->createNode((long)MSXML::NODE_ELEMENT, _bstr_t(pszSoapMethodName), spSetupTestsNode->namespaceURI);
		spSetupTestsNode->parentNode->replaceChild(spNewNode, spSetupTestsNode);

		//Post the XML to the server.
		CHECK_HR(ExecuteNoHeader(spDoc, pszSoapMethodName));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CTestService::SetSoapEndPoints(BSTR URI, BSTR MockURI)
{
	CSOAPService::SetSoapEndPoints(URI, MockURI);
	return S_OK;
}

STDMETHODIMP CTestService::SetupContactTests()
{
	return SetupTests("SetupContactTests");
}

STDMETHODIMP CTestService::SetupAccountTests()
{
	return SetupTests("SetupAccountTests");
}

STDMETHODIMP CTestService::SetupSendTests()
{
	return SetupTests("SetupSendTests");
}

STDMETHODIMP CTestService::SetupInboxTests()
{
	return SetupTests("SetupInboxTests");
}

STDMETHODIMP CTestService::SetupSignupTests()
{
	return SetupTests("SetupSignupTests");
}
