// SOAPService.h: interface for the SOAPService class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SOAPSERVICE_H__E06D8313_F28E_4003_BE76_EA833AF74304__INCLUDED_)
#define AFX_SOAPSERVICE_H__E06D8313_F28E_4003_BE76_EA833AF74304__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSOAPService  
{
public:
	static std::wstring m_wstrSoapEndPoint;
	static std::wstring m_wstrSoapEndPointMock;
	static void SetSoapEndPoints(BSTR bstrURI, BSTR bstrMockURI);

	HRESULT Initialise(BSTR Username, BSTR Password, BSTR Account, VARIANT IsServerSide);
	HRESULT Execute(MSXML::IXMLDOMDocumentPtr& spDoc, LPCTSTR pszMethod);
	HRESULT ExecuteNoHeader(MSXML::IXMLDOMDocumentPtr& spDoc, LPCTSTR pszMethod);
	HRESULT Execute(MSXML::IXMLDOMDocumentPtr& spDoc, LPCTSTR pwszMethod, bool fUsesHeader);
	
	CSOAPService(LPCWSTR pwszService);
	CSOAPService(LPCWSTR pwszService, bool fUseMockEndPoint);
	virtual ~CSOAPService();

private:
	std::wstring m_wstrService;
	bool m_fUseMockEndPoint;
	static const LPCWSTR CSOAPService::m_wstrNamespace;

	_bstr_t m_bstrUsername;
	_bstr_t m_bstrPassword;
	_bstr_t m_bstrAccount;
	VARIANT_BOOL m_bIsServerSide;
	void ReportSoapError(LPCWSTR pwszErrorMessage, LPCWSTR pwszErrorCode);

	DECLARE_CLASS;
};

#endif // !defined(AFX_SOAPSERVICE_H__E06D8313_F28E_4003_BE76_EA833AF74304__INCLUDED_)
