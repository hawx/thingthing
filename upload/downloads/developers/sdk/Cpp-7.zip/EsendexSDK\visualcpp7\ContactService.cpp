// ContactService.cpp : Implementation of CContactService
#include "stdafx.h"
#include "EsendexSDK.h"
#include "ContactService.h"
#include "XmlUtils.h"
#include "Contact.h"
#include "ContactGroup.h"
#include "Utils.h"

/////////////////////////////////////////////////////////////////////////////
// CContactService

STDMETHODIMP CContactService::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IContactService
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CContactService::Initialise(BSTR UserName, BSTR Password, BSTR Account, VARIANT IsServerSide)
{
	return CSOAPService::Initialise(UserName, Password, Account, IsServerSide);
}

STDMETHODIMP CContactService::GetContacts(IObjectCollection **pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetContacts"); 
	try
	{
		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_CONTACTS)));

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"GetContactsResult");

		CHECK_HR(GetObjectCollectionFromResult(OBJECT_TYPE_CONTACT, spNode, pVal));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CContactService::GetContact(BSTR ID, IContact **pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetContact"); 
	try
	{
		//Use CHECK_STRING_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_STRING_PARAM("ID", ID);

		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_CONTACT)));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementValue(spDoc, L"id", ID);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"GetContactResult");
		if (spNode==NULL)
			*pVal = NULL;
		else
			CHECK_HR(GetContactFromNode(spNode, (LPDISPATCH*)pVal));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CContactService::GetContactByQuickName(BSTR Name, IContact **pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetContactByQuickName"); 
	try
	{
		//Use CHECK_STRING_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_STRING_PARAM("Name", Name);

		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_CONTACT_BY_NAME)));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementValue(spDoc, L"name", Name);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"GetContactByQuickNameResult");
		if (spNode==NULL)
			*pVal = NULL;
		else
			CHECK_HR(GetContactFromNode(spNode, (LPDISPATCH*)pVal));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

HRESULT	CContactService::GetObjectCollectionFromResult(OBJECT_TYPE type, MSXML::IXMLDOMNodePtr spResultNode, IObjectCollection** pVal)
{
	//Create a collection to hold the return values.
	CComPtr<IObjectCollection> spObjects;
	CHECK_HR(spObjects.CoCreateInstance(__uuidof(ObjectCollection)));

	//Get the child values.
	MSXML::IXMLDOMNodePtr spObjectNode = spResultNode->firstChild;
	while(spObjectNode)
	{
		CComPtr<IDispatch> spObject;
		if (type==OBJECT_TYPE_CONTACT)
			GetContactFromNode(spObjectNode, &spObject);
		else if (type==OBJECT_TYPE_GROUP)
			GetGroupFromNode(spObjectNode, &spObject);

		spObjects->Add(spObject);
		
		spObjectNode = spObjectNode->nextSibling;
	}

	*pVal = spObjects.Detach();
	return S_OK;
}

HRESULT	CContactService::GetIDsFromResult(MSXML::IXMLDOMNodePtr spResultNode, IStringCollection2** pVal)
{
	//Create a collection to hold the return values.
	CComPtr<IStringCollection2> spIDs;
	CHECK_HR(spIDs.CoCreateInstance(__uuidof(StringCollection2)));

	//Get the child values.
	MSXML::IXMLDOMNodePtr spIDNode = spResultNode->firstChild;
	while(spIDNode)
	{
		spIDs->Add(spIDNode->text);
		spIDNode = spIDNode->nextSibling;
	}

	*pVal = spIDs.Detach();
	return S_OK;
}

HRESULT CContactService::GetContactFromNode(MSXML::IXMLDOMNodePtr spContactNode, IDispatch** pVal)
{
	CComPtr<IContact> spContact;
	CHECK_HR(spContact.CoCreateInstance(__uuidof(Contact)));

	MSXML::IXMLDOMNodePtr spXmlElement = spContactNode->firstChild;
	while (spXmlElement!=NULL)
	{
		if (wcscmp(spXmlElement->baseName, L"ID")==0)
			spContact->put_ID(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"QuickName")==0)
			spContact->put_QuickName(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"FirstName")==0)
			spContact->put_FirstName(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"LastName")==0)
			spContact->put_LastName(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"TelephoneNumber")==0)
			spContact->put_TelephoneNumber(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"MobileNumber")==0)
			spContact->put_MobileNumber(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"StreetAddress1")==0)
			spContact->put_StreetAddress1(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"StreetAddress2")==0)
			spContact->put_StreetAddress2(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"Town")==0)
			spContact->put_Town(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"County")==0)
			spContact->put_County(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"Postcode")==0)
			spContact->put_Postcode(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"Country")==0)
			spContact->put_Country(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"EmailAddress")==0)
			spContact->put_EmailAddress(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"ContactType")==0)
			spContact->put_ContactType(StringToContactType(spXmlElement->text));
		
		spXmlElement = spXmlElement->nextSibling;
	}
	*pVal = spContact.Detach();
	return S_OK;
}

HRESULT CContactService::GetGroupFromNode(MSXML::IXMLDOMNodePtr spGroupNode, IDispatch** pVal)
{
	CComPtr<IContactGroup> spGroup;
	CHECK_HR(spGroup.CoCreateInstance(__uuidof(ContactGroup)));

	MSXML::IXMLDOMNodePtr spXmlElement = spGroupNode->firstChild;
	while (spXmlElement!=NULL)
	{
		if (wcscmp(spXmlElement->baseName, L"ID")==0)
			spGroup->put_ID(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"Name")==0)
			spGroup->put_Name(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"Description")==0)
			spGroup->put_Description(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"GroupType")==0)
			spGroup->put_GroupType(StringToGroupType(spXmlElement->text));
		
		spXmlElement = spXmlElement->nextSibling;
	}
	*pVal = spGroup.Detach();
	return S_OK;
}

STDMETHODIMP CContactService::GetGroups(IObjectCollection **pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetGroups"); 
	try
	{
		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_GROUPS)));

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"GetGroupsResult");

		CHECK_HR(GetObjectCollectionFromResult(OBJECT_TYPE_GROUP, spNode, pVal));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CContactService::GetGroup(BSTR ID, IContactGroup **pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetGroup"); 
	try
	{
		//Use CHECK_STRING_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_STRING_PARAM("ID", ID);

		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_GROUP)));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementValue(spDoc, L"id", ID);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"GetGroupResult");
		if (spNode==NULL)
			*pVal = NULL;
		else
			CHECK_HR(GetGroupFromNode(spNode, (LPDISPATCH*)pVal));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CContactService::GetGroupByName(BSTR Name, IContactGroup **pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetGroupByName"); 
	try
	{
		//Use CHECK_STRING_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_STRING_PARAM("Name", Name);

		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_GROUP_BY_NAME)));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementValue(spDoc, L"name", Name);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"GetGroupByNameResult");
		if (spNode==NULL)
			*pVal = NULL;
		else
			CHECK_HR(GetGroupFromNode(spNode, (LPDISPATCH*)pVal));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CContactService::AddContacts(IObjectCollection* Contacts, IStringCollection2** pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("AddContacts"); 
	try
	{
		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_ADD_CONTACTS)));

		//Get the contacts node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"contacts");

		//Delete the node's children.
		CXmlUtils::DeleteNodeChildren(spNode);

		long iCount;
		CHECK_HR(Contacts->get_Count(&iCount));
		for (long i=1; i<=iCount; i++)
		{
			//Get the contact.
			CComPtr<IContact> spContact;
			CHECK_HR(Contacts->get_Item(i, (LPDISPATCH*)&spContact));

			//Create an XML node for the contact.
			MSXML::IXMLDOMNodePtr spChildNode = 
				spDoc->createNode((long)MSXML::NODE_ELEMENT, L"Contact", spNode->namespaceURI);
			spNode->appendChild(spChildNode);

			//Add the contact elements below the new contact node.
			CHECK_HR(AddContactElements(spDoc, spChildNode, spContact));
		}

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result node.
		spNode = CXmlUtils::GetElementByName(spDoc, L"AddContactsResult");

		CHECK_HR(GetIDsFromResult(spNode, pVal));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

HRESULT CContactService::AddContactElements(MSXML::IXMLDOMDocumentPtr spDoc, MSXML::IXMLDOMNodePtr spContactNode, IContact* pContact)
{
	//Get a local interface on the contact so we don't
	//have to go through COM to get every property.
	CComQIPtr<ILocalObject> spLocalObject(pContact);
	if (spLocalObject==NULL)
		ReportError(IDS_ERR_OBJECT_NOT_LOCAL);
	CContact* pContactLocal;
	CHECK_HR(spLocalObject->GetLocalObject((LPUNKNOWN*)&pContactLocal));

	CXmlUtils::AddTextElement(spDoc, spContactNode, L"ID", pContactLocal->m_bstrID);
	CXmlUtils::AddTextElement(spDoc, spContactNode, L"QuickName", pContactLocal->m_bstrQuickName);
	CXmlUtils::AddTextElement(spDoc, spContactNode, L"FirstName", pContactLocal->m_bstrFirstName);
	CXmlUtils::AddTextElement(spDoc, spContactNode, L"LastName", pContactLocal->m_bstrLastName);
	CXmlUtils::AddTextElement(spDoc, spContactNode, L"TelephoneNumber", pContactLocal->m_bstrTelephoneNumber);
	CXmlUtils::AddTextElement(spDoc, spContactNode, L"MobileNumber", pContactLocal->m_bstrMobileNumber);
	CXmlUtils::AddTextElement(spDoc, spContactNode, L"StreetAddress1", pContactLocal->m_bstrStreetAddress1);
	CXmlUtils::AddTextElement(spDoc, spContactNode, L"StreetAddress2", pContactLocal->m_bstrStreetAddress2);
	CXmlUtils::AddTextElement(spDoc, spContactNode, L"Town", pContactLocal->m_bstrTown);
	CXmlUtils::AddTextElement(spDoc, spContactNode, L"County", pContactLocal->m_bstrCounty);
	CXmlUtils::AddTextElement(spDoc, spContactNode, L"Country", pContactLocal->m_bstrCountry);
	CXmlUtils::AddTextElement(spDoc, spContactNode, L"Postcode", pContactLocal->m_bstrPostcode);
	CXmlUtils::AddTextElement(spDoc, spContactNode, L"EmailAddress", pContactLocal->m_bstrEmailAddress);
	CXmlUtils::AddTextElement(spDoc, spContactNode, L"ContactType", ContactTypeToString(pContactLocal->m_contactType));

	return S_OK;
}


STDMETHODIMP CContactService::AddContact(IContact *Contact, BSTR* pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("AddContact"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_PARAM("Contact", Contact);

		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_ADD_CONTACT)));

		//Get the contact node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"contact");

		//Delete the node's children.
		CXmlUtils::DeleteNodeChildren(spNode);

		//Add the contact elements below the new contact node.
		CHECK_HR(AddContactElements(spDoc, spNode, Contact));

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result.
		_bstr_t bstrResult = CXmlUtils::GetElementValue(spDoc, L"AddContactResult");

		//Return the result to the caller.
		*pVal = bstrResult.copy();
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CContactService::AddGroup(IContactGroup *Group, BSTR MemberIDs, BSTR* pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("AddGroup"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_PARAM("Group", Group);

		//Members can be null
		//CHECK_VARIANT_STRING_ARRAY_PARAM("Members", Members);

		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_ADD_GROUP)));

		CComQIPtr<ILocalObject> spLocalObject(Group);
		if (!spLocalObject)
			ReportError(IDS_ERR_OBJECT_NOT_LOCAL);
		CContactGroup* pGroup;
		CHECK_HR(spLocalObject->GetLocalObject((LPUNKNOWN*)&pGroup));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementValue(spDoc, L"ID", pGroup->m_bstrID);
		CXmlUtils::SetElementValue(spDoc, L"Name", pGroup->m_bstrName);
		CXmlUtils::SetElementValue(spDoc, L"Description", pGroup->m_bstrDescription);
		CXmlUtils::SetElementValue(spDoc, L"GroupType", GroupTypeToString(pGroup->m_groupType));
		CXmlUtils::SetElementArrayValue(spDoc, L"memberIDs", MemberIDs);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result.
		_bstr_t bstrResult = CXmlUtils::GetElementValue(spDoc, L"AddGroupResult");

		//Return the result to the caller.
		*pVal = bstrResult.copy();

	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CContactService::DeleteContact(BSTR ContactID)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("DeleteContact"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_PARAM("ContactID", ContactID);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_DELETE_CONTACT)));

		//Set the value of the elements in the XML.
		CXmlUtils::SetElementValue(spDoc, L"id", ContactID);
	
		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}


STDMETHODIMP CContactService::DeleteContacts(BSTR ContactIDs)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("DeleteContacts"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_PARAM("Contacts", ContactIDs);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_DELETE_CONTACTS)));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementArrayValue(spDoc, L"ids", ContactIDs);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CContactService::DeleteGroup(BSTR GroupID, VARIANT IncludeMembers)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("DeleteGroup"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_PARAM("GroupID", GroupID);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_DELETE_GROUP)));

		//Set the value of the elements in the XML.
		CXmlUtils::SetElementValue(spDoc, L"id", GroupID);
		if (IncludeMembers.vt==VT_BOOL && IncludeMembers.boolVal==VARIANT_TRUE)
			CXmlUtils::SetElementValue(spDoc, L"includeMembers", L"true");
		else
			CXmlUtils::SetElementValue(spDoc, L"includeMembers", L"false");
	
		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CContactService::DeleteGroups(BSTR GroupIDs)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("DeleteGroups"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_PARAM("Groups", GroupIDs);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_DELETE_GROUPS)));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementArrayValue(spDoc, L"ids", GroupIDs);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CContactService::UpdateContact(IContact* Contact)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("UpdateContact"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_PARAM("Contact", Contact);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_UPDATE_CONTACT)));

		//Get the contact node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"contact");

		//Delete the node's children.
		CXmlUtils::DeleteNodeChildren(spNode);

		//Add the contact elements below the new contact node.
		CHECK_HR(AddContactElements(spDoc, spNode, Contact));

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CContactService::UpdateGroup(IContactGroup* Group, BSTR MemberIDs)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("UpdateGroup"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_PARAM("Group", Group);

		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		//CHECK_PARAM("Members", MemberIDs);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_UPDATE_GROUP)));

		CComQIPtr<ILocalObject> spLocalObject(Group);
		if (!spLocalObject)
			ReportError(IDS_ERR_OBJECT_NOT_LOCAL);
		CContactGroup* pGroup;
		CHECK_HR(spLocalObject->GetLocalObject((LPUNKNOWN*)&pGroup));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementValue(spDoc, L"ID", pGroup->m_bstrID);
		CXmlUtils::SetElementValue(spDoc, L"Name", pGroup->m_bstrName);
		CXmlUtils::SetElementValue(spDoc, L"Description", pGroup->m_bstrDescription);
		CXmlUtils::SetElementValue(spDoc, L"GroupType", GroupTypeToString(pGroup->m_groupType));
		CXmlUtils::SetElementArrayValue(spDoc, L"memberIDs", MemberIDs);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CContactService::GetGroupMembers(BSTR ID, IObjectCollection **pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetGroupMembers"); 
	try
	{
		//Use CHECK_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_PARAM("ID", ID);

		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_GROUP_MEMBERS)));

		//Set the value of the elements in the XML.
		CXmlUtils::SetElementValue(spDoc, L"id", ID);

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"GetGroupMembersResult");

		CHECK_HR(GetObjectCollectionFromResult(OBJECT_TYPE_CONTACT, spNode, pVal));
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}


