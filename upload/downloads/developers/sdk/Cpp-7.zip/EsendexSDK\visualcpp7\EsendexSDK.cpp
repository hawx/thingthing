// Esendex.cpp : Implementation of DLL Exports.


// Note: Proxy/Stub Information
//      To build a separate proxy/stub DLL, 
//      run nmake -f Esendexps.mk in the project directory.

#include "stdafx.h"
#include "resource.h"
#include <initguid.h>
#include "EsendexSDK.h"

#include "EsendexSDK_i.c"
#include "SMSMessage.h"
#include "StringCollection.h"
#include "SendService.h"
#include "InboxService.h"
#include "AccountService.h"
#include "Contact.h"
#include "ContactService.h"
#include "SignupService.h"
#include "ObjectCollection.h"
#include "ContactGroup.h"
#include "TestService.h"
#include "SignupCompletionElements.h"
#include "AccountState.h"
#include "MessengerService.h"


CComModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
OBJECT_ENTRY(CLSID_SendService2, CSendService)
OBJECT_ENTRY(CLSID_StringCollection2, CStringCollection)
OBJECT_ENTRY(CLSID_InboxService2, CInboxService)
OBJECT_ENTRY(CLSID_SMSMessage2, CSMSMessage)
OBJECT_ENTRY(CLSID_AccountService, CAccountService)
OBJECT_ENTRY(CLSID_Contact, CContact)
OBJECT_ENTRY(CLSID_ContactService, CContactService)
OBJECT_ENTRY(CLSID_SignupService, CSignupService)
OBJECT_ENTRY(CLSID_ObjectCollection, CObjectCollection)
OBJECT_ENTRY(CLSID_ContactGroup, CContactGroup)
OBJECT_ENTRY(CLSID_TestService, CTestService)
OBJECT_ENTRY(CLSID_SignupCompletionElements, CSignupCompletionElements)
OBJECT_ENTRY(CLSID_AccountState, CAccountState)
OBJECT_ENTRY(CLSID_MessengerService, CMessengerService)
END_OBJECT_MAP()

/////////////////////////////////////////////////////////////////////////////
// DLL Entry Point

const WCHAR* g_pwszMSXMLProgID;

static bool CheckVersion(log4cpp::Category& log, LPCWSTR pwszProgID)
{
	CLSID classID;
	HRESULT hr;
	hr = CLSIDFromProgID(pwszProgID, &classID);
	if (SUCCEEDED(hr))		
	{
		log.debug("MSXML ProgID %S was found", pwszProgID);
		g_pwszMSXMLProgID = pwszProgID;
		return true;
	}
	else
	{
		log.debug("MSXML ProgID %S is not registered", pwszProgID);
		return false;
	}
}

static HRESULT CheckMSXML()
{
	char* m_pszClassName = "global";
	ESENDEX_METHOD_PROLOGUE("DllMain"); 
	try
	{
		if (!CheckVersion(log, L"MSXML2.DOMDOCUMENT.4.0"))
			if (!CheckVersion(log, L"MSXML2.DOMDOCUMENT.3.0"))
				if (!CheckVersion(log, L"MSXML2.DOMDOCUMENT.2.6"))
					if (!CheckVersion(log, L"MSXML2.DOMDOCUMENT"))
						if (!CheckVersion(log, L"MSXML.DOMDOCUMENT"))
							if (!CheckVersion(log, L"MICROSOFT.XMLDOM.1.0"))
								if (!CheckVersion(log, L"MICROSOFT.XMLDOM"))
									return E_FAIL;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

extern "C"
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID /*lpReserved*/)
{
    if (dwReason == DLL_PROCESS_ATTACH)
    {
        _Module.Init(ObjectMap, hInstance, &LIBID_EsendexLib);
        DisableThreadLibraryCalls(hInstance);

		try 
		{
			log4cpp::PropertyConfigurator::configure("c:\\EsendexLogging.properties");
		}
		catch(log4cpp::ConfigureFailure& f) 
		{
			
			//std::cout << "Configure Problem " << f.what() << std::endl;
			//return -1;
			OutputDebugString("Failed to configure log4cpp ");
			OutputDebugString(f.what());
			OutputDebugString("\n");
		}

		CheckMSXML();
    }
    else if (dwReason == DLL_PROCESS_DETACH)
	{
		log4cpp::Category::shutdown();
        _Module.Term();
	}
    return TRUE;    // ok
}


/////////////////////////////////////////////////////////////////////////////
// Used to determine whether the DLL can be unloaded by OLE

STDAPI DllCanUnloadNow(void)
{
    return (_Module.GetLockCount()==0) ? S_OK : S_FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// Returns a class factory to create an object of the requested type

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
    return _Module.GetClassObject(rclsid, riid, ppv);
}

/////////////////////////////////////////////////////////////////////////////
// DllRegisterServer - Adds entries to the system registry

STDAPI DllRegisterServer(void)
{
    // registers object, typelib and all interfaces in typelib
    return _Module.RegisterServer(TRUE);
}

/////////////////////////////////////////////////////////////////////////////
// DllUnregisterServer - Removes entries from the system registry

STDAPI DllUnregisterServer(void)
{
    return _Module.UnregisterServer(TRUE);
}


