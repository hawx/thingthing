

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Fri Dec 10 10:52:06 2004
 */
/* Compiler settings for .\EsendexSDK.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __EsendexSDK_h__
#define __EsendexSDK_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IDomainObject_FWD_DEFINED__
#define __IDomainObject_FWD_DEFINED__
typedef interface IDomainObject IDomainObject;
#endif 	/* __IDomainObject_FWD_DEFINED__ */


#ifndef __ILocalObject_FWD_DEFINED__
#define __ILocalObject_FWD_DEFINED__
typedef interface ILocalObject ILocalObject;
#endif 	/* __ILocalObject_FWD_DEFINED__ */


#ifndef __IObjectCollection_FWD_DEFINED__
#define __IObjectCollection_FWD_DEFINED__
typedef interface IObjectCollection IObjectCollection;
#endif 	/* __IObjectCollection_FWD_DEFINED__ */


#ifndef __IStringCollection2_FWD_DEFINED__
#define __IStringCollection2_FWD_DEFINED__
typedef interface IStringCollection2 IStringCollection2;
#endif 	/* __IStringCollection2_FWD_DEFINED__ */


#ifndef __ISMSMessage2_FWD_DEFINED__
#define __ISMSMessage2_FWD_DEFINED__
typedef interface ISMSMessage2 ISMSMessage2;
#endif 	/* __ISMSMessage2_FWD_DEFINED__ */


#ifndef __ISendService2_FWD_DEFINED__
#define __ISendService2_FWD_DEFINED__
typedef interface ISendService2 ISendService2;
#endif 	/* __ISendService2_FWD_DEFINED__ */


#ifndef __IInboxService2_FWD_DEFINED__
#define __IInboxService2_FWD_DEFINED__
typedef interface IInboxService2 IInboxService2;
#endif 	/* __IInboxService2_FWD_DEFINED__ */


#ifndef __IAccountState_FWD_DEFINED__
#define __IAccountState_FWD_DEFINED__
typedef interface IAccountState IAccountState;
#endif 	/* __IAccountState_FWD_DEFINED__ */


#ifndef __IAccountService_FWD_DEFINED__
#define __IAccountService_FWD_DEFINED__
typedef interface IAccountService IAccountService;
#endif 	/* __IAccountService_FWD_DEFINED__ */


#ifndef __IContact_FWD_DEFINED__
#define __IContact_FWD_DEFINED__
typedef interface IContact IContact;
#endif 	/* __IContact_FWD_DEFINED__ */


#ifndef __IContactGroup_FWD_DEFINED__
#define __IContactGroup_FWD_DEFINED__
typedef interface IContactGroup IContactGroup;
#endif 	/* __IContactGroup_FWD_DEFINED__ */


#ifndef __IContactService_FWD_DEFINED__
#define __IContactService_FWD_DEFINED__
typedef interface IContactService IContactService;
#endif 	/* __IContactService_FWD_DEFINED__ */


#ifndef __ISignupCompletionElements_FWD_DEFINED__
#define __ISignupCompletionElements_FWD_DEFINED__
typedef interface ISignupCompletionElements ISignupCompletionElements;
#endif 	/* __ISignupCompletionElements_FWD_DEFINED__ */


#ifndef __ISignupService_FWD_DEFINED__
#define __ISignupService_FWD_DEFINED__
typedef interface ISignupService ISignupService;
#endif 	/* __ISignupService_FWD_DEFINED__ */


#ifndef __ITestService_FWD_DEFINED__
#define __ITestService_FWD_DEFINED__
typedef interface ITestService ITestService;
#endif 	/* __ITestService_FWD_DEFINED__ */


#ifndef __IMessengerService_FWD_DEFINED__
#define __IMessengerService_FWD_DEFINED__
typedef interface IMessengerService IMessengerService;
#endif 	/* __IMessengerService_FWD_DEFINED__ */


#ifndef __SendService2_FWD_DEFINED__
#define __SendService2_FWD_DEFINED__

#ifdef __cplusplus
typedef class SendService2 SendService2;
#else
typedef struct SendService2 SendService2;
#endif /* __cplusplus */

#endif 	/* __SendService2_FWD_DEFINED__ */


#ifndef __StringCollection2_FWD_DEFINED__
#define __StringCollection2_FWD_DEFINED__

#ifdef __cplusplus
typedef class StringCollection2 StringCollection2;
#else
typedef struct StringCollection2 StringCollection2;
#endif /* __cplusplus */

#endif 	/* __StringCollection2_FWD_DEFINED__ */


#ifndef __InboxService2_FWD_DEFINED__
#define __InboxService2_FWD_DEFINED__

#ifdef __cplusplus
typedef class InboxService2 InboxService2;
#else
typedef struct InboxService2 InboxService2;
#endif /* __cplusplus */

#endif 	/* __InboxService2_FWD_DEFINED__ */


#ifndef __AccountService_FWD_DEFINED__
#define __AccountService_FWD_DEFINED__

#ifdef __cplusplus
typedef class AccountService AccountService;
#else
typedef struct AccountService AccountService;
#endif /* __cplusplus */

#endif 	/* __AccountService_FWD_DEFINED__ */


#ifndef __SMSMessage2_FWD_DEFINED__
#define __SMSMessage2_FWD_DEFINED__

#ifdef __cplusplus
typedef class SMSMessage2 SMSMessage2;
#else
typedef struct SMSMessage2 SMSMessage2;
#endif /* __cplusplus */

#endif 	/* __SMSMessage2_FWD_DEFINED__ */


#ifndef __ContactService_FWD_DEFINED__
#define __ContactService_FWD_DEFINED__

#ifdef __cplusplus
typedef class ContactService ContactService;
#else
typedef struct ContactService ContactService;
#endif /* __cplusplus */

#endif 	/* __ContactService_FWD_DEFINED__ */


#ifndef __SignupService_FWD_DEFINED__
#define __SignupService_FWD_DEFINED__

#ifdef __cplusplus
typedef class SignupService SignupService;
#else
typedef struct SignupService SignupService;
#endif /* __cplusplus */

#endif 	/* __SignupService_FWD_DEFINED__ */


#ifndef __ObjectCollection_FWD_DEFINED__
#define __ObjectCollection_FWD_DEFINED__

#ifdef __cplusplus
typedef class ObjectCollection ObjectCollection;
#else
typedef struct ObjectCollection ObjectCollection;
#endif /* __cplusplus */

#endif 	/* __ObjectCollection_FWD_DEFINED__ */


#ifndef __Contact_FWD_DEFINED__
#define __Contact_FWD_DEFINED__

#ifdef __cplusplus
typedef class Contact Contact;
#else
typedef struct Contact Contact;
#endif /* __cplusplus */

#endif 	/* __Contact_FWD_DEFINED__ */


#ifndef __ContactGroup_FWD_DEFINED__
#define __ContactGroup_FWD_DEFINED__

#ifdef __cplusplus
typedef class ContactGroup ContactGroup;
#else
typedef struct ContactGroup ContactGroup;
#endif /* __cplusplus */

#endif 	/* __ContactGroup_FWD_DEFINED__ */


#ifndef __TestService_FWD_DEFINED__
#define __TestService_FWD_DEFINED__

#ifdef __cplusplus
typedef class TestService TestService;
#else
typedef struct TestService TestService;
#endif /* __cplusplus */

#endif 	/* __TestService_FWD_DEFINED__ */


#ifndef __SignupCompletionElements_FWD_DEFINED__
#define __SignupCompletionElements_FWD_DEFINED__

#ifdef __cplusplus
typedef class SignupCompletionElements SignupCompletionElements;
#else
typedef struct SignupCompletionElements SignupCompletionElements;
#endif /* __cplusplus */

#endif 	/* __SignupCompletionElements_FWD_DEFINED__ */


#ifndef __AccountState_FWD_DEFINED__
#define __AccountState_FWD_DEFINED__

#ifdef __cplusplus
typedef class AccountState AccountState;
#else
typedef struct AccountState AccountState;
#endif /* __cplusplus */

#endif 	/* __AccountState_FWD_DEFINED__ */


#ifndef __MessengerService_FWD_DEFINED__
#define __MessengerService_FWD_DEFINED__

#ifdef __cplusplus
typedef class MessengerService MessengerService;
#else
typedef struct MessengerService MessengerService;
#endif /* __cplusplus */

#endif 	/* __MessengerService_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

/* interface __MIDL_itf_EsendexSDK_0000 */
/* [local] */ 

typedef 
enum MESSAGE_TYPE
    {	MESSAGE_TYPE_TEXT	= 1,
	MESSAGE_TYPE_BINARY	= 2,
	MESSAGE_TYPE_SMARTMESSAGE	= 3,
	MESSAGE_TYPE_UNICODE	= 4
    } 	MESSAGE_TYPE;

typedef 
enum MESSAGE_STATUS
    {	MESSAGE_STATUS_QUEUED	= 1,
	MESSAGE_STATUS_SENT	= 2,
	MESSAGE_STATUS_DELIVERED	= 3,
	MESSAGE_STATUS_FAILED	= 4
    } 	MESSAGE_STATUS;

typedef 
enum ACCOUNT_FEATURES
    {	ACCOUNT_FEATURE_NONE	= 0,
	ACCOUNT_FEATURE_SERVICE_ALIASING	= 1,
	ACCOUNT_FEATURE_INBOX	= 2
    } 	ACCOUNT_FEATURES;

typedef 
enum CONTACT_TYPE
    {	CONTACT_TYPE_CONTACT	= 0,
	CONTACT_TYPE_SUBSCRIBER	= 1
    } 	CONTACT_TYPE;

typedef 
enum CONTACT_GROUP_TYPE
    {	CONTACT_GROUP_TYPE_GROUP	= 0,
	CONTACT_GROUP_TYPE_SUBSCRIBERS	= 1
    } 	CONTACT_GROUP_TYPE;

typedef 
enum ERROR_CODE
    {	ERROR_CODE_UNKNOWN	= 0,
	ERROR_CODE_UNEXPECTED	= 1,
	ERROR_CODE_AUTHENTICATION_FAILED	= 2,
	ERROR_CODE_MISSING_HEADER	= 3,
	ERROR_CODE_RECIPIENT_MISSING	= 4,
	ERROR_CODE_ACCOUNT_NOT_LIVE	= 5,
	ERROR_CODE_METHOD_NOT_ENABLED	= 6,
	ERROR_CODE_FEATURE_NOT_SUPPORTED	= 7,
	ERROR_CODE_MESSAGE_NOT_FOUND	= 8,
	ERROR_CODE_RECIPIENT_INVALID	= 9,
	ERROR_CODE_MESSAGE_LIMIT_EXCEEDED	= 10,
	ERROR_CODE_MESSAGE_ID_FORMAT_INVALID	= 11,
	ERROR_CODE_USERNAME_ALREADY_EXISTS	= 12,
	ERROR_CODE_CONTACT_ALREADY_EXISTS	= 13,
	ERROR_CODE_CONTACT_GROUP_ALREADY_EXISTS	= 14,
	ERROR_CODE_CONTACT_OR_GROUP_ALREADY_EXISTS	= 15,
	ERROR_CODE_NOT_AUTHORISED	= 16,
	ERROR_CODE_VALIDATION	= 17,
	ERROR_CODE_NO_ACTIVE_SUBSCRIPTION	= 18,
	ERROR_CODE_CONNECTION_FAILED	= 1000
    } 	ERROR_CODE;



extern RPC_IF_HANDLE __MIDL_itf_EsendexSDK_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_EsendexSDK_0000_v0_0_s_ifspec;

#ifndef __IDomainObject_INTERFACE_DEFINED__
#define __IDomainObject_INTERFACE_DEFINED__

/* interface IDomainObject */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IDomainObject;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("E4D0FAEE-2D16-4543-8995-971A615E1AC5")
    IDomainObject : public IUnknown
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ID( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ID( 
            /* [in] */ BSTR newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDomainObjectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IDomainObject * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IDomainObject * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IDomainObject * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ID )( 
            IDomainObject * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ID )( 
            IDomainObject * This,
            /* [in] */ BSTR newVal);
        
        END_INTERFACE
    } IDomainObjectVtbl;

    interface IDomainObject
    {
        CONST_VTBL struct IDomainObjectVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDomainObject_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDomainObject_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDomainObject_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDomainObject_get_ID(This,pVal)	\
    (This)->lpVtbl -> get_ID(This,pVal)

#define IDomainObject_put_ID(This,newVal)	\
    (This)->lpVtbl -> put_ID(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDomainObject_get_ID_Proxy( 
    IDomainObject * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IDomainObject_get_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDomainObject_put_ID_Proxy( 
    IDomainObject * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IDomainObject_put_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDomainObject_INTERFACE_DEFINED__ */


#ifndef __ILocalObject_INTERFACE_DEFINED__
#define __ILocalObject_INTERFACE_DEFINED__

/* interface ILocalObject */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_ILocalObject;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("E5F0C6D3-5228-445e-8A69-0AF4155AB359")
    ILocalObject : public IUnknown
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetLocalObject( 
            /* [retval][out] */ IUnknown **pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ILocalObjectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ILocalObject * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ILocalObject * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ILocalObject * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetLocalObject )( 
            ILocalObject * This,
            /* [retval][out] */ IUnknown **pVal);
        
        END_INTERFACE
    } ILocalObjectVtbl;

    interface ILocalObject
    {
        CONST_VTBL struct ILocalObjectVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ILocalObject_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ILocalObject_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ILocalObject_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ILocalObject_GetLocalObject(This,pVal)	\
    (This)->lpVtbl -> GetLocalObject(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILocalObject_GetLocalObject_Proxy( 
    ILocalObject * This,
    /* [retval][out] */ IUnknown **pVal);


void __RPC_STUB ILocalObject_GetLocalObject_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ILocalObject_INTERFACE_DEFINED__ */


#ifndef __IObjectCollection_INTERFACE_DEFINED__
#define __IObjectCollection_INTERFACE_DEFINED__

/* interface IObjectCollection */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IObjectCollection;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("6EF5679E-A648-4546-B2E3-C9FDD64D96B4")
    IObjectCollection : public IDispatch
    {
    public:
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown **ppUnk) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ long Index,
            /* [retval][out] */ IDispatch **pVal) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_Item( 
            /* [in] */ long Index,
            /* [in] */ IDispatch *newVal) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Add( 
            IDispatch *newVal) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Remove( 
            long Index) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_IDs( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IObjectCollectionVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IObjectCollection * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IObjectCollection * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IObjectCollection * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IObjectCollection * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IObjectCollection * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IObjectCollection * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IObjectCollection * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE *get__NewEnum )( 
            IObjectCollection * This,
            /* [retval][out] */ IUnknown **ppUnk);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IObjectCollection * This,
            /* [in] */ long Index,
            /* [retval][out] */ IDispatch **pVal);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Item )( 
            IObjectCollection * This,
            /* [in] */ long Index,
            /* [in] */ IDispatch *newVal);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            IObjectCollection * This,
            /* [retval][out] */ long *pVal);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *Add )( 
            IObjectCollection * This,
            IDispatch *newVal);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *Remove )( 
            IObjectCollection * This,
            long Index);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_IDs )( 
            IObjectCollection * This,
            /* [retval][out] */ BSTR *pVal);
        
        END_INTERFACE
    } IObjectCollectionVtbl;

    interface IObjectCollection
    {
        CONST_VTBL struct IObjectCollectionVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IObjectCollection_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IObjectCollection_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IObjectCollection_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IObjectCollection_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IObjectCollection_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IObjectCollection_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IObjectCollection_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IObjectCollection_get__NewEnum(This,ppUnk)	\
    (This)->lpVtbl -> get__NewEnum(This,ppUnk)

#define IObjectCollection_get_Item(This,Index,pVal)	\
    (This)->lpVtbl -> get_Item(This,Index,pVal)

#define IObjectCollection_put_Item(This,Index,newVal)	\
    (This)->lpVtbl -> put_Item(This,Index,newVal)

#define IObjectCollection_get_Count(This,pVal)	\
    (This)->lpVtbl -> get_Count(This,pVal)

#define IObjectCollection_Add(This,newVal)	\
    (This)->lpVtbl -> Add(This,newVal)

#define IObjectCollection_Remove(This,Index)	\
    (This)->lpVtbl -> Remove(This,Index)

#define IObjectCollection_get_IDs(This,pVal)	\
    (This)->lpVtbl -> get_IDs(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget][id] */ HRESULT STDMETHODCALLTYPE IObjectCollection_get__NewEnum_Proxy( 
    IObjectCollection * This,
    /* [retval][out] */ IUnknown **ppUnk);


void __RPC_STUB IObjectCollection_get__NewEnum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IObjectCollection_get_Item_Proxy( 
    IObjectCollection * This,
    /* [in] */ long Index,
    /* [retval][out] */ IDispatch **pVal);


void __RPC_STUB IObjectCollection_get_Item_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IObjectCollection_put_Item_Proxy( 
    IObjectCollection * This,
    /* [in] */ long Index,
    /* [in] */ IDispatch *newVal);


void __RPC_STUB IObjectCollection_put_Item_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IObjectCollection_get_Count_Proxy( 
    IObjectCollection * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB IObjectCollection_get_Count_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IObjectCollection_Add_Proxy( 
    IObjectCollection * This,
    IDispatch *newVal);


void __RPC_STUB IObjectCollection_Add_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IObjectCollection_Remove_Proxy( 
    IObjectCollection * This,
    long Index);


void __RPC_STUB IObjectCollection_Remove_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IObjectCollection_get_IDs_Proxy( 
    IObjectCollection * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IObjectCollection_get_IDs_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IObjectCollection_INTERFACE_DEFINED__ */


#ifndef __IStringCollection2_INTERFACE_DEFINED__
#define __IStringCollection2_INTERFACE_DEFINED__

/* interface IStringCollection2 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IStringCollection2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("FF4384A2-3FAA-40f4-A28E-7E49D78FB775")
    IStringCollection2 : public IDispatch
    {
    public:
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown **ppUnk) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ long Index,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_Item( 
            /* [in] */ long Index,
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Add( 
            BSTR newVal) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Remove( 
            long Index) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IStringCollection2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IStringCollection2 * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IStringCollection2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IStringCollection2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IStringCollection2 * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IStringCollection2 * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IStringCollection2 * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IStringCollection2 * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE *get__NewEnum )( 
            IStringCollection2 * This,
            /* [retval][out] */ IUnknown **ppUnk);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IStringCollection2 * This,
            /* [in] */ long Index,
            /* [retval][out] */ BSTR *pVal);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Item )( 
            IStringCollection2 * This,
            /* [in] */ long Index,
            /* [in] */ BSTR newVal);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            IStringCollection2 * This,
            /* [retval][out] */ long *pVal);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *Add )( 
            IStringCollection2 * This,
            BSTR newVal);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *Remove )( 
            IStringCollection2 * This,
            long Index);
        
        END_INTERFACE
    } IStringCollection2Vtbl;

    interface IStringCollection2
    {
        CONST_VTBL struct IStringCollection2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IStringCollection2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IStringCollection2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IStringCollection2_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IStringCollection2_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IStringCollection2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IStringCollection2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IStringCollection2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IStringCollection2_get__NewEnum(This,ppUnk)	\
    (This)->lpVtbl -> get__NewEnum(This,ppUnk)

#define IStringCollection2_get_Item(This,Index,pVal)	\
    (This)->lpVtbl -> get_Item(This,Index,pVal)

#define IStringCollection2_put_Item(This,Index,newVal)	\
    (This)->lpVtbl -> put_Item(This,Index,newVal)

#define IStringCollection2_get_Count(This,pVal)	\
    (This)->lpVtbl -> get_Count(This,pVal)

#define IStringCollection2_Add(This,newVal)	\
    (This)->lpVtbl -> Add(This,newVal)

#define IStringCollection2_Remove(This,Index)	\
    (This)->lpVtbl -> Remove(This,Index)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget][id] */ HRESULT STDMETHODCALLTYPE IStringCollection2_get__NewEnum_Proxy( 
    IStringCollection2 * This,
    /* [retval][out] */ IUnknown **ppUnk);


void __RPC_STUB IStringCollection2_get__NewEnum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IStringCollection2_get_Item_Proxy( 
    IStringCollection2 * This,
    /* [in] */ long Index,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IStringCollection2_get_Item_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IStringCollection2_put_Item_Proxy( 
    IStringCollection2 * This,
    /* [in] */ long Index,
    /* [in] */ BSTR newVal);


void __RPC_STUB IStringCollection2_put_Item_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IStringCollection2_get_Count_Proxy( 
    IStringCollection2 * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB IStringCollection2_get_Count_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IStringCollection2_Add_Proxy( 
    IStringCollection2 * This,
    BSTR newVal);


void __RPC_STUB IStringCollection2_Add_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IStringCollection2_Remove_Proxy( 
    IStringCollection2 * This,
    long Index);


void __RPC_STUB IStringCollection2_Remove_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IStringCollection2_INTERFACE_DEFINED__ */


#ifndef __ISMSMessage2_INTERFACE_DEFINED__
#define __ISMSMessage2_INTERFACE_DEFINED__

/* interface ISMSMessage2 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISMSMessage2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("7662BA01-1898-4e36-A82F-61C046885F92")
    ISMSMessage2 : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ID( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ID( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Originator( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Originator( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Recipient( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Recipient( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Body( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Body( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SentAt( 
            /* [retval][out] */ DATE *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SentAt( 
            /* [in] */ DATE newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ReceivedAt( 
            /* [retval][out] */ DATE *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ReceivedAt( 
            /* [in] */ DATE newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Type( 
            /* [retval][out] */ MESSAGE_TYPE *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Type( 
            /* [in] */ MESSAGE_TYPE newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Status( 
            /* [retval][out] */ MESSAGE_STATUS *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Status( 
            /* [in] */ MESSAGE_STATUS newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Username( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Username( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_MessageIndex( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_MessageIndex( 
            /* [in] */ long newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISMSMessage2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISMSMessage2 * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISMSMessage2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISMSMessage2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISMSMessage2 * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISMSMessage2 * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISMSMessage2 * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISMSMessage2 * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ID )( 
            ISMSMessage2 * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ID )( 
            ISMSMessage2 * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Originator )( 
            ISMSMessage2 * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Originator )( 
            ISMSMessage2 * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Recipient )( 
            ISMSMessage2 * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Recipient )( 
            ISMSMessage2 * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Body )( 
            ISMSMessage2 * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Body )( 
            ISMSMessage2 * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_SentAt )( 
            ISMSMessage2 * This,
            /* [retval][out] */ DATE *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_SentAt )( 
            ISMSMessage2 * This,
            /* [in] */ DATE newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ReceivedAt )( 
            ISMSMessage2 * This,
            /* [retval][out] */ DATE *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ReceivedAt )( 
            ISMSMessage2 * This,
            /* [in] */ DATE newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Type )( 
            ISMSMessage2 * This,
            /* [retval][out] */ MESSAGE_TYPE *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Type )( 
            ISMSMessage2 * This,
            /* [in] */ MESSAGE_TYPE newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Status )( 
            ISMSMessage2 * This,
            /* [retval][out] */ MESSAGE_STATUS *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Status )( 
            ISMSMessage2 * This,
            /* [in] */ MESSAGE_STATUS newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Username )( 
            ISMSMessage2 * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Username )( 
            ISMSMessage2 * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_MessageIndex )( 
            ISMSMessage2 * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_MessageIndex )( 
            ISMSMessage2 * This,
            /* [in] */ long newVal);
        
        END_INTERFACE
    } ISMSMessage2Vtbl;

    interface ISMSMessage2
    {
        CONST_VTBL struct ISMSMessage2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISMSMessage2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISMSMessage2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISMSMessage2_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISMSMessage2_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISMSMessage2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISMSMessage2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISMSMessage2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISMSMessage2_get_ID(This,pVal)	\
    (This)->lpVtbl -> get_ID(This,pVal)

#define ISMSMessage2_put_ID(This,newVal)	\
    (This)->lpVtbl -> put_ID(This,newVal)

#define ISMSMessage2_get_Originator(This,pVal)	\
    (This)->lpVtbl -> get_Originator(This,pVal)

#define ISMSMessage2_put_Originator(This,newVal)	\
    (This)->lpVtbl -> put_Originator(This,newVal)

#define ISMSMessage2_get_Recipient(This,pVal)	\
    (This)->lpVtbl -> get_Recipient(This,pVal)

#define ISMSMessage2_put_Recipient(This,newVal)	\
    (This)->lpVtbl -> put_Recipient(This,newVal)

#define ISMSMessage2_get_Body(This,pVal)	\
    (This)->lpVtbl -> get_Body(This,pVal)

#define ISMSMessage2_put_Body(This,newVal)	\
    (This)->lpVtbl -> put_Body(This,newVal)

#define ISMSMessage2_get_SentAt(This,pVal)	\
    (This)->lpVtbl -> get_SentAt(This,pVal)

#define ISMSMessage2_put_SentAt(This,newVal)	\
    (This)->lpVtbl -> put_SentAt(This,newVal)

#define ISMSMessage2_get_ReceivedAt(This,pVal)	\
    (This)->lpVtbl -> get_ReceivedAt(This,pVal)

#define ISMSMessage2_put_ReceivedAt(This,newVal)	\
    (This)->lpVtbl -> put_ReceivedAt(This,newVal)

#define ISMSMessage2_get_Type(This,pVal)	\
    (This)->lpVtbl -> get_Type(This,pVal)

#define ISMSMessage2_put_Type(This,newVal)	\
    (This)->lpVtbl -> put_Type(This,newVal)

#define ISMSMessage2_get_Status(This,pVal)	\
    (This)->lpVtbl -> get_Status(This,pVal)

#define ISMSMessage2_put_Status(This,newVal)	\
    (This)->lpVtbl -> put_Status(This,newVal)

#define ISMSMessage2_get_Username(This,pVal)	\
    (This)->lpVtbl -> get_Username(This,pVal)

#define ISMSMessage2_put_Username(This,newVal)	\
    (This)->lpVtbl -> put_Username(This,newVal)

#define ISMSMessage2_get_MessageIndex(This,pVal)	\
    (This)->lpVtbl -> get_MessageIndex(This,pVal)

#define ISMSMessage2_put_MessageIndex(This,newVal)	\
    (This)->lpVtbl -> put_MessageIndex(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_get_ID_Proxy( 
    ISMSMessage2 * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISMSMessage2_get_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_put_ID_Proxy( 
    ISMSMessage2 * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISMSMessage2_put_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_get_Originator_Proxy( 
    ISMSMessage2 * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISMSMessage2_get_Originator_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_put_Originator_Proxy( 
    ISMSMessage2 * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISMSMessage2_put_Originator_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_get_Recipient_Proxy( 
    ISMSMessage2 * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISMSMessage2_get_Recipient_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_put_Recipient_Proxy( 
    ISMSMessage2 * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISMSMessage2_put_Recipient_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_get_Body_Proxy( 
    ISMSMessage2 * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISMSMessage2_get_Body_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_put_Body_Proxy( 
    ISMSMessage2 * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISMSMessage2_put_Body_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_get_SentAt_Proxy( 
    ISMSMessage2 * This,
    /* [retval][out] */ DATE *pVal);


void __RPC_STUB ISMSMessage2_get_SentAt_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_put_SentAt_Proxy( 
    ISMSMessage2 * This,
    /* [in] */ DATE newVal);


void __RPC_STUB ISMSMessage2_put_SentAt_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_get_ReceivedAt_Proxy( 
    ISMSMessage2 * This,
    /* [retval][out] */ DATE *pVal);


void __RPC_STUB ISMSMessage2_get_ReceivedAt_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_put_ReceivedAt_Proxy( 
    ISMSMessage2 * This,
    /* [in] */ DATE newVal);


void __RPC_STUB ISMSMessage2_put_ReceivedAt_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_get_Type_Proxy( 
    ISMSMessage2 * This,
    /* [retval][out] */ MESSAGE_TYPE *pVal);


void __RPC_STUB ISMSMessage2_get_Type_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_put_Type_Proxy( 
    ISMSMessage2 * This,
    /* [in] */ MESSAGE_TYPE newVal);


void __RPC_STUB ISMSMessage2_put_Type_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_get_Status_Proxy( 
    ISMSMessage2 * This,
    /* [retval][out] */ MESSAGE_STATUS *pVal);


void __RPC_STUB ISMSMessage2_get_Status_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_put_Status_Proxy( 
    ISMSMessage2 * This,
    /* [in] */ MESSAGE_STATUS newVal);


void __RPC_STUB ISMSMessage2_put_Status_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_get_Username_Proxy( 
    ISMSMessage2 * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISMSMessage2_get_Username_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_put_Username_Proxy( 
    ISMSMessage2 * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISMSMessage2_put_Username_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_get_MessageIndex_Proxy( 
    ISMSMessage2 * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB ISMSMessage2_get_MessageIndex_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISMSMessage2_put_MessageIndex_Proxy( 
    ISMSMessage2 * This,
    /* [in] */ long newVal);


void __RPC_STUB ISMSMessage2_put_MessageIndex_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISMSMessage2_INTERFACE_DEFINED__ */


#ifndef __ISendService2_INTERFACE_DEFINED__
#define __ISendService2_INTERFACE_DEFINED__

/* interface ISendService2 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISendService2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("41C3B9F8-CC42-47ca-B9B1-C7561563CF81")
    ISendService2 : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Initialise( 
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SendMessageFull( 
            BSTR Originator,
            BSTR Recipient,
            BSTR Body,
            MESSAGE_TYPE Type,
            long ValidityPeriod,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SendMessage( 
            BSTR Recipient,
            BSTR Body,
            MESSAGE_TYPE Type,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetMessageStatus( 
            BSTR MessageID,
            /* [retval][out] */ MESSAGE_STATUS *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SendMessageMultipleRecipients( 
            BSTR Recipients,
            BSTR Body,
            MESSAGE_TYPE Type,
            /* [retval][out] */ IStringCollection2 **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SendMessageMultipleRecipientsFull( 
            BSTR Originator,
            BSTR Recipients,
            BSTR Body,
            MESSAGE_TYPE Type,
            long ValidityPeriod,
            /* [retval][out] */ IStringCollection2 **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Dummy( 
            ERROR_CODE x) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISendService2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISendService2 * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISendService2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISendService2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISendService2 * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISendService2 * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISendService2 * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISendService2 * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Initialise )( 
            ISendService2 * This,
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SendMessageFull )( 
            ISendService2 * This,
            BSTR Originator,
            BSTR Recipient,
            BSTR Body,
            MESSAGE_TYPE Type,
            long ValidityPeriod,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SendMessage )( 
            ISendService2 * This,
            BSTR Recipient,
            BSTR Body,
            MESSAGE_TYPE Type,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetMessageStatus )( 
            ISendService2 * This,
            BSTR MessageID,
            /* [retval][out] */ MESSAGE_STATUS *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SendMessageMultipleRecipients )( 
            ISendService2 * This,
            BSTR Recipients,
            BSTR Body,
            MESSAGE_TYPE Type,
            /* [retval][out] */ IStringCollection2 **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SendMessageMultipleRecipientsFull )( 
            ISendService2 * This,
            BSTR Originator,
            BSTR Recipients,
            BSTR Body,
            MESSAGE_TYPE Type,
            long ValidityPeriod,
            /* [retval][out] */ IStringCollection2 **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Dummy )( 
            ISendService2 * This,
            ERROR_CODE x);
        
        END_INTERFACE
    } ISendService2Vtbl;

    interface ISendService2
    {
        CONST_VTBL struct ISendService2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISendService2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISendService2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISendService2_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISendService2_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISendService2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISendService2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISendService2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISendService2_Initialise(This,Username,Password,Account,IsServerSide)	\
    (This)->lpVtbl -> Initialise(This,Username,Password,Account,IsServerSide)

#define ISendService2_SendMessageFull(This,Originator,Recipient,Body,Type,ValidityPeriod,pVal)	\
    (This)->lpVtbl -> SendMessageFull(This,Originator,Recipient,Body,Type,ValidityPeriod,pVal)

#define ISendService2_SendMessage(This,Recipient,Body,Type,pVal)	\
    (This)->lpVtbl -> SendMessage(This,Recipient,Body,Type,pVal)

#define ISendService2_GetMessageStatus(This,MessageID,pVal)	\
    (This)->lpVtbl -> GetMessageStatus(This,MessageID,pVal)

#define ISendService2_SendMessageMultipleRecipients(This,Recipients,Body,Type,pVal)	\
    (This)->lpVtbl -> SendMessageMultipleRecipients(This,Recipients,Body,Type,pVal)

#define ISendService2_SendMessageMultipleRecipientsFull(This,Originator,Recipients,Body,Type,ValidityPeriod,pVal)	\
    (This)->lpVtbl -> SendMessageMultipleRecipientsFull(This,Originator,Recipients,Body,Type,ValidityPeriod,pVal)

#define ISendService2_Dummy(This,x)	\
    (This)->lpVtbl -> Dummy(This,x)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISendService2_Initialise_Proxy( 
    ISendService2 * This,
    BSTR Username,
    BSTR Password,
    BSTR Account,
    /* [optional] */ VARIANT IsServerSide);


void __RPC_STUB ISendService2_Initialise_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISendService2_SendMessageFull_Proxy( 
    ISendService2 * This,
    BSTR Originator,
    BSTR Recipient,
    BSTR Body,
    MESSAGE_TYPE Type,
    long ValidityPeriod,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISendService2_SendMessageFull_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISendService2_SendMessage_Proxy( 
    ISendService2 * This,
    BSTR Recipient,
    BSTR Body,
    MESSAGE_TYPE Type,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISendService2_SendMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISendService2_GetMessageStatus_Proxy( 
    ISendService2 * This,
    BSTR MessageID,
    /* [retval][out] */ MESSAGE_STATUS *pVal);


void __RPC_STUB ISendService2_GetMessageStatus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISendService2_SendMessageMultipleRecipients_Proxy( 
    ISendService2 * This,
    BSTR Recipients,
    BSTR Body,
    MESSAGE_TYPE Type,
    /* [retval][out] */ IStringCollection2 **pVal);


void __RPC_STUB ISendService2_SendMessageMultipleRecipients_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISendService2_SendMessageMultipleRecipientsFull_Proxy( 
    ISendService2 * This,
    BSTR Originator,
    BSTR Recipients,
    BSTR Body,
    MESSAGE_TYPE Type,
    long ValidityPeriod,
    /* [retval][out] */ IStringCollection2 **pVal);


void __RPC_STUB ISendService2_SendMessageMultipleRecipientsFull_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISendService2_Dummy_Proxy( 
    ISendService2 * This,
    ERROR_CODE x);


void __RPC_STUB ISendService2_Dummy_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISendService2_INTERFACE_DEFINED__ */


#ifndef __IInboxService2_INTERFACE_DEFINED__
#define __IInboxService2_INTERFACE_DEFINED__

/* interface IInboxService2 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IInboxService2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("506EB50A-D14A-4019-94C2-E7B4801CEEDF")
    IInboxService2 : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Initialise( 
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteMessage( 
            BSTR MessageID) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteMessages( 
            BSTR MessageIDs) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetMessages( 
            /* [retval][out] */ IObjectCollection **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetMessage( 
            /* [in] */ BSTR MessageID,
            /* [retval][out] */ ISMSMessage2 **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetMessagesForDay( 
            /* [in] */ long Year,
            /* [in] */ long Month,
            /* [in] */ long Day,
            /* [retval][out] */ IObjectCollection **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetMessagesForDateRange( 
            DATE StartDate,
            DATE EndDate,
            /* [retval][out] */ IObjectCollection **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetMessagesByID( 
            /* [in] */ BSTR Messages,
            /* [retval][out] */ IObjectCollection **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetLatestMessages( 
            VARIANT LastMessageIndex,
            /* [optional] */ VARIANT MaxMessages,
            /* [retval][out] */ IObjectCollection **pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IInboxService2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IInboxService2 * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IInboxService2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IInboxService2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IInboxService2 * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IInboxService2 * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IInboxService2 * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IInboxService2 * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Initialise )( 
            IInboxService2 * This,
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DeleteMessage )( 
            IInboxService2 * This,
            BSTR MessageID);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DeleteMessages )( 
            IInboxService2 * This,
            BSTR MessageIDs);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetMessages )( 
            IInboxService2 * This,
            /* [retval][out] */ IObjectCollection **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetMessage )( 
            IInboxService2 * This,
            /* [in] */ BSTR MessageID,
            /* [retval][out] */ ISMSMessage2 **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetMessagesForDay )( 
            IInboxService2 * This,
            /* [in] */ long Year,
            /* [in] */ long Month,
            /* [in] */ long Day,
            /* [retval][out] */ IObjectCollection **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetMessagesForDateRange )( 
            IInboxService2 * This,
            DATE StartDate,
            DATE EndDate,
            /* [retval][out] */ IObjectCollection **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetMessagesByID )( 
            IInboxService2 * This,
            /* [in] */ BSTR Messages,
            /* [retval][out] */ IObjectCollection **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetLatestMessages )( 
            IInboxService2 * This,
            VARIANT LastMessageIndex,
            /* [optional] */ VARIANT MaxMessages,
            /* [retval][out] */ IObjectCollection **pVal);
        
        END_INTERFACE
    } IInboxService2Vtbl;

    interface IInboxService2
    {
        CONST_VTBL struct IInboxService2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IInboxService2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IInboxService2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IInboxService2_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IInboxService2_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IInboxService2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IInboxService2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IInboxService2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IInboxService2_Initialise(This,Username,Password,Account,IsServerSide)	\
    (This)->lpVtbl -> Initialise(This,Username,Password,Account,IsServerSide)

#define IInboxService2_DeleteMessage(This,MessageID)	\
    (This)->lpVtbl -> DeleteMessage(This,MessageID)

#define IInboxService2_DeleteMessages(This,MessageIDs)	\
    (This)->lpVtbl -> DeleteMessages(This,MessageIDs)

#define IInboxService2_GetMessages(This,pVal)	\
    (This)->lpVtbl -> GetMessages(This,pVal)

#define IInboxService2_GetMessage(This,MessageID,pVal)	\
    (This)->lpVtbl -> GetMessage(This,MessageID,pVal)

#define IInboxService2_GetMessagesForDay(This,Year,Month,Day,pVal)	\
    (This)->lpVtbl -> GetMessagesForDay(This,Year,Month,Day,pVal)

#define IInboxService2_GetMessagesForDateRange(This,StartDate,EndDate,pVal)	\
    (This)->lpVtbl -> GetMessagesForDateRange(This,StartDate,EndDate,pVal)

#define IInboxService2_GetMessagesByID(This,Messages,pVal)	\
    (This)->lpVtbl -> GetMessagesByID(This,Messages,pVal)

#define IInboxService2_GetLatestMessages(This,LastMessageIndex,MaxMessages,pVal)	\
    (This)->lpVtbl -> GetLatestMessages(This,LastMessageIndex,MaxMessages,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService2_Initialise_Proxy( 
    IInboxService2 * This,
    BSTR Username,
    BSTR Password,
    BSTR Account,
    /* [optional] */ VARIANT IsServerSide);


void __RPC_STUB IInboxService2_Initialise_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService2_DeleteMessage_Proxy( 
    IInboxService2 * This,
    BSTR MessageID);


void __RPC_STUB IInboxService2_DeleteMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService2_DeleteMessages_Proxy( 
    IInboxService2 * This,
    BSTR MessageIDs);


void __RPC_STUB IInboxService2_DeleteMessages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService2_GetMessages_Proxy( 
    IInboxService2 * This,
    /* [retval][out] */ IObjectCollection **pVal);


void __RPC_STUB IInboxService2_GetMessages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService2_GetMessage_Proxy( 
    IInboxService2 * This,
    /* [in] */ BSTR MessageID,
    /* [retval][out] */ ISMSMessage2 **pVal);


void __RPC_STUB IInboxService2_GetMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService2_GetMessagesForDay_Proxy( 
    IInboxService2 * This,
    /* [in] */ long Year,
    /* [in] */ long Month,
    /* [in] */ long Day,
    /* [retval][out] */ IObjectCollection **pVal);


void __RPC_STUB IInboxService2_GetMessagesForDay_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService2_GetMessagesForDateRange_Proxy( 
    IInboxService2 * This,
    DATE StartDate,
    DATE EndDate,
    /* [retval][out] */ IObjectCollection **pVal);


void __RPC_STUB IInboxService2_GetMessagesForDateRange_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService2_GetMessagesByID_Proxy( 
    IInboxService2 * This,
    /* [in] */ BSTR Messages,
    /* [retval][out] */ IObjectCollection **pVal);


void __RPC_STUB IInboxService2_GetMessagesByID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IInboxService2_GetLatestMessages_Proxy( 
    IInboxService2 * This,
    VARIANT LastMessageIndex,
    /* [optional] */ VARIANT MaxMessages,
    /* [retval][out] */ IObjectCollection **pVal);


void __RPC_STUB IInboxService2_GetLatestMessages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IInboxService2_INTERFACE_DEFINED__ */


#ifndef __IAccountState_INTERFACE_DEFINED__
#define __IAccountState_INTERFACE_DEFINED__

/* interface IAccountState */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IAccountState;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("1684AE92-1721-4B3C-98D2-3914F7BB3B0F")
    IAccountState : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ID( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ID( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Reference( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Reference( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Address( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Address( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ServiceAlias( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ServiceAlias( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_MessageLimit( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_MessageLimit( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Features( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Features( 
            /* [in] */ long newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAccountStateVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IAccountState * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IAccountState * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IAccountState * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IAccountState * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IAccountState * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IAccountState * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IAccountState * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ID )( 
            IAccountState * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ID )( 
            IAccountState * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Reference )( 
            IAccountState * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Reference )( 
            IAccountState * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Address )( 
            IAccountState * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Address )( 
            IAccountState * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ServiceAlias )( 
            IAccountState * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ServiceAlias )( 
            IAccountState * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_MessageLimit )( 
            IAccountState * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_MessageLimit )( 
            IAccountState * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Features )( 
            IAccountState * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Features )( 
            IAccountState * This,
            /* [in] */ long newVal);
        
        END_INTERFACE
    } IAccountStateVtbl;

    interface IAccountState
    {
        CONST_VTBL struct IAccountStateVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAccountState_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IAccountState_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IAccountState_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IAccountState_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IAccountState_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IAccountState_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IAccountState_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IAccountState_get_ID(This,pVal)	\
    (This)->lpVtbl -> get_ID(This,pVal)

#define IAccountState_put_ID(This,newVal)	\
    (This)->lpVtbl -> put_ID(This,newVal)

#define IAccountState_get_Reference(This,pVal)	\
    (This)->lpVtbl -> get_Reference(This,pVal)

#define IAccountState_put_Reference(This,newVal)	\
    (This)->lpVtbl -> put_Reference(This,newVal)

#define IAccountState_get_Address(This,pVal)	\
    (This)->lpVtbl -> get_Address(This,pVal)

#define IAccountState_put_Address(This,newVal)	\
    (This)->lpVtbl -> put_Address(This,newVal)

#define IAccountState_get_ServiceAlias(This,pVal)	\
    (This)->lpVtbl -> get_ServiceAlias(This,pVal)

#define IAccountState_put_ServiceAlias(This,newVal)	\
    (This)->lpVtbl -> put_ServiceAlias(This,newVal)

#define IAccountState_get_MessageLimit(This,pVal)	\
    (This)->lpVtbl -> get_MessageLimit(This,pVal)

#define IAccountState_put_MessageLimit(This,newVal)	\
    (This)->lpVtbl -> put_MessageLimit(This,newVal)

#define IAccountState_get_Features(This,pVal)	\
    (This)->lpVtbl -> get_Features(This,pVal)

#define IAccountState_put_Features(This,newVal)	\
    (This)->lpVtbl -> put_Features(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAccountState_get_ID_Proxy( 
    IAccountState * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IAccountState_get_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAccountState_put_ID_Proxy( 
    IAccountState * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IAccountState_put_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAccountState_get_Reference_Proxy( 
    IAccountState * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IAccountState_get_Reference_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAccountState_put_Reference_Proxy( 
    IAccountState * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IAccountState_put_Reference_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAccountState_get_Address_Proxy( 
    IAccountState * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IAccountState_get_Address_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAccountState_put_Address_Proxy( 
    IAccountState * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IAccountState_put_Address_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAccountState_get_ServiceAlias_Proxy( 
    IAccountState * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IAccountState_get_ServiceAlias_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAccountState_put_ServiceAlias_Proxy( 
    IAccountState * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IAccountState_put_ServiceAlias_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAccountState_get_MessageLimit_Proxy( 
    IAccountState * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB IAccountState_get_MessageLimit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAccountState_put_MessageLimit_Proxy( 
    IAccountState * This,
    /* [in] */ long newVal);


void __RPC_STUB IAccountState_put_MessageLimit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAccountState_get_Features_Proxy( 
    IAccountState * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB IAccountState_get_Features_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAccountState_put_Features_Proxy( 
    IAccountState * This,
    /* [in] */ long newVal);


void __RPC_STUB IAccountState_put_Features_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IAccountState_INTERFACE_DEFINED__ */


#ifndef __IAccountService_INTERFACE_DEFINED__
#define __IAccountService_INTERFACE_DEFINED__

/* interface IAccountService */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IAccountService;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("95605B05-3760-4211-9EEB-F6D928325031")
    IAccountService : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Initialise( 
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetMessageLimit( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetAccountFeatures( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Dummy( 
            ACCOUNT_FEATURES x) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetAccountState( 
            /* [retval][out] */ IAccountState **pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAccountServiceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IAccountService * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IAccountService * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IAccountService * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IAccountService * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IAccountService * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IAccountService * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IAccountService * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Initialise )( 
            IAccountService * This,
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetMessageLimit )( 
            IAccountService * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetAccountFeatures )( 
            IAccountService * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Dummy )( 
            IAccountService * This,
            ACCOUNT_FEATURES x);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetAccountState )( 
            IAccountService * This,
            /* [retval][out] */ IAccountState **pVal);
        
        END_INTERFACE
    } IAccountServiceVtbl;

    interface IAccountService
    {
        CONST_VTBL struct IAccountServiceVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAccountService_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IAccountService_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IAccountService_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IAccountService_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IAccountService_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IAccountService_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IAccountService_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IAccountService_Initialise(This,Username,Password,Account,IsServerSide)	\
    (This)->lpVtbl -> Initialise(This,Username,Password,Account,IsServerSide)

#define IAccountService_GetMessageLimit(This,pVal)	\
    (This)->lpVtbl -> GetMessageLimit(This,pVal)

#define IAccountService_GetAccountFeatures(This,pVal)	\
    (This)->lpVtbl -> GetAccountFeatures(This,pVal)

#define IAccountService_Dummy(This,x)	\
    (This)->lpVtbl -> Dummy(This,x)

#define IAccountService_GetAccountState(This,pVal)	\
    (This)->lpVtbl -> GetAccountState(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAccountService_Initialise_Proxy( 
    IAccountService * This,
    BSTR Username,
    BSTR Password,
    BSTR Account,
    /* [optional] */ VARIANT IsServerSide);


void __RPC_STUB IAccountService_Initialise_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAccountService_GetMessageLimit_Proxy( 
    IAccountService * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB IAccountService_GetMessageLimit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAccountService_GetAccountFeatures_Proxy( 
    IAccountService * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB IAccountService_GetAccountFeatures_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAccountService_Dummy_Proxy( 
    IAccountService * This,
    ACCOUNT_FEATURES x);


void __RPC_STUB IAccountService_Dummy_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAccountService_GetAccountState_Proxy( 
    IAccountService * This,
    /* [retval][out] */ IAccountState **pVal);


void __RPC_STUB IAccountService_GetAccountState_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IAccountService_INTERFACE_DEFINED__ */


#ifndef __IContact_INTERFACE_DEFINED__
#define __IContact_INTERFACE_DEFINED__

/* interface IContact */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IContact;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("790CF8C5-14A7-45CA-BEEA-9BF6C8B7B9CB")
    IContact : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ID( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ID( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_QuickName( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_QuickName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FirstName( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FirstName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_LastName( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_LastName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_TelephoneNumber( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_TelephoneNumber( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_MobileNumber( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_MobileNumber( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_StreetAddress1( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_StreetAddress1( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_StreetAddress2( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_StreetAddress2( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Town( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Town( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_County( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_County( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Postcode( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Postcode( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Country( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Country( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_EmailAddress( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_EmailAddress( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ContactType( 
            /* [retval][out] */ CONTACT_TYPE *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ContactType( 
            /* [in] */ CONTACT_TYPE newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IContactVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IContact * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IContact * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IContact * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IContact * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IContact * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IContact * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IContact * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ID )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ID )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_QuickName )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_QuickName )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_FirstName )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_FirstName )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_LastName )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_LastName )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_TelephoneNumber )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_TelephoneNumber )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_MobileNumber )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_MobileNumber )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_StreetAddress1 )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_StreetAddress1 )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_StreetAddress2 )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_StreetAddress2 )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Town )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Town )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_County )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_County )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Postcode )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Postcode )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Country )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Country )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_EmailAddress )( 
            IContact * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_EmailAddress )( 
            IContact * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ContactType )( 
            IContact * This,
            /* [retval][out] */ CONTACT_TYPE *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ContactType )( 
            IContact * This,
            /* [in] */ CONTACT_TYPE newVal);
        
        END_INTERFACE
    } IContactVtbl;

    interface IContact
    {
        CONST_VTBL struct IContactVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IContact_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IContact_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IContact_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IContact_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IContact_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IContact_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IContact_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IContact_get_ID(This,pVal)	\
    (This)->lpVtbl -> get_ID(This,pVal)

#define IContact_put_ID(This,newVal)	\
    (This)->lpVtbl -> put_ID(This,newVal)

#define IContact_get_QuickName(This,pVal)	\
    (This)->lpVtbl -> get_QuickName(This,pVal)

#define IContact_put_QuickName(This,newVal)	\
    (This)->lpVtbl -> put_QuickName(This,newVal)

#define IContact_get_FirstName(This,pVal)	\
    (This)->lpVtbl -> get_FirstName(This,pVal)

#define IContact_put_FirstName(This,newVal)	\
    (This)->lpVtbl -> put_FirstName(This,newVal)

#define IContact_get_LastName(This,pVal)	\
    (This)->lpVtbl -> get_LastName(This,pVal)

#define IContact_put_LastName(This,newVal)	\
    (This)->lpVtbl -> put_LastName(This,newVal)

#define IContact_get_TelephoneNumber(This,pVal)	\
    (This)->lpVtbl -> get_TelephoneNumber(This,pVal)

#define IContact_put_TelephoneNumber(This,newVal)	\
    (This)->lpVtbl -> put_TelephoneNumber(This,newVal)

#define IContact_get_MobileNumber(This,pVal)	\
    (This)->lpVtbl -> get_MobileNumber(This,pVal)

#define IContact_put_MobileNumber(This,newVal)	\
    (This)->lpVtbl -> put_MobileNumber(This,newVal)

#define IContact_get_StreetAddress1(This,pVal)	\
    (This)->lpVtbl -> get_StreetAddress1(This,pVal)

#define IContact_put_StreetAddress1(This,newVal)	\
    (This)->lpVtbl -> put_StreetAddress1(This,newVal)

#define IContact_get_StreetAddress2(This,pVal)	\
    (This)->lpVtbl -> get_StreetAddress2(This,pVal)

#define IContact_put_StreetAddress2(This,newVal)	\
    (This)->lpVtbl -> put_StreetAddress2(This,newVal)

#define IContact_get_Town(This,pVal)	\
    (This)->lpVtbl -> get_Town(This,pVal)

#define IContact_put_Town(This,newVal)	\
    (This)->lpVtbl -> put_Town(This,newVal)

#define IContact_get_County(This,pVal)	\
    (This)->lpVtbl -> get_County(This,pVal)

#define IContact_put_County(This,newVal)	\
    (This)->lpVtbl -> put_County(This,newVal)

#define IContact_get_Postcode(This,pVal)	\
    (This)->lpVtbl -> get_Postcode(This,pVal)

#define IContact_put_Postcode(This,newVal)	\
    (This)->lpVtbl -> put_Postcode(This,newVal)

#define IContact_get_Country(This,pVal)	\
    (This)->lpVtbl -> get_Country(This,pVal)

#define IContact_put_Country(This,newVal)	\
    (This)->lpVtbl -> put_Country(This,newVal)

#define IContact_get_EmailAddress(This,pVal)	\
    (This)->lpVtbl -> get_EmailAddress(This,pVal)

#define IContact_put_EmailAddress(This,newVal)	\
    (This)->lpVtbl -> put_EmailAddress(This,newVal)

#define IContact_get_ContactType(This,pVal)	\
    (This)->lpVtbl -> get_ContactType(This,pVal)

#define IContact_put_ContactType(This,newVal)	\
    (This)->lpVtbl -> put_ContactType(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_ID_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_ID_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_QuickName_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_QuickName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_QuickName_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_QuickName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_FirstName_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_FirstName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_FirstName_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_FirstName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_LastName_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_LastName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_LastName_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_LastName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_TelephoneNumber_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_TelephoneNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_TelephoneNumber_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_TelephoneNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_MobileNumber_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_MobileNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_MobileNumber_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_MobileNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_StreetAddress1_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_StreetAddress1_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_StreetAddress1_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_StreetAddress1_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_StreetAddress2_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_StreetAddress2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_StreetAddress2_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_StreetAddress2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_Town_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_Town_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_Town_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_Town_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_County_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_County_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_County_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_County_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_Postcode_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_Postcode_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_Postcode_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_Postcode_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_Country_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_Country_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_Country_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_Country_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_EmailAddress_Proxy( 
    IContact * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContact_get_EmailAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_EmailAddress_Proxy( 
    IContact * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContact_put_EmailAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContact_get_ContactType_Proxy( 
    IContact * This,
    /* [retval][out] */ CONTACT_TYPE *pVal);


void __RPC_STUB IContact_get_ContactType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContact_put_ContactType_Proxy( 
    IContact * This,
    /* [in] */ CONTACT_TYPE newVal);


void __RPC_STUB IContact_put_ContactType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IContact_INTERFACE_DEFINED__ */


#ifndef __IContactGroup_INTERFACE_DEFINED__
#define __IContactGroup_INTERFACE_DEFINED__

/* interface IContactGroup */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IContactGroup;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("17E0F07A-E3EB-47D2-A683-86C0EA7CDA8B")
    IContactGroup : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ID( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ID( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Name( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Name( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Description( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Description( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_GroupType( 
            /* [retval][out] */ CONTACT_GROUP_TYPE *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_GroupType( 
            /* [in] */ CONTACT_GROUP_TYPE newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IContactGroupVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IContactGroup * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IContactGroup * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IContactGroup * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IContactGroup * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IContactGroup * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IContactGroup * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IContactGroup * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ID )( 
            IContactGroup * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ID )( 
            IContactGroup * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Name )( 
            IContactGroup * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Name )( 
            IContactGroup * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Description )( 
            IContactGroup * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Description )( 
            IContactGroup * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_GroupType )( 
            IContactGroup * This,
            /* [retval][out] */ CONTACT_GROUP_TYPE *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_GroupType )( 
            IContactGroup * This,
            /* [in] */ CONTACT_GROUP_TYPE newVal);
        
        END_INTERFACE
    } IContactGroupVtbl;

    interface IContactGroup
    {
        CONST_VTBL struct IContactGroupVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IContactGroup_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IContactGroup_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IContactGroup_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IContactGroup_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IContactGroup_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IContactGroup_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IContactGroup_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IContactGroup_get_ID(This,pVal)	\
    (This)->lpVtbl -> get_ID(This,pVal)

#define IContactGroup_put_ID(This,newVal)	\
    (This)->lpVtbl -> put_ID(This,newVal)

#define IContactGroup_get_Name(This,pVal)	\
    (This)->lpVtbl -> get_Name(This,pVal)

#define IContactGroup_put_Name(This,newVal)	\
    (This)->lpVtbl -> put_Name(This,newVal)

#define IContactGroup_get_Description(This,pVal)	\
    (This)->lpVtbl -> get_Description(This,pVal)

#define IContactGroup_put_Description(This,newVal)	\
    (This)->lpVtbl -> put_Description(This,newVal)

#define IContactGroup_get_GroupType(This,pVal)	\
    (This)->lpVtbl -> get_GroupType(This,pVal)

#define IContactGroup_put_GroupType(This,newVal)	\
    (This)->lpVtbl -> put_GroupType(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContactGroup_get_ID_Proxy( 
    IContactGroup * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContactGroup_get_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContactGroup_put_ID_Proxy( 
    IContactGroup * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContactGroup_put_ID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContactGroup_get_Name_Proxy( 
    IContactGroup * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContactGroup_get_Name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContactGroup_put_Name_Proxy( 
    IContactGroup * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContactGroup_put_Name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContactGroup_get_Description_Proxy( 
    IContactGroup * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContactGroup_get_Description_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContactGroup_put_Description_Proxy( 
    IContactGroup * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IContactGroup_put_Description_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IContactGroup_get_GroupType_Proxy( 
    IContactGroup * This,
    /* [retval][out] */ CONTACT_GROUP_TYPE *pVal);


void __RPC_STUB IContactGroup_get_GroupType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IContactGroup_put_GroupType_Proxy( 
    IContactGroup * This,
    /* [in] */ CONTACT_GROUP_TYPE newVal);


void __RPC_STUB IContactGroup_put_GroupType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IContactGroup_INTERFACE_DEFINED__ */


#ifndef __IContactService_INTERFACE_DEFINED__
#define __IContactService_INTERFACE_DEFINED__

/* interface IContactService */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IContactService;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("7D90CD80-9E3F-48B7-89BE-75E9C4B824C3")
    IContactService : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Initialise( 
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetContacts( 
            /* [retval][out] */ IObjectCollection **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetGroups( 
            /* [retval][out] */ IObjectCollection **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddContact( 
            IContact *Contact,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddContacts( 
            IObjectCollection *Contacts,
            /* [retval][out] */ IStringCollection2 **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddGroup( 
            IContactGroup *Group,
            BSTR MemberIDs,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteContact( 
            BSTR ContactID) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteContacts( 
            BSTR ContactIDs) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteGroup( 
            BSTR GroupID,
            /* [optional] */ VARIANT IncludeMembers) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteGroups( 
            BSTR Groups) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE UpdateContact( 
            IContact *Contact) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE UpdateGroup( 
            IContactGroup *Group,
            BSTR MemberIDs) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetContact( 
            BSTR ID,
            /* [retval][out] */ IContact **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetGroup( 
            BSTR ID,
            /* [retval][out] */ IContactGroup **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetGroupMembers( 
            BSTR ID,
            /* [retval][out] */ IObjectCollection **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetContactByQuickName( 
            BSTR ID,
            /* [retval][out] */ IContact **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetGroupByName( 
            BSTR ID,
            /* [retval][out] */ IContactGroup **pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IContactServiceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IContactService * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IContactService * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IContactService * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IContactService * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IContactService * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IContactService * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IContactService * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Initialise )( 
            IContactService * This,
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetContacts )( 
            IContactService * This,
            /* [retval][out] */ IObjectCollection **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetGroups )( 
            IContactService * This,
            /* [retval][out] */ IObjectCollection **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *AddContact )( 
            IContactService * This,
            IContact *Contact,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *AddContacts )( 
            IContactService * This,
            IObjectCollection *Contacts,
            /* [retval][out] */ IStringCollection2 **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *AddGroup )( 
            IContactService * This,
            IContactGroup *Group,
            BSTR MemberIDs,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DeleteContact )( 
            IContactService * This,
            BSTR ContactID);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DeleteContacts )( 
            IContactService * This,
            BSTR ContactIDs);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DeleteGroup )( 
            IContactService * This,
            BSTR GroupID,
            /* [optional] */ VARIANT IncludeMembers);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DeleteGroups )( 
            IContactService * This,
            BSTR Groups);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *UpdateContact )( 
            IContactService * This,
            IContact *Contact);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *UpdateGroup )( 
            IContactService * This,
            IContactGroup *Group,
            BSTR MemberIDs);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetContact )( 
            IContactService * This,
            BSTR ID,
            /* [retval][out] */ IContact **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetGroup )( 
            IContactService * This,
            BSTR ID,
            /* [retval][out] */ IContactGroup **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetGroupMembers )( 
            IContactService * This,
            BSTR ID,
            /* [retval][out] */ IObjectCollection **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetContactByQuickName )( 
            IContactService * This,
            BSTR ID,
            /* [retval][out] */ IContact **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetGroupByName )( 
            IContactService * This,
            BSTR ID,
            /* [retval][out] */ IContactGroup **pVal);
        
        END_INTERFACE
    } IContactServiceVtbl;

    interface IContactService
    {
        CONST_VTBL struct IContactServiceVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IContactService_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IContactService_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IContactService_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IContactService_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IContactService_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IContactService_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IContactService_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IContactService_Initialise(This,Username,Password,Account,IsServerSide)	\
    (This)->lpVtbl -> Initialise(This,Username,Password,Account,IsServerSide)

#define IContactService_GetContacts(This,pVal)	\
    (This)->lpVtbl -> GetContacts(This,pVal)

#define IContactService_GetGroups(This,pVal)	\
    (This)->lpVtbl -> GetGroups(This,pVal)

#define IContactService_AddContact(This,Contact,pVal)	\
    (This)->lpVtbl -> AddContact(This,Contact,pVal)

#define IContactService_AddContacts(This,Contacts,pVal)	\
    (This)->lpVtbl -> AddContacts(This,Contacts,pVal)

#define IContactService_AddGroup(This,Group,MemberIDs,pVal)	\
    (This)->lpVtbl -> AddGroup(This,Group,MemberIDs,pVal)

#define IContactService_DeleteContact(This,ContactID)	\
    (This)->lpVtbl -> DeleteContact(This,ContactID)

#define IContactService_DeleteContacts(This,ContactIDs)	\
    (This)->lpVtbl -> DeleteContacts(This,ContactIDs)

#define IContactService_DeleteGroup(This,GroupID,IncludeMembers)	\
    (This)->lpVtbl -> DeleteGroup(This,GroupID,IncludeMembers)

#define IContactService_DeleteGroups(This,Groups)	\
    (This)->lpVtbl -> DeleteGroups(This,Groups)

#define IContactService_UpdateContact(This,Contact)	\
    (This)->lpVtbl -> UpdateContact(This,Contact)

#define IContactService_UpdateGroup(This,Group,MemberIDs)	\
    (This)->lpVtbl -> UpdateGroup(This,Group,MemberIDs)

#define IContactService_GetContact(This,ID,pVal)	\
    (This)->lpVtbl -> GetContact(This,ID,pVal)

#define IContactService_GetGroup(This,ID,pVal)	\
    (This)->lpVtbl -> GetGroup(This,ID,pVal)

#define IContactService_GetGroupMembers(This,ID,pVal)	\
    (This)->lpVtbl -> GetGroupMembers(This,ID,pVal)

#define IContactService_GetContactByQuickName(This,ID,pVal)	\
    (This)->lpVtbl -> GetContactByQuickName(This,ID,pVal)

#define IContactService_GetGroupByName(This,ID,pVal)	\
    (This)->lpVtbl -> GetGroupByName(This,ID,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_Initialise_Proxy( 
    IContactService * This,
    BSTR Username,
    BSTR Password,
    BSTR Account,
    /* [optional] */ VARIANT IsServerSide);


void __RPC_STUB IContactService_Initialise_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_GetContacts_Proxy( 
    IContactService * This,
    /* [retval][out] */ IObjectCollection **pVal);


void __RPC_STUB IContactService_GetContacts_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_GetGroups_Proxy( 
    IContactService * This,
    /* [retval][out] */ IObjectCollection **pVal);


void __RPC_STUB IContactService_GetGroups_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_AddContact_Proxy( 
    IContactService * This,
    IContact *Contact,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContactService_AddContact_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_AddContacts_Proxy( 
    IContactService * This,
    IObjectCollection *Contacts,
    /* [retval][out] */ IStringCollection2 **pVal);


void __RPC_STUB IContactService_AddContacts_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_AddGroup_Proxy( 
    IContactService * This,
    IContactGroup *Group,
    BSTR MemberIDs,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IContactService_AddGroup_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_DeleteContact_Proxy( 
    IContactService * This,
    BSTR ContactID);


void __RPC_STUB IContactService_DeleteContact_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_DeleteContacts_Proxy( 
    IContactService * This,
    BSTR ContactIDs);


void __RPC_STUB IContactService_DeleteContacts_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_DeleteGroup_Proxy( 
    IContactService * This,
    BSTR GroupID,
    /* [optional] */ VARIANT IncludeMembers);


void __RPC_STUB IContactService_DeleteGroup_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_DeleteGroups_Proxy( 
    IContactService * This,
    BSTR Groups);


void __RPC_STUB IContactService_DeleteGroups_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_UpdateContact_Proxy( 
    IContactService * This,
    IContact *Contact);


void __RPC_STUB IContactService_UpdateContact_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_UpdateGroup_Proxy( 
    IContactService * This,
    IContactGroup *Group,
    BSTR MemberIDs);


void __RPC_STUB IContactService_UpdateGroup_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_GetContact_Proxy( 
    IContactService * This,
    BSTR ID,
    /* [retval][out] */ IContact **pVal);


void __RPC_STUB IContactService_GetContact_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_GetGroup_Proxy( 
    IContactService * This,
    BSTR ID,
    /* [retval][out] */ IContactGroup **pVal);


void __RPC_STUB IContactService_GetGroup_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_GetGroupMembers_Proxy( 
    IContactService * This,
    BSTR ID,
    /* [retval][out] */ IObjectCollection **pVal);


void __RPC_STUB IContactService_GetGroupMembers_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_GetContactByQuickName_Proxy( 
    IContactService * This,
    BSTR ID,
    /* [retval][out] */ IContact **pVal);


void __RPC_STUB IContactService_GetContactByQuickName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IContactService_GetGroupByName_Proxy( 
    IContactService * This,
    BSTR ID,
    /* [retval][out] */ IContactGroup **pVal);


void __RPC_STUB IContactService_GetGroupByName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IContactService_INTERFACE_DEFINED__ */


#ifndef __ISignupCompletionElements_INTERFACE_DEFINED__
#define __ISignupCompletionElements_INTERFACE_DEFINED__

/* interface ISignupCompletionElements */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISignupCompletionElements;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("5CD56000-830A-4701-AFA5-C25C13C00669")
    ISignupCompletionElements : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Username( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Username( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_AccountReference( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_AccountReference( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_WelcomeMessage( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_WelcomeMessage( 
            /* [in] */ BSTR newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISignupCompletionElementsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISignupCompletionElements * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISignupCompletionElements * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISignupCompletionElements * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISignupCompletionElements * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISignupCompletionElements * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISignupCompletionElements * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISignupCompletionElements * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Username )( 
            ISignupCompletionElements * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Username )( 
            ISignupCompletionElements * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_AccountReference )( 
            ISignupCompletionElements * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_AccountReference )( 
            ISignupCompletionElements * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_WelcomeMessage )( 
            ISignupCompletionElements * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_WelcomeMessage )( 
            ISignupCompletionElements * This,
            /* [in] */ BSTR newVal);
        
        END_INTERFACE
    } ISignupCompletionElementsVtbl;

    interface ISignupCompletionElements
    {
        CONST_VTBL struct ISignupCompletionElementsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISignupCompletionElements_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISignupCompletionElements_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISignupCompletionElements_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISignupCompletionElements_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISignupCompletionElements_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISignupCompletionElements_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISignupCompletionElements_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISignupCompletionElements_get_Username(This,pVal)	\
    (This)->lpVtbl -> get_Username(This,pVal)

#define ISignupCompletionElements_put_Username(This,newVal)	\
    (This)->lpVtbl -> put_Username(This,newVal)

#define ISignupCompletionElements_get_AccountReference(This,pVal)	\
    (This)->lpVtbl -> get_AccountReference(This,pVal)

#define ISignupCompletionElements_put_AccountReference(This,newVal)	\
    (This)->lpVtbl -> put_AccountReference(This,newVal)

#define ISignupCompletionElements_get_WelcomeMessage(This,pVal)	\
    (This)->lpVtbl -> get_WelcomeMessage(This,pVal)

#define ISignupCompletionElements_put_WelcomeMessage(This,newVal)	\
    (This)->lpVtbl -> put_WelcomeMessage(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISignupCompletionElements_get_Username_Proxy( 
    ISignupCompletionElements * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISignupCompletionElements_get_Username_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISignupCompletionElements_put_Username_Proxy( 
    ISignupCompletionElements * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISignupCompletionElements_put_Username_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISignupCompletionElements_get_AccountReference_Proxy( 
    ISignupCompletionElements * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISignupCompletionElements_get_AccountReference_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISignupCompletionElements_put_AccountReference_Proxy( 
    ISignupCompletionElements * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISignupCompletionElements_put_AccountReference_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISignupCompletionElements_get_WelcomeMessage_Proxy( 
    ISignupCompletionElements * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISignupCompletionElements_get_WelcomeMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISignupCompletionElements_put_WelcomeMessage_Proxy( 
    ISignupCompletionElements * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISignupCompletionElements_put_WelcomeMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISignupCompletionElements_INTERFACE_DEFINED__ */


#ifndef __ISignupService_INTERFACE_DEFINED__
#define __ISignupService_INTERFACE_DEFINED__

/* interface ISignupService */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISignupService;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B8B6782A-0108-4CFA-BD0A-5C229A520398")
    ISignupService : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Initialise( 
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DefaultEvaluationSignup( 
            BSTR FirstName,
            BSTR LastName,
            BSTR CompanyName,
            BSTR TelephoneNumber,
            BSTR MobileNumber,
            BSTR EmailAddress,
            VARIANT_BOOL MailingAgreement,
            /* [retval][out] */ ISignupCompletionElements **pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISignupServiceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISignupService * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISignupService * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISignupService * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISignupService * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISignupService * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISignupService * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISignupService * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Initialise )( 
            ISignupService * This,
            BSTR Username,
            BSTR Password,
            BSTR Account,
            /* [optional] */ VARIANT IsServerSide);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DefaultEvaluationSignup )( 
            ISignupService * This,
            BSTR FirstName,
            BSTR LastName,
            BSTR CompanyName,
            BSTR TelephoneNumber,
            BSTR MobileNumber,
            BSTR EmailAddress,
            VARIANT_BOOL MailingAgreement,
            /* [retval][out] */ ISignupCompletionElements **pVal);
        
        END_INTERFACE
    } ISignupServiceVtbl;

    interface ISignupService
    {
        CONST_VTBL struct ISignupServiceVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISignupService_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISignupService_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISignupService_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISignupService_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISignupService_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISignupService_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISignupService_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISignupService_Initialise(This,Username,Password,Account,IsServerSide)	\
    (This)->lpVtbl -> Initialise(This,Username,Password,Account,IsServerSide)

#define ISignupService_DefaultEvaluationSignup(This,FirstName,LastName,CompanyName,TelephoneNumber,MobileNumber,EmailAddress,MailingAgreement,pVal)	\
    (This)->lpVtbl -> DefaultEvaluationSignup(This,FirstName,LastName,CompanyName,TelephoneNumber,MobileNumber,EmailAddress,MailingAgreement,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISignupService_Initialise_Proxy( 
    ISignupService * This,
    BSTR Username,
    BSTR Password,
    BSTR Account,
    /* [optional] */ VARIANT IsServerSide);


void __RPC_STUB ISignupService_Initialise_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISignupService_DefaultEvaluationSignup_Proxy( 
    ISignupService * This,
    BSTR FirstName,
    BSTR LastName,
    BSTR CompanyName,
    BSTR TelephoneNumber,
    BSTR MobileNumber,
    BSTR EmailAddress,
    VARIANT_BOOL MailingAgreement,
    /* [retval][out] */ ISignupCompletionElements **pVal);


void __RPC_STUB ISignupService_DefaultEvaluationSignup_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISignupService_INTERFACE_DEFINED__ */


#ifndef __ITestService_INTERFACE_DEFINED__
#define __ITestService_INTERFACE_DEFINED__

/* interface ITestService */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ITestService;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("D21D6F23-1E6D-4DDF-8FF0-C8DF771A8D68")
    ITestService : public IDispatch
    {
    public:
        virtual /* [helpstring][hidden][id] */ HRESULT STDMETHODCALLTYPE SetSoapEndPoints( 
            BSTR URI,
            BSTR MockURI) = 0;
        
        virtual /* [helpstring][restricted][hidden][id] */ HRESULT STDMETHODCALLTYPE SetupContactTests( void) = 0;
        
        virtual /* [helpstring][hidden][id] */ HRESULT STDMETHODCALLTYPE SetupAccountTests( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetupSendTests( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetupInboxTests( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetupSignupTests( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITestServiceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ITestService * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ITestService * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ITestService * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ITestService * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ITestService * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ITestService * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ITestService * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][hidden][id] */ HRESULT ( STDMETHODCALLTYPE *SetSoapEndPoints )( 
            ITestService * This,
            BSTR URI,
            BSTR MockURI);
        
        /* [helpstring][restricted][hidden][id] */ HRESULT ( STDMETHODCALLTYPE *SetupContactTests )( 
            ITestService * This);
        
        /* [helpstring][hidden][id] */ HRESULT ( STDMETHODCALLTYPE *SetupAccountTests )( 
            ITestService * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SetupSendTests )( 
            ITestService * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SetupInboxTests )( 
            ITestService * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SetupSignupTests )( 
            ITestService * This);
        
        END_INTERFACE
    } ITestServiceVtbl;

    interface ITestService
    {
        CONST_VTBL struct ITestServiceVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITestService_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITestService_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITestService_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITestService_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ITestService_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ITestService_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ITestService_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ITestService_SetSoapEndPoints(This,URI,MockURI)	\
    (This)->lpVtbl -> SetSoapEndPoints(This,URI,MockURI)

#define ITestService_SetupContactTests(This)	\
    (This)->lpVtbl -> SetupContactTests(This)

#define ITestService_SetupAccountTests(This)	\
    (This)->lpVtbl -> SetupAccountTests(This)

#define ITestService_SetupSendTests(This)	\
    (This)->lpVtbl -> SetupSendTests(This)

#define ITestService_SetupInboxTests(This)	\
    (This)->lpVtbl -> SetupInboxTests(This)

#define ITestService_SetupSignupTests(This)	\
    (This)->lpVtbl -> SetupSignupTests(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][hidden][id] */ HRESULT STDMETHODCALLTYPE ITestService_SetSoapEndPoints_Proxy( 
    ITestService * This,
    BSTR URI,
    BSTR MockURI);


void __RPC_STUB ITestService_SetSoapEndPoints_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][restricted][hidden][id] */ HRESULT STDMETHODCALLTYPE ITestService_SetupContactTests_Proxy( 
    ITestService * This);


void __RPC_STUB ITestService_SetupContactTests_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][hidden][id] */ HRESULT STDMETHODCALLTYPE ITestService_SetupAccountTests_Proxy( 
    ITestService * This);


void __RPC_STUB ITestService_SetupAccountTests_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITestService_SetupSendTests_Proxy( 
    ITestService * This);


void __RPC_STUB ITestService_SetupSendTests_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITestService_SetupInboxTests_Proxy( 
    ITestService * This);


void __RPC_STUB ITestService_SetupInboxTests_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITestService_SetupSignupTests_Proxy( 
    ITestService * This);


void __RPC_STUB ITestService_SetupSignupTests_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITestService_INTERFACE_DEFINED__ */


#ifndef __IMessengerService_INTERFACE_DEFINED__
#define __IMessengerService_INTERFACE_DEFINED__

/* interface IMessengerService */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IMessengerService;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("F1A54EDF-A417-4ADE-AA38-801BCD899664")
    IMessengerService : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetCurrentVersion( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IMessengerServiceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IMessengerService * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IMessengerService * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IMessengerService * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IMessengerService * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IMessengerService * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IMessengerService * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IMessengerService * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetCurrentVersion )( 
            IMessengerService * This,
            /* [retval][out] */ BSTR *pVal);
        
        END_INTERFACE
    } IMessengerServiceVtbl;

    interface IMessengerService
    {
        CONST_VTBL struct IMessengerServiceVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMessengerService_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMessengerService_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMessengerService_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMessengerService_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IMessengerService_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IMessengerService_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IMessengerService_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IMessengerService_GetCurrentVersion(This,pVal)	\
    (This)->lpVtbl -> GetCurrentVersion(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IMessengerService_GetCurrentVersion_Proxy( 
    IMessengerService * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IMessengerService_GetCurrentVersion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IMessengerService_INTERFACE_DEFINED__ */



#ifndef __EsendexLib_LIBRARY_DEFINED__
#define __EsendexLib_LIBRARY_DEFINED__

/* library EsendexLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_EsendexLib;

EXTERN_C const CLSID CLSID_SendService2;

#ifdef __cplusplus

class DECLSPEC_UUID("EC711225-61CA-4992-A48B-44453957FB54")
SendService2;
#endif

EXTERN_C const CLSID CLSID_StringCollection2;

#ifdef __cplusplus

class DECLSPEC_UUID("E5B75431-6C0B-438b-A560-99D682B988B8")
StringCollection2;
#endif

EXTERN_C const CLSID CLSID_InboxService2;

#ifdef __cplusplus

class DECLSPEC_UUID("11BC71C9-E410-446b-BA08-241F32C2D3C6")
InboxService2;
#endif

EXTERN_C const CLSID CLSID_AccountService;

#ifdef __cplusplus

class DECLSPEC_UUID("6964E153-7999-40B0-8A7D-05CDD4D6B7C0")
AccountService;
#endif

EXTERN_C const CLSID CLSID_SMSMessage2;

#ifdef __cplusplus

class DECLSPEC_UUID("FBD44C3B-5A03-4fba-8044-A1D9A8D5BD42")
SMSMessage2;
#endif

EXTERN_C const CLSID CLSID_ContactService;

#ifdef __cplusplus

class DECLSPEC_UUID("FC4B1994-DE90-4655-85A8-AADE7C405261")
ContactService;
#endif

EXTERN_C const CLSID CLSID_SignupService;

#ifdef __cplusplus

class DECLSPEC_UUID("E566C526-B40F-4539-B3E2-F6A4C5911B87")
SignupService;
#endif

EXTERN_C const CLSID CLSID_ObjectCollection;

#ifdef __cplusplus

class DECLSPEC_UUID("A2A9134A-5B61-4785-9652-70635F5F67A8")
ObjectCollection;
#endif

EXTERN_C const CLSID CLSID_Contact;

#ifdef __cplusplus

class DECLSPEC_UUID("C4A0F7F2-5BA0-4EBE-AEE9-E65EA63330ED")
Contact;
#endif

EXTERN_C const CLSID CLSID_ContactGroup;

#ifdef __cplusplus

class DECLSPEC_UUID("CD076658-CC44-4FE3-A696-470B50BE2595")
ContactGroup;
#endif

EXTERN_C const CLSID CLSID_TestService;

#ifdef __cplusplus

class DECLSPEC_UUID("C8E14693-88CF-47C2-A802-159AD787545F")
TestService;
#endif

EXTERN_C const CLSID CLSID_SignupCompletionElements;

#ifdef __cplusplus

class DECLSPEC_UUID("3AAA4707-C4EE-441F-8F0F-9D87A9F9E8AC")
SignupCompletionElements;
#endif

EXTERN_C const CLSID CLSID_AccountState;

#ifdef __cplusplus

class DECLSPEC_UUID("DC986047-4EA9-4C08-9ACA-3935B53F8FC3")
AccountState;
#endif

EXTERN_C const CLSID CLSID_MessengerService;

#ifdef __cplusplus

class DECLSPEC_UUID("BFEE1DEB-E2E8-492B-A838-8F7CE4371AE2")
MessengerService;
#endif
#endif /* __EsendexLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long *, BSTR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long *, unsigned long            , VARIANT * ); 
unsigned char * __RPC_USER  VARIANT_UserMarshal(  unsigned long *, unsigned char *, VARIANT * ); 
unsigned char * __RPC_USER  VARIANT_UserUnmarshal(unsigned long *, unsigned char *, VARIANT * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long *, VARIANT * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


