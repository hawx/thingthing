// Utils.cpp: implementation of the CUtils class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Utils.h"

MESSAGE_STATUS StringToMessageStatus(LPCWSTR pwszStatus)
{
	if (wcscmp(pwszStatus, L"Queued")==0)
		return MESSAGE_STATUS_QUEUED;
	else if (wcscmp(pwszStatus, L"Sent")==0)
		return MESSAGE_STATUS_SENT;
	else if (wcscmp(pwszStatus, L"Delivered")==0)
		return MESSAGE_STATUS_DELIVERED;
	else if (wcscmp(pwszStatus, L"Failed")==0)
		return MESSAGE_STATUS_FAILED;
	else
	{
		ATLASSERT(!"Unknown message status");
		return (MESSAGE_STATUS)0;
	}
}

MESSAGE_TYPE StringToMessageType(LPCWSTR pwszType)
{
	if (wcscmp(pwszType, L"Text")==0)
		return MESSAGE_TYPE_TEXT;
	else if (wcscmp(pwszType, L"Unicode")==0)
		return MESSAGE_TYPE_UNICODE;
	else if (wcscmp(pwszType, L"SmartMessage")==0)
		return MESSAGE_TYPE_SMARTMESSAGE;
	else if (wcscmp(pwszType, L"Binary")==0)
		return MESSAGE_TYPE_BINARY;
	else
	{
		ATLASSERT(!"Unknown message type");
		return (MESSAGE_TYPE)0;
	}
}

CONTACT_TYPE StringToContactType(LPCWSTR pwszType)
{
	if (wcscmp(pwszType, L"Contact")==0)
		return CONTACT_TYPE_CONTACT;
	else if (wcscmp(pwszType, L"Subscriber")==0)
		return CONTACT_TYPE_SUBSCRIBER;
	else
	{
		ATLASSERT(!"Unknown contact type");
		return CONTACT_TYPE_CONTACT;
	}
}

_bstr_t ContactTypeToString(CONTACT_TYPE type)
{
	switch(type)
	{
		case CONTACT_TYPE_SUBSCRIBER:
			return _bstr_t(L"Subscriber");
		case CONTACT_TYPE_CONTACT:
			return _bstr_t(L"Contact");
		default:
			ATLASSERT(!"Unknown contact type");
			return _bstr_t(L"Contact");
	}
}

CONTACT_GROUP_TYPE StringToGroupType(LPCWSTR pwszType)
{
	if (wcscmp(pwszType, L"Group")==0)
		return CONTACT_GROUP_TYPE_GROUP;
	else if (wcscmp(pwszType, L"AllSubscribed")==0)
		return CONTACT_GROUP_TYPE_SUBSCRIBERS;
	else 
	{
		ATLASSERT(!"Unknown group type");
		return CONTACT_GROUP_TYPE_GROUP;
	}
}

_bstr_t GroupTypeToString(CONTACT_GROUP_TYPE type)
{
	switch(type)
	{
		case CONTACT_GROUP_TYPE_GROUP:
			return _bstr_t(L"Group");
		case CONTACT_GROUP_TYPE_SUBSCRIBERS:
			_bstr_t(L"AllSubscribed");
		default:
			ATLASSERT(!"Unknown group type");
			return _bstr_t(L"Group");
	}
}

long GetLongFromVariant(VARIANT var)
{
	if (var.vt==VT_I2) 
		return var.iVal; 
	else if (var.vt==VT_I4) 
		return var.lVal; 
	else if (var.vt==VT_INT) 
		return var.intVal; 
	else 
		throw (HRESULT)E_INVALIDARG;
}
