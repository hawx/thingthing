// ObjectCollection.cpp : Implementation of CObjectCollection
#include "stdafx.h"
#include "EsendexSDK.h"
#include "ObjectCollection.h"

/////////////////////////////////////////////////////////////////////////////
// CObjectCollection

STDMETHODIMP CObjectCollection::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IObjectCollection
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CObjectCollection::get_Count(long* pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_Count"); 
	try
	{
		CHECK_INIT_PTR(pVal);

		*pVal = m_coll.size();

		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CObjectCollection::get_Item(long Index, IDispatch* *pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_Item"); 
	try
	{
		CHECK_INIT_PTR(pVal);

		if (Index <= 0 || Index > (long)m_coll.size())
			ReportError(IDS_ERR_INDEX_OUT_OF_RANGE);

		// Get the iterator.
		ContainerType::iterator it = m_coll.begin();
		std::advance(it, Index - 1);

		//Get the item from the iterator
		ItemType& cItem = *it;

		//Copy to the caller
		CHECK_HR(cItem.CopyTo(pVal));

		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CObjectCollection::put_Item(long Index, IDispatch* newVal)
{
	ESENDEX_METHOD_PROLOGUE("put_Item"); 
	try
	{
		if (Index <= 0 || Index > (long)m_coll.size())
			ReportError(IDS_ERR_INDEX_OUT_OF_RANGE);

		//Replace the item
		m_coll[Index] = newVal;

		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CObjectCollection::Add(IDispatch* newVal)
{
	ESENDEX_METHOD_PROLOGUE("Add"); 
	try
	{
		m_coll.push_back(newVal);
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CObjectCollection::Remove(long Index)
{
	ESENDEX_METHOD_PROLOGUE("Remove"); 
	try
	{
		if (Index <= 0 || Index > (long)m_coll.size())
			ReportError(IDS_ERR_INDEX_OUT_OF_RANGE);

		// Get the iterator and erase the item
		ContainerType::iterator it = m_coll.begin();
		std::advance(it, Index - 1);
		m_coll.erase(it);

		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP::CObjectCollection::get__NewEnum(IUnknown** pVal)
{
	ESENDEX_METHOD_PROLOGUE("get__NewEnum"); 
	try
	{
		CHECK_INIT_PTR(pVal);
		CHECK_HR(QueryInterface(IID_IUnknown, (void**)pVal));
		m_iter = m_coll.begin();
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CObjectCollection::Next(ULONG celt, VARIANT* rgelt, ULONG* pceltFetched)
{
	ESENDEX_METHOD_PROLOGUE("Next"); 
	try
	{
		if (rgelt == NULL || (celt != 1 && pceltFetched == NULL))
			return E_POINTER;

		ULONG nActual = 0;
		HRESULT hr = S_OK;
		VARIANT* pelt = rgelt;
		while (SUCCEEDED(hr) && m_iter != m_coll.end() && nActual < celt)
		{
			//Get the item from the iterator
			ItemType& cItem = *m_iter;

			//Copy to the caller
			hr = cItem.CopyTo( (IDispatch**)&pelt->pdispVal );

			if (FAILED(hr))
			{
				while (rgelt < pelt)
					VariantClear(rgelt++);
				nActual = 0;
			}
			else
			{
				pelt->vt = VT_DISPATCH;
				pelt++;
				m_iter++;
				nActual++;
			}
		}
		if (pceltFetched)
			*pceltFetched = nActual;
		if (SUCCEEDED(hr) && (nActual < celt))
			hr = S_FALSE;
		return hr;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CObjectCollection::Skip(ULONG celt)
{
	ESENDEX_METHOD_PROLOGUE("Skip"); 
	try
	{
		HRESULT hr = S_OK;
		while (celt--)
		{
			if (m_iter != m_coll.end())
				m_iter++;
			else
			{
				hr = S_FALSE;
				break;
			}
		}
		return hr;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CObjectCollection::Reset()
{
	ESENDEX_METHOD_PROLOGUE("Reset"); 
	try
	{
		m_iter = m_coll.begin();
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CObjectCollection::Clone(IEnumVARIANT** pVal)
{
	return E_NOTIMPL;
}

STDMETHODIMP CObjectCollection::get_IDs(BSTR* pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_IDs"); 
	try
	{
		CHECK_INIT_PTR(pVal);

		// Get the iterator.
		ContainerType::iterator it = m_coll.begin();
		std::wstringstream ss;
		while (it != m_coll.end())
		{
			//Get the item from the iterator
			ItemType& cItem = *it;

			CComQIPtr<IDomainObject> spDomainObject(cItem);
			if (spDomainObject==NULL)
				ReportError(IDS_ERR_NOT_DOMAINOBJECT, E_FAIL);

			CComBSTR bstrID;
			CHECK_HR(spDomainObject->get_ID(&bstrID));

			if (it!=m_coll.begin())
				ss << L",";

			ss << (LPCWSTR)bstrID;

			it++;
		}

		//Copy to the caller
		CComBSTR bstrIDs(ss.str().c_str());
		*pVal = bstrIDs.Detach();

		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

