// MessengerService.h : Declaration of the CMessengerService

#ifndef __MESSENGERSERVICE_H_
#define __MESSENGERSERVICE_H_

#include "resource.h"       // main symbols
#include "SOAPService.h"

/////////////////////////////////////////////////////////////////////////////
// CMessengerService
class ATL_NO_VTABLE CMessengerService : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMessengerService, &CLSID_MessengerService>,
	public ISupportErrorInfo,
	public IDispatchImpl<IMessengerService, &IID_IMessengerService, &LIBID_EsendexLib, 2>,
	public CSOAPService
{
public:
	CMessengerService() : CSOAPService(L"PCMessengerService")
	{
		INIT_CLASS("CMessengerService");
	}


DECLARE_REGISTRY_RESOURCEID(IDR_MESSENGERSERVICE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMessengerService)
	COM_INTERFACE_ENTRY(IMessengerService)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IMessengerService
public:
	STDMETHOD(GetCurrentVersion)(/*[out, retval]*/ BSTR* pVal);

	DECLARE_CLASS;
};

#endif //__MESSENGERSERVICE_H_
