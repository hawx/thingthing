// InboxService.h : Declaration of the CInboxService

#ifndef __INBOXSERVICE_H_
#define __INBOXSERVICE_H_

#include "resource.h"       // main symbols
#include "SOAPService.h"

/////////////////////////////////////////////////////////////////////////////
// CInboxService
class ATL_NO_VTABLE CInboxService : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CInboxService, &CLSID_InboxService2>,
	public ISupportErrorInfo,
	public IDispatchImpl<IInboxService2, &IID_IInboxService2, &LIBID_EsendexLib, 2>,
	public CSOAPService
{
public:
	CInboxService() : CSOAPService(L"InboxService2")
	{
		INIT_CLASS("CInboxService");
	}

DECLARE_REGISTRY_RESOURCEID(IDR_INBOXSERVICE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CInboxService)
	COM_INTERFACE_ENTRY(IInboxService2)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IInboxService
public:
	STDMETHOD(GetMessages)(/*[out, retval]*/ IObjectCollection** pVal);
	STDMETHOD(DeleteMessages)(BSTR MessageIDs);
	STDMETHOD(DeleteMessage)(BSTR MessageID);
	STDMETHOD(Initialise)(BSTR Username, BSTR Password, BSTR Account, VARIANT IsServerSide);
	STDMETHOD(GetMessage)(BSTR ID, ISMSMessage2** pVal);
	STDMETHOD(GetMessagesForDay)(long Year, long Month, long Day, IObjectCollection** pVal);
	STDMETHOD(GetMessagesForDateRange)(DATE StartDate, DATE EndDate, IObjectCollection** pVal);
	STDMETHOD(GetMessagesByID)(BSTR Messages, IObjectCollection** pVal);
	STDMETHOD(GetLatestMessages)(VARIANT LastMessageIndex, VARIANT MaxMessages, IObjectCollection** pVal);

	DECLARE_CLASS;

	HRESULT	GetMessagesFromResult(MSXML::IXMLDOMNodePtr spNode, IObjectCollection** pVal);
	HRESULT GetMessageFromNode(MSXML::IXMLDOMNodePtr spMessageElement, ISMSMessage2** pVal);
};

#endif //__INBOXSERVICE_H_
