// SignupService.h : Declaration of the CSignupService

#ifndef __SIGNUPSERVICE_H_
#define __SIGNUPSERVICE_H_

#include "resource.h"       // main symbols
#include "SOAPService.h"

/////////////////////////////////////////////////////////////////////////////
// CSignupService
class ATL_NO_VTABLE CSignupService : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSignupService, &CLSID_SignupService>,
	public ISupportErrorInfo,
	public IDispatchImpl<ISignupService, &IID_ISignupService, &LIBID_EsendexLib, 2>,
	public CSOAPService
{
public:
	CSignupService() : CSOAPService(L"SignupService")
	{
		INIT_CLASS("SignupService");
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SIGNUPSERVICE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSignupService)
	COM_INTERFACE_ENTRY(ISignupService)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ISignupService
public:
	STDMETHOD(DefaultEvaluationSignup)(BSTR FirstName, BSTR LastName, BSTR CompanyName, BSTR TelephoneNumber, BSTR MobileNumber, BSTR EmailAddress, VARIANT_BOOL MailingAgreement, /*[out, retval]*/ ISignupCompletionElements** pVal);
	STDMETHOD(Initialise)(BSTR Username, BSTR Password, BSTR Account, VARIANT IsServerSide);

	DECLARE_CLASS;

};

#endif //__SIGNUPSERVICE_H_
