// SignupService.cpp : Implementation of CSignupService
#include "stdafx.h"
#include "EsendexSDK.h"
#include "SignupService.h"
#include "XmlUtils.h"

/////////////////////////////////////////////////////////////////////////////
// CSignupService

STDMETHODIMP CSignupService::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISignupService
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CSignupService::Initialise(BSTR UserName, BSTR Password, BSTR Account, VARIANT IsServerSide)
{
	return CSOAPService::Initialise(UserName, Password, Account, IsServerSide);
}

STDMETHODIMP CSignupService::DefaultEvaluationSignup(BSTR FirstName, BSTR LastName, BSTR CompanyName, BSTR TelephoneNumber, BSTR MobileNumber, BSTR EmailAddress, VARIANT_BOOL MailingAgreement, ISignupCompletionElements **pVal)
{

	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("DefaultEvaluationSignup"); 
	try
	{
		//Use CHECK_STRING_PARAM to check the parameter is not null. Throw an exception 
		//if it is null. The exception will get picked up below so we get the
		//class and method names.
		CHECK_STRING_PARAM("FirstName", FirstName);
		CHECK_STRING_PARAM("LastName", LastName);
		CHECK_STRING_PARAM("CompanyName", CompanyName);
		CHECK_STRING_PARAM("TelephoneNumber", TelephoneNumber);
		CHECK_STRING_PARAM("MobileNumber", MobileNumber);
		CHECK_STRING_PARAM("EmailAddress", EmailAddress);
		///CHECK_STRING_PARAM("MailingAgreement", MailingAgreement);

		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR(pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_DEFAULT_EVALUATION_SIGNUP)));

		//Set the values of the elements in the XML.
		CXmlUtils::SetElementValue(spDoc, L"firstName", FirstName);
		CXmlUtils::SetElementValue(spDoc, L"lastName", LastName);
		CXmlUtils::SetElementValue(spDoc, L"companyName", CompanyName);
		CXmlUtils::SetElementValue(spDoc, L"telephoneNumber", TelephoneNumber);
		CXmlUtils::SetElementValue(spDoc, L"mobileNumber", MobileNumber);
		CXmlUtils::SetElementValue(spDoc, L"emailAddress", EmailAddress);
		CXmlUtils::SetElementValue(spDoc, L"mailingAgreement", MailingAgreement);

		//Post the XML to the server.
		CHECK_HR(ExecuteNoHeader(spDoc, pszMethodName));

		//Get the result node.
		MSXML::IXMLDOMNodePtr spResultNode = CXmlUtils::GetElementByName(spDoc, L"DefaultEvaluationSignupResult");

		CComPtr<ISignupCompletionElements> spCompletionElements;
		CHECK_HR(spCompletionElements.CoCreateInstance(__uuidof(SignupCompletionElements)));

		MSXML::IXMLDOMNodePtr spXmlElement = spResultNode->firstChild;
		while (spXmlElement!=NULL)
		{
			if (wcscmp(spXmlElement->baseName, L"Username")==0)
				spCompletionElements->put_Username(spXmlElement->text);
			else if (wcscmp(spXmlElement->baseName, L"AccountReference")==0)
				spCompletionElements->put_AccountReference(spXmlElement->text);
			else if (wcscmp(spXmlElement->baseName, L"WelcomeMessage")==0)
				spCompletionElements->put_WelcomeMessage(spXmlElement->text);			
			spXmlElement = spXmlElement->nextSibling;
		}
		*pVal = spCompletionElements.Detach();
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}
