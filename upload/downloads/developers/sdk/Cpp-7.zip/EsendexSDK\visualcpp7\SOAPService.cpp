// SOAPService.cpp: implementation of the CSOAPService class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "EsendexSDK.h"
#include "resource.h"
#include "SOAPService.h"
#include "XMLUtils.h"
#include "utils.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const LPCWSTR CSOAPService::m_wstrNamespace = L"com.esendex.ems.soapinterface/";
std::wstring CSOAPService::m_wstrSoapEndPoint;
std::wstring CSOAPService::m_wstrSoapEndPointMock;


CSOAPService::CSOAPService(LPCWSTR pwszService) :
	m_wstrService(pwszService),
	m_fUseMockEndPoint(false)
{
	INIT_CLASS("CSOAPService");
}

CSOAPService::CSOAPService(LPCWSTR pwszService, bool fUseMockEndPoint) :
	m_wstrService(pwszService),
	m_fUseMockEndPoint(fUseMockEndPoint)
{
	INIT_CLASS("CSOAPService");
}

CSOAPService::~CSOAPService()
{
}

void CSOAPService::SetSoapEndPoints(BSTR bstrURI, BSTR bstrMockURI)
{
	m_wstrSoapEndPoint = bstrURI;
	m_wstrSoapEndPointMock = bstrMockURI;
}

HRESULT CSOAPService::Initialise(BSTR Username, BSTR Password, BSTR Account, VARIANT IsServerSide)
{
	ESENDEX_METHOD_PROLOGUE("Initialise"); 
	try
	{
		CHECK_STRING_PARAM("Username", Username);
		CHECK_STRING_PARAM("Password", Password);
		CHECK_STRING_PARAM("Account", Account);
		if (IsServerSide.vt==VT_BOOL && IsServerSide.boolVal==VARIANT_TRUE)
			m_bIsServerSide = VARIANT_TRUE;
		else
			m_bIsServerSide = VARIANT_FALSE;

		m_bstrUsername = Username;
		m_bstrPassword = Password;
		m_bstrAccount = Account;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

HRESULT CSOAPService::Execute(MSXML::IXMLDOMDocumentPtr& spDoc, LPCTSTR pszMethod)
{
	return Execute(spDoc, pszMethod, true);
}

HRESULT CSOAPService::ExecuteNoHeader(MSXML::IXMLDOMDocumentPtr& spDoc, LPCTSTR pszMethod)
{
	return Execute(spDoc, pszMethod, false);
}

HRESULT CSOAPService::Execute(MSXML::IXMLDOMDocumentPtr& spDoc, LPCTSTR pszMethod, bool fUsesHeader)
{
	ESENDEX_METHOD_PROLOGUE("Execute");
	try
	{
		//Calculate an endpoint for the service.
		std::wstring strServiceEndPoint;
		if (m_fUseMockEndPoint)
			strServiceEndPoint = m_wstrSoapEndPointMock;
		else
			strServiceEndPoint = m_wstrSoapEndPoint.length()>0 ? m_wstrSoapEndPoint : DEFAULT_SOAP_END_POINT;
		strServiceEndPoint += m_wstrService;
		strServiceEndPoint += L".asmx";

		if (fUsesHeader)
		{
			if (!m_bstrUsername)
				ReportError(IDS_ERR_MUST_INITIALISE);

			CXmlUtils::SetElementValue(spDoc, L"Username", m_bstrUsername);
			CXmlUtils::SetElementValue(spDoc, L"Password", m_bstrPassword);
			CXmlUtils::SetElementValue(spDoc, L"Account", m_bstrAccount);
		}

		MSXML::IXMLHttpRequestPtr spRequest;
		HRESULT hr;
		if (m_bIsServerSide)
		{
			log.debug("Creating COM object MSXML2.ServerXMLHTTP");
			hr = spRequest.CreateInstance(L"MSXML2.ServerXMLHTTP");
		}
		else
		{
			log.debug("Creating COM object Microsoft.XMLHTTP");
			hr = spRequest.CreateInstance(L"Microsoft.XMLHTTP");
		}

		if (FAILED(hr))
			ReportError(IDS_ERR_CREATE_SERVER_XML_HTTP);

		log.debug("Open POST request to endpoint %S", strServiceEndPoint.c_str());
		hr = spRequest->raw_open(L"POST", (BSTR)strServiceEndPoint.c_str(), _variant_t(VARIANT_FALSE));
		if (FAILED(hr))
			ReportMsxmlError(hr, IDS_ERR_MSXML, "open");

		hr = spRequest->raw_setRequestHeader(L"Content-Type", L"text/xml;charset=utf-8");
		if (FAILED(hr))
			ReportMsxmlError(hr, IDS_ERR_MSXML, "setRequestHeader");

		_bstr_t bstrSOAPAction(m_wstrNamespace);
		bstrSOAPAction+=pszMethod;

		log.debug("SOAP Action: %S", (LPCWSTR)bstrSOAPAction);
		hr = spRequest->raw_setRequestHeader(L"SOAPAction", bstrSOAPAction);
		if (FAILED(hr))
			ReportMsxmlError(hr, IDS_ERR_MSXML, "setRequestHeader");

		log.debug("XML request: %s", (TCHAR*)spDoc->xml);
		hr = spRequest->raw_send(_variant_t(spDoc->xml));
		if (FAILED(hr))
			ReportMsxmlError(hr, IDS_ERR_MSXML, "send");

		if (spRequest->status!=200 && spRequest->status!=500)
			ReportErrorVA(E_FAIL, IDS_ERR_HTTP_STATUS, spRequest->status, (LPCTSTR)spRequest->statusText); 

		std::string strResponse((LPCTSTR)spRequest->responseText);
		log.debug("XML response: %s", strResponse.c_str());

		/*
		
		CHGlobal cHGlobal(GMEM_MOVEABLE, strResponse.length());
		LPTSTR psz = (LPTSTR)cHGlobal.Lock();
		memmove(psz, strResponse.c_str(), strResponse.length());
		cHGlobal.Unlock();

		CComPtr<IStream> spStream;
		cHGlobal.CreateStream(&spStream);

		_variant_t varSource(spStream);
		if (!spDoc->load(varSource))
		{
			//Report any XML parse error.
			_bstr_t bstrText;
			CXmlUtils::GetXMLParseError(spDoc, bstrText);
			ReportErrorVA(E_FAIL, IDS_ERR_PARSE_XML_RESPONSE, (LPCTSTR)bstrText); 
		}*/

		spDoc = spRequest->responseXML;
		
		if (spRequest->status==500)
		{
			//See end for sample error XML
			//Check for Esendex-specific error detail
			MSXML::IXMLDOMNodePtr spErrorMessageNode = spDoc->selectSingleNode(L"//detail/ErrorMessage");
			if (spErrorMessageNode!=NULL)
			{
				MSXML::IXMLDOMNodePtr spErrorCodeNode = spDoc->selectSingleNode(L"//detail/ErrorCode");
				ReportSoapError(spErrorMessageNode->text, spErrorCodeNode->text);
			}
			else
			{
				//No Esendex-specific error. Look for a fault string.
				_bstr_t bstrError = CXmlUtils::GetElementValue(spDoc, L"faultstring");
				if (NULL!=(BSTR)bstrError)
					ReportError(bstrError, E_FAIL);
				else
					//No fault string. Report back the whole response
					ReportError((LPCWSTR)spRequest->responseText, E_FAIL);
			}
		}
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

/*
void CSOAPService::ReportSoapError(LPCWSTR pwszError)
{
	long nError = ERROR_CODE_UNEXPECTED;

	WCHAR* pwszSoapException = L"System.Web.Services.Protocols.SoapException:";

	WCHAR* pwszMessageStart = wcsstr(pwszError, pwszSoapException);
	if (pwszMessageStart)
	{
		pwszMessageStart += wcslen(pwszSoapException);
		while(iswspace(*pwszMessageStart))
			pwszMessageStart++;

		WCHAR* pwszErrorUpper = _wcsdup(pwszError);
		pwszErrorUpper = wcsupr(pwszErrorUpper);

		if (wcsstr(pwszErrorUpper, L"AUTHENTICATION FAILED"))
			nError = ERROR_CODE_AUTHENTICATION_FAILED;
		else if (wcsstr(pwszErrorUpper, L"HEADER IS MISSING"))
			nError = ERROR_CODE_MISSING_HEADER;
		else if (wcsstr(pwszErrorUpper, L"RECIPIENT MISSING"))
			nError = ERROR_CODE_RECIPIENT_MISSING;
		else if (wcsstr(pwszErrorUpper, L"ACCOUNT IS NOT LIVE"))
			nError = ERROR_CODE_ACCOUNT_NOT_LIVE;
		else if (wcsstr(pwszErrorUpper, L"METHOD NOT ENABLED"))
			nError = ERROR_CODE_METHOD_NOT_ENABLED;
		else if (wcsstr(pwszErrorUpper, L"FEATURE IS NOT SUPPORTED"))
			nError = ERROR_CODE_FEATURE_NOT_SUPPORTED;
		else if (wcsstr(pwszErrorUpper, L"MESSAGE NOT FOUND"))
			nError = ERROR_CODE_MESSAGE_NOT_FOUND;
		else if (wcsstr(pwszErrorUpper, L"RECIPIENTS APPEARED TO BE INVALID"))
			nError = ERROR_CODE_RECIPIENT_INVALID;
		else if (wcsstr(pwszErrorUpper, L"MESSAGE LIMIT EXCEEDED"))
			nError = ERROR_CODE_MESSAGE_LIMIT_EXCEEDED;
		else if (wcsstr(pwszErrorUpper, L"MESSAGE ID FORMAT NOT RECOGNISED"))
			nError = ERROR_CODE_MESSAGE_ID_FORMAT_INVALID;
		else if (wcsstr(pwszErrorUpper, L"USERNAME ALREADY EXISTS"))
			nError = ERROR_CODE_USERNAME_ALREADY_EXISTS;
		else if (wcsstr(pwszErrorUpper, L"CONTACT ALREADY EXISTS"))
			nError = ERROR_CODE_CONTACT_ALREADY_EXISTS;
		else if (wcsstr(pwszErrorUpper, L"CONTACT GROUP ALREADY EXISTS"))
			nError = ERROR_CODE_CONTACT_GROUP_ALREADY_EXISTS;
		else if (wcsstr(pwszErrorUpper, L"CONTACT OR CONTACT GROUP ALREADY EXISTS"))
			nError = ERROR_CODE_CONTACT_OR_GROUP_ALREADY_EXISTS;

		free(pwszErrorUpper);

		WCHAR* pwszMessageEnd = wcsstr(pwszError, L"\n");
		if (pwszMessageEnd)
			*pwszMessageEnd = 0;
	}
	else
		pwszMessageStart = (WCHAR*)pwszError;

	ReportError(pwszMessageStart, MAKE_HRESULT(SEVERITY_ERROR, FACILITY_DISPATCH, nError));
}
*/

void CSOAPService::ReportSoapError(LPCWSTR pwszErrorMessage, LPCWSTR pwszErrorCode)
{
	int nError = _wtol(pwszErrorCode);
	//ERROR_CODE errorCode = (ERROR_CODE)nError;
	ReportError(pwszErrorMessage, MAKE_HRESULT(SEVERITY_ERROR, FACILITY_DISPATCH, nError));
}

/*
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">  <soap:Body>    <soap:Fault>      <faultcode>soap:Client</faultcode>      <faultstring>System.Web.Services.Protocols.SoapException: Authentication Failed   at com.esendex.ems.soapinterface.SendService.SendMessage(String recipient, String body, MessageType type) in C:\Dev\wip\com\esendex\ems\soapinterface\SendService.asmx.cs:line 41</faultstring>      <detail>        <ErrorCode>2</ErrorCode>        <ErrorMessage>Authentication Failed</ErrorMessage>      </detail>    </soap:Fault>  </soap:Body></soap:Envelope>*/