// XmlUtils.h
//
#pragma once
#import "msxml.dll" raw_interfaces_only, raw_native_types 
#include <set>
#include <map>
#include <utility>

#include "StringCollection.h"

class CXmlUtils
{
public:
	// Get an element by name. Assumes that the name is unique.
	static MSXML::IXMLDOMNodePtr GetElementByName(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag);

	// Set/get the value of a named element. Assumes that the name is unique.
	static _bstr_t GetElementValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag);
	static long GetElementValueLong(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag);
	static HRESULT SetElementValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag, LPCWSTR pwszValue);
	static HRESULT SetElementValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag, long Value);
	static HRESULT SetElementValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag, DATE Value);
	static HRESULT SetElementValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag, SYSTEMTIME systemTime);

	static HRESULT SetElementValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag, VARIANT_BOOL boolValue);
	static HRESULT SetElementArrayValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag, VARIANT arrValue);
	static HRESULT SetElementArrayValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag, BSTR bstrArrayValue);
	static HRESULT AddTextElement(MSXML::IXMLDOMDocumentPtr& spXMLDoc, MSXML::IXMLDOMNodePtr spParentNode, BSTR bstrName, BSTR bstrValue);

	static void GetElementArrayValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag, IStringCollection2** pVal);
	static void DeleteNodeChildren(MSXML::IXMLDOMNodePtr& spNode);
	static DATE ParseDate(BSTR bstrDate);
	static void StoreDate(DATE date, BSTR* pVal);
	static void StoreDateTime(DATE date, BSTR* pVal);
	static void StoreDateTime(SYSTEMTIME systemTime, BSTR* pVal);

	static HRESULT LoadXMLDocFromResource(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCTSTR pszResId);

	static bool GetXMLParseError(MSXML::IXMLDOMDocument* pXMLDoc, _bstr_t& bstrText);

	DECLARE_STATIC_CLASS;
};







