// XmlUtils.cpp

#include "stdafx.h"
#include "EsendexSDK.h"
#include "XmlUtils.h"
#include "CResource.h"
#include <sstream>
#include "Resource.h"
#include <string.h>
#include <oleauto.h>
#include <time.h>

INIT_STATIC_CLASS(CXmlUtils, "CXmlUtils");

extern const WCHAR* g_pwszMSXMLProgID;

// Does what it says...
HRESULT CXmlUtils::LoadXMLDocFromResource(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCTSTR pszResId)
{
	ESENDEX_METHOD_PROLOGUE("LoadXMLDocFromResource");
	try
	{
		//Load the specified resource.
		CResource resource;
		CHECK_HR(resource.Load(pszResId, "XML"));
	
		//Get the resource string as a BSTR.
		_bstr_t bstrXML;
		CHECK_HR(resource.GetBSTR(bstrXML));

		//Instantiate an XML doc.
		//HRESULT hr = spXMLDoc.CreateInstance(__uuidof(MSXML::DOMDocument)); //Version independent progid
		//HRESULT hr = spXMLDoc.CreateInstance(L"Msxml2.DOMDocument.2.6"); //v2.6 for testing
		//HRESULT hr = spXMLDoc.CreateInstance(g_pwszMSXMLProgID); 
		HRESULT hr = spXMLDoc.CreateInstance(__uuidof(MSXML::DOMDocument));
		if (FAILED(hr))
			ReportError(IDS_ERR_DOM_FROM_XML);

		// Load the XML from the BSTR buffer
		if (spXMLDoc->loadXML(bstrXML)==VARIANT_FALSE)
		{
			//Report any XML parse error.
			_bstr_t bstrText;
			GetXMLParseError(spXMLDoc, bstrText);
			ReportError(bstrText);
		}

		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}





bool CXmlUtils::GetXMLParseError(MSXML::IXMLDOMDocument* pXMLDoc, _bstr_t& bstrText)
{
	long lLine, lCol, lErrNo;
	CComPtr<MSXML::IXMLDOMParseError> spErrorObj;	
	pXMLDoc->get_parseError(&spErrorObj);
	spErrorObj->get_errorCode(&lErrNo);
	if (0 == lErrNo)
		return true;

	CComBSTR bstrReason;
	spErrorObj->get_reason(&bstrReason);		
	CComBSTR bstrSrc;
	spErrorObj->get_srcText(&bstrSrc);
	spErrorObj->get_line(&lLine);
	spErrorObj->get_linepos(&lCol);

	std::wstringstream strTemp;
	strTemp << L"Line: " << lLine << L" Col: " << lCol << L" Reason: " << (LPCWSTR)bstrReason << ((BSTR)bstrSrc==(BSTR)NULL ? LPCWSTR(bstrSrc): L"");

	bstrText = strTemp.str().c_str();
	
	return false;
}


// Get an element by name. Assumes that the name is unique.
MSXML::IXMLDOMNodePtr CXmlUtils::GetElementByName(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR bstrTag)
{
	MSXML::IXMLDOMNodeListPtr spNodeList = spXMLDoc->getElementsByTagName(bstrTag);

	long lCount;
	spNodeList->get_length(&lCount);

	if (0 == lCount)
		return NULL;

	_ASSERTE(lCount == 1);

	return spNodeList->Getitem(0);
}


// Set the value of a named element. Assumes that the name is unique.
HRESULT CXmlUtils::SetElementValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag, LPCWSTR pwszValue)
{
	MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spXMLDoc, pwszTag);
	if (spNode==NULL)
		ReportErrorVA(E_FAIL, IDS_ERR_ELEMENT_NOT_FOUND, (LPCTSTR)_bstr_t(pwszTag));

	MSXML::IXMLDOMNodeListPtr spNodes = spNode->GetchildNodes();
	if (spNodes->length!=1)
		ReportError(IDS_ERR_TEXT_NODE_NOT_FOUND);

	MSXML::IXMLDOMNodePtr spTextNode = spNodes->Getitem(0);
	
//	CComPtr<MSXML::IXMLDOMNode> spTextNode = 
//		spXMLDoc->createNode(_variant_t ((long)MSXML::NODE_TEXT), pwszValue, _bstr_t());

	_variant_t Value(pwszValue);
	CHECK_HR(spTextNode->put_nodeValue(Value));
	/*
	VARIANT  after;
	after.vt = VT_EMPTY;
	CComPtr<MSXML::IXMLDOMNode> spInsertedTextNode;
	spInsertedTextNode = spNode->insertBefore(spTextNode, after);
*/
	return S_OK;
}

HRESULT CXmlUtils::SetElementValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag, long lValue)
{
	std::wstringstream s;
	s << lValue << std::ends;
	return SetElementValue(spXMLDoc, pwszTag, s.str().c_str());
}

HRESULT CXmlUtils::SetElementValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag, DATE dateValue)
{
	CComBSTR bstrDate;
	StoreDateTime(dateValue, &bstrDate);
	return SetElementValue(spXMLDoc, pwszTag, (LPCWSTR)bstrDate);
}

HRESULT CXmlUtils::SetElementValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag, SYSTEMTIME systemTime)
{
	CComBSTR bstrDate;
	StoreDateTime(systemTime, &bstrDate);
	return SetElementValue(spXMLDoc, pwszTag, (LPCWSTR)bstrDate);
}

HRESULT CXmlUtils::SetElementValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag, VARIANT_BOOL boolValue)
{
	return SetElementValue(spXMLDoc, pwszTag, boolValue==VARIANT_TRUE ? L"true" : L"false");
}

void CXmlUtils::DeleteNodeChildren(MSXML::IXMLDOMNodePtr& spParent)
{
	MSXML::IXMLDOMNodePtr spChild = spParent->firstChild;
	while(spChild)
	{
		MSXML::IXMLDOMNodePtr spNextChild = spChild->nextSibling;
		spParent->removeChild(spChild);
		spChild = spNextChild;
	}
}

HRESULT CXmlUtils::SetElementArrayValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag, BSTR bstrArrayValue)
{
	VARIANT varArrayValue;
	if (bstrArrayValue==NULL)
		varArrayValue.vt = VT_EMPTY;
	else
	{
		varArrayValue.vt = VT_BSTR;
		varArrayValue.bstrVal = bstrArrayValue;
	}	
	return SetElementArrayValue(spXMLDoc, pwszTag, varArrayValue);
}

HRESULT CXmlUtils::SetElementArrayValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag, VARIANT arrValue)
{
	ATLASSERT( (arrValue.vt==VT_BSTR && arrValue.bstrVal!=NULL) ||
			   (arrValue.vt==VT_DISPATCH && arrValue.pdispVal!=NULL) ||
			    arrValue.vt==VT_EMPTY || arrValue.vt==VT_ERROR);

	//Get the node.
	MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spXMLDoc, pwszTag);
	if (spNode==NULL)
		ReportErrorVA(E_FAIL, IDS_ERR_ELEMENT_NOT_FOUND, (LPCTSTR)_bstr_t(pwszTag));

	//Delete the node's children.
	DeleteNodeChildren(spNode);

	if (arrValue.vt==VT_BSTR)
	{
		//Copy the value passed in so we can modify it.
		_bstr_t bstrValueCopy(arrValue.bstrVal);

		wchar_t* token = wcstok( (LPWSTR)bstrValueCopy, L"," );
		while(token!=NULL)
		{
			MSXML::IXMLDOMNodePtr spChildNode = 
				spXMLDoc->createNode((long)MSXML::NODE_ELEMENT, L"string", spNode->namespaceURI);
			spNode->appendChild(spChildNode);
			MSXML::IXMLDOMNodePtr spTextNode = 
				spXMLDoc->createNode(_variant_t((long)MSXML::NODE_TEXT), token, _bstr_t());
			spTextNode->nodeValue = token;
			spChildNode->appendChild(spTextNode);
			token = wcstok( NULL, L"," );
		}
	}
	else if (arrValue.vt==VT_DISPATCH)
	{
		CComQIPtr<IStringCollection2> spStrings(arrValue.pdispVal);
		if (spStrings)
		{
			long nItems;
			CHECK_HR(spStrings->get_Count(&nItems));
			for (long i=1; i<=nItems; i++)
			{
				CComBSTR bstrItem;
				CHECK_HR(spStrings->get_Item(i, &bstrItem));
				AddTextElement(spXMLDoc, spNode, L"string", bstrItem.m_str);
			}
		}
		else
		{
			CComQIPtr<IObjectCollection> spObjects(arrValue.pdispVal);
			if (spObjects)
			{
				long nItems;
				CHECK_HR(spObjects->get_Count(&nItems));
				for (long i=1; i<=nItems; i++)
				{
					CComQIPtr<IDispatch> spObject;
					CHECK_HR(spObjects->get_Item(i, &spObject));
					CComQIPtr<IDomainObject> spDomainObject(spObject);
					if (!spDomainObject)
						ReportError(IDS_ERR_NOT_DOMAINOBJECT);
					CComBSTR bstrItem;
					CHECK_HR(spDomainObject->get_ID(&bstrItem));
					AddTextElement(spXMLDoc, spNode, L"string", bstrItem.m_str);
				}
			}
			else
			{
				ATLASSERT(!"Collection type not recognised");
			}
		}
	}

	return S_OK;
}

HRESULT CXmlUtils::AddTextElement(MSXML::IXMLDOMDocumentPtr& spXMLDoc, MSXML::IXMLDOMNodePtr spParentNode, BSTR bstrName, BSTR bstrValue)
{
	MSXML::IXMLDOMNodePtr spChildNode = 
		spXMLDoc->createNode((long)MSXML::NODE_ELEMENT, bstrName, spParentNode->namespaceURI);
	spParentNode->appendChild(spChildNode);

	MSXML::IXMLDOMNodePtr spTextNode = 
			spXMLDoc->createNode(_variant_t((long)MSXML::NODE_TEXT), bstrValue, _bstr_t());
	spTextNode->nodeValue = bstrValue;
	spChildNode->appendChild(spTextNode);
	return S_OK;
}


void CXmlUtils::GetElementArrayValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag, IStringCollection2** pVal)
{
	//Get the node.
	MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spXMLDoc, pwszTag);
	if (spNode==NULL)
		ReportErrorVA(E_FAIL, IDS_ERR_ELEMENT_NOT_FOUND, (LPCTSTR)_bstr_t(pwszTag));

	//Create a string collection to hold the return values.
	CComPtr<IStringCollection2> spStringCollection;
	CHECK_HR(spStringCollection.CoCreateInstance(__uuidof(StringCollection2)));

	//Get the child values.
	MSXML::IXMLDOMNodePtr spChild = spNode->firstChild;
	while(spChild)
	{
		spStringCollection->Add(spChild->text);		
		spChild = spChild->nextSibling;
	}

	*pVal = spStringCollection.Detach();
}

_bstr_t CXmlUtils::GetElementValue(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag)
{
	// Get the element
	MSXML::IXMLDOMNodePtr spNode = GetElementByName(spXMLDoc, pwszTag);
	return spNode!=NULL ? spNode->text : _bstr_t((BSTR)NULL);
}

long CXmlUtils::GetElementValueLong(MSXML::IXMLDOMDocumentPtr& spXMLDoc, LPCWSTR pwszTag)
{
	// Get the element
	MSXML::IXMLDOMNodePtr spNode = GetElementByName(spXMLDoc, pwszTag);
	if (spNode==NULL)
		return 0;
	_variant_t varTyped = spNode->nodeTypedValue;
	CHECK_VARIANT_LONG_PARAM("", varTyped);
	return varTyped.lVal;
}

DATE CXmlUtils::ParseDate(BSTR bstrDate)
{
	int year, month, day, hour, min, sec, milli;
	float bias;
	try
	{
		sscanf((LPCTSTR)_bstr_t(bstrDate), "%d-%02d-%02dT%02d:%02d:%02d.%07d%f",
			&year,
			&month,
			&day,
			&hour,
			&min,
			&sec,
			&milli,
			&bias);
	}
	catch(...)
	{
		USES_CONVERSION;
		_bstr_t bstrTemp(bstrDate);
		ReportErrorVA(E_FAIL, IDS_ERR_PARSE_DATE, (LPCTSTR)bstrTemp);
	}


	SYSTEMTIME st;
	st.wYear = year;
	st.wMonth = month;
	st.wDay = day;
	st.wHour = hour;
	st.wMinute = min;
	st.wSecond = sec;
	st.wMilliseconds = milli;
	st.wDayOfWeek = 0;

	/*
	//Convert to UTC
	if (bias!=0)
	{
		int biasHours = (int)bias;
		int biasMins = (int)((bias - biasHours)*100);
	

		ULONGLONG& timeInHundredthsOfNanos = reinterpret_cast<ULONGLONG&>(ft);
		timeInHundredthsOfNanos += (long)biasHours * 10,000,000 * 60 * 60;
		timeInHundredthsOfNanos += (long)biasMins * 10,000,000 * 60;

		FILETIME ft;
		SystemTimeToFileTime(&st, &ft);

		ft = reinterpret_cast<FILETIME&>(timeInHundredthsOfNanos);
		FileTimeToSystemTime(&ft, &st);
	}
	*/

	DATE date;
	SystemTimeToVariantTime(&st, &date);

	return date;
}

void CXmlUtils::StoreDate(DATE date, BSTR* pVal)
{
	SYSTEMTIME  systemTime;
	VariantTimeToSystemTime(date, &systemTime);
	systemTime.wHour = 0;
	systemTime.wMinute = 0;
	systemTime.wSecond = 0;
	systemTime.wMilliseconds = 0;
	StoreDateTime(systemTime, pVal);
}

void CXmlUtils::StoreDateTime(DATE date, BSTR* pVal)
{
	SYSTEMTIME  systemTime;
	VariantTimeToSystemTime(date, &systemTime);
	StoreDateTime(systemTime, pVal);
}

void CXmlUtils::StoreDateTime(SYSTEMTIME systemTime, BSTR* pVal)
{

	TIME_ZONE_INFORMATION tz;
	DWORD dwMode = GetTimeZoneInformation(&tz);
	tz.Bias *= -1;
	if (dwMode==TIME_ZONE_ID_STANDARD)
		tz.Bias += tz.StandardBias;
	else if (dwMode==TIME_ZONE_ID_DAYLIGHT)
		tz.Bias += tz.DaylightBias;
	tz.Bias *= -1;

	int biasHours = (int)(tz.Bias / 60);
	int biasMins = (int)(tz.Bias % 60);

	BSTR bstrDate = SysAllocStringLen(NULL, 40);

	WCHAR wszTimeZone[7];
	ZeroMemory(&wszTimeZone, sizeof(wszTimeZone));
	swprintf(wszTimeZone, L" %02d:%02d", abs(biasHours), abs(biasMins));
	wszTimeZone[0] = tz.Bias<0 ? '-' : '+';
	
	swprintf(bstrDate, L"%d-%02d-%02dT%02d:%02d:%02d.%07d%s", 
		systemTime.wYear, 
		systemTime.wMonth, 
		systemTime.wDay,
		systemTime.wHour,
		systemTime.wMinute,
		systemTime.wSecond,
		(long)systemTime.wMilliseconds*10000,
		wszTimeZone
		);
	*pVal = bstrDate;
}

