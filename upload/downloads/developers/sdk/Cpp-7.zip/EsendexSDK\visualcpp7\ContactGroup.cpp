// ContactGroup.cpp : Implementation of CContactGroup
#include "stdafx.h"
#include "EsendexSDK.h"
#include "ContactGroup.h"

/////////////////////////////////////////////////////////////////////////////
// CContactGroup

STDMETHODIMP CContactGroup::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IContactGroup
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CContactGroup::GetLocalObject(IUnknown**pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	*pVal = (LPUNKNOWN)(void*)this;
	return S_OK;
}

STDMETHODIMP CContactGroup::get_ID(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrID.CopyTo(pVal);
}

STDMETHODIMP CContactGroup::put_ID(BSTR newVal)
{
	m_bstrID = newVal;
	return S_OK;
}

STDMETHODIMP CContactGroup::get_Name(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrName.CopyTo(pVal);
}

STDMETHODIMP CContactGroup::put_Name(BSTR newVal)
{
	m_bstrName = newVal;
	return S_OK;
}

STDMETHODIMP CContactGroup::get_Description(BSTR *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	return m_bstrDescription.CopyTo(pVal);
}

STDMETHODIMP CContactGroup::put_Description(BSTR newVal)
{
	m_bstrDescription = newVal;
	return S_OK;
}

STDMETHODIMP CContactGroup::get_GroupType(CONTACT_GROUP_TYPE *pVal)
{
	if (!pVal)
		return E_INVALIDARG;
	*pVal = m_groupType;
	return S_OK;
}

STDMETHODIMP CContactGroup::put_GroupType(CONTACT_GROUP_TYPE newVal)
{
	m_groupType = newVal;
	return S_OK;
}
