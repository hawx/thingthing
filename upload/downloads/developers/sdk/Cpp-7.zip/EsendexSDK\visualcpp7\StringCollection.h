// StringCollection.h : Declaration of the CStringCollection

#ifndef __STRINGCOLLECTION_H_
#define __STRINGCOLLECTION_H_

#include "resource.h"       // main symbols

#include <vector>

/////////////////////////////////////////////////////////////////////////////
// CStringCollection
class ATL_NO_VTABLE CStringCollection : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CStringCollection, &CLSID_StringCollection2>,
	public ISupportErrorInfo,
	public IDispatchImpl<IStringCollection2, &IID_IStringCollection2, &LIBID_EsendexLib, 2>,
	public IEnumVARIANT
{
public:
	CStringCollection()
	{
		INIT_CLASS("CStringCollection");
	}

DECLARE_REGISTRY_RESOURCEID(IDR_STRINGCOLLECTION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CStringCollection)
	COM_INTERFACE_ENTRY(IStringCollection2)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IEnumVARIANT)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IStringCollection
public:
	STDMETHOD(get__NewEnum)(IUnknown** pVal);
	STDMETHOD(get_Item)(long Index, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Item)(long Index, /*[in]*/ BSTR newVal);
	STDMETHOD(Add)(BSTR newVal);
	STDMETHOD(Remove)(long Index);
	STDMETHOD(get_Count)(long* pVal);

//IEnumVARIANT
	STDMETHOD(Next)(ULONG celt, VARIANT*, ULONG* pceltFetched);
	STDMETHOD(Skip)(ULONG celt);
	STDMETHOD(Reset)(void);
	STDMETHOD(Clone)(IEnumVARIANT** pVal);

	DECLARE_CLASS;

	typedef std::vector< CComBSTR >	ContainerType;

	ContainerType m_coll;
	ContainerType::iterator m_iter;
};

#endif //__STRINGCOLLECTION_H_
