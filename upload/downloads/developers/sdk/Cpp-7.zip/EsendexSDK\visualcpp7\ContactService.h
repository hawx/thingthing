// ContactService.h : Declaration of the CContactService

#ifndef __CONTACTSERVICE_H_
#define __CONTACTSERVICE_H_

#include "resource.h"       // main symbols
#include "SOAPService.h"

/////////////////////////////////////////////////////////////////////////////
// CContactService
class ATL_NO_VTABLE CContactService : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CContactService, &CLSID_ContactService>,
	public ISupportErrorInfo,
	public IDispatchImpl<IContactService, &IID_IContactService, &LIBID_EsendexLib, 2>,
	public CSOAPService
{
public:
	CContactService() : CSOAPService(L"ContactService")
	{
		INIT_CLASS("ContactService");
	}
	virtual ~CContactService()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CONTACTSERVICE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CContactService)
	COM_INTERFACE_ENTRY(IContactService)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IContactService
public:
	STDMETHOD(GetGroupByName)(BSTR Name, IContactGroup **pVal);
	STDMETHOD(GetContactByQuickName)(BSTR Name, IContact **pVal);
	STDMETHOD(GetGroupMembers)(BSTR ID, /*[out, retval]*/ IObjectCollection** pVal);
	STDMETHOD(GetGroup)(BSTR ID, /*[out, retval]*/ IContactGroup** pVal);
	STDMETHOD(GetContact)(BSTR ID, /*[out, retval]*/ IContact** pVal);
	STDMETHOD(UpdateGroup)(IContactGroup* ContactGroup, BSTR MemberIDs);
	STDMETHOD(UpdateContact)(IContact* Contact);
	STDMETHOD(DeleteContact)(BSTR ContactID);
	STDMETHOD(DeleteContacts)(BSTR ContactIDs);
	STDMETHOD(DeleteGroup)(BSTR GroupID, VARIANT IncludeMembers);
	STDMETHOD(DeleteGroups)(BSTR GroupID);
	STDMETHOD(AddGroup)(IContactGroup* Group, BSTR MemberIDs, BSTR* pVal);
	STDMETHOD(AddContact)(IContact* Contact, BSTR* pVal);
	STDMETHOD(AddContacts)(IObjectCollection* Contacts, IStringCollection2** pVal);
	STDMETHOD(GetGroups)(IObjectCollection** pVal);
	STDMETHOD(GetContacts)(IObjectCollection** pVal);
	STDMETHOD(Initialise)(BSTR Username, BSTR Password, BSTR Account, VARIANT IsServerSide);

	DECLARE_CLASS;

	typedef enum {OBJECT_TYPE_CONTACT, OBJECT_TYPE_GROUP} OBJECT_TYPE;
	HRESULT	GetObjectCollectionFromResult(OBJECT_TYPE type, MSXML::IXMLDOMNodePtr spResultNode, IObjectCollection** pVal);
	HRESULT GetContactFromNode(MSXML::IXMLDOMNodePtr spContactNode, IDispatch** pVal);
	HRESULT GetGroupFromNode(MSXML::IXMLDOMNodePtr spContactNode, IDispatch** pVal);
	HRESULT AddContactElements(MSXML::IXMLDOMDocumentPtr spDoc, MSXML::IXMLDOMNodePtr spContactNode, IContact* pContact);
	HRESULT	GetIDsFromResult(MSXML::IXMLDOMNodePtr spResultNode, IStringCollection2** pVal);

};

#endif //__CONTACTSERVICE_H_
