// SMSMessage.cpp : Implementation of CSMSMessage
#include "stdafx.h"
#include "EsendexSDK.h"
#include "SMSMessage.h"

/////////////////////////////////////////////////////////////////////////////
// CSMSMessage

STDMETHODIMP CSMSMessage::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISMSMessage2
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CSMSMessage::get_ID(BSTR *pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_ID");
	try
	{
		CHECK_INIT_PTR(pVal);
		CHECK_HR(m_bstrMessageID.CopyTo(pVal));
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::put_ID(BSTR newVal)
{
	ESENDEX_METHOD_PROLOGUE("put_ID");
	try
	{
		m_bstrMessageID = newVal;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::get_Originator(BSTR *pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_Originator");
	try
	{
		CHECK_INIT_PTR(pVal);
		CHECK_HR(m_bstrOriginator.CopyTo(pVal));
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::put_Originator(BSTR newVal)
{
	ESENDEX_METHOD_PROLOGUE("put_Originator");
	try
	{
		m_bstrOriginator = newVal;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::get_Recipient(BSTR *pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_Recipient");
	try
	{
		CHECK_INIT_PTR(pVal);
		CHECK_HR(m_bstrRecipient.CopyTo(pVal));
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::put_Recipient(BSTR newVal)
{
	ESENDEX_METHOD_PROLOGUE("put_Recipient");
	try
	{
		m_bstrRecipient = newVal;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::get_Body(BSTR *pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_Body");
	try
	{
		CHECK_INIT_PTR(pVal);
		CHECK_HR(m_bstrBody.CopyTo(pVal));
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::put_Body(BSTR newVal)
{
	ESENDEX_METHOD_PROLOGUE("put_Body");
	try
	{
		m_bstrBody = newVal;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::get_SentAt(DATE *pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_SentAt");
	try
	{
		CHECK_INIT_PTR(pVal);
		*pVal = m_sentAt;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::put_SentAt(DATE newVal)
{
	ESENDEX_METHOD_PROLOGUE("put_SentAt");
	try
	{
		m_sentAt = newVal;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::get_ReceivedAt(DATE *pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_ReceivedAt");
	try
	{
		CHECK_INIT_PTR(pVal);
		*pVal = m_receivedAt;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::put_ReceivedAt(DATE newVal)
{
	ESENDEX_METHOD_PROLOGUE("put_ReceivedAt");
	try
	{
		m_receivedAt = newVal;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::get_Type(MESSAGE_TYPE *pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_MessageID");
	try
	{
		CHECK_INIT_PTR((long*)pVal);
		*pVal = m_messageType;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::put_Type(MESSAGE_TYPE newVal)
{
	ESENDEX_METHOD_PROLOGUE("put_Type");
	try
	{
		m_messageType = newVal;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::get_Status(MESSAGE_STATUS *pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_MessageID");
	try
	{
		CHECK_INIT_PTR((long*)pVal);
		*pVal = m_messageStatus;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::put_Status(MESSAGE_STATUS newVal)
{
	ESENDEX_METHOD_PROLOGUE("put_Status");
	try
	{
		m_messageStatus = newVal;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::get_Username(BSTR *pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_MessageID");
	try
	{
		CHECK_INIT_PTR(pVal);
		CHECK_HR(m_bstrUsername.CopyTo(pVal));
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::put_Username(BSTR newVal)
{
	ESENDEX_METHOD_PROLOGUE("put_Username");
	try
	{
		m_bstrUsername = newVal;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::get_MessageIndex(long *pVal)
{
	ESENDEX_METHOD_PROLOGUE("get_MessageIndex");
	try
	{
		CHECK_INIT_PTR(pVal);
		*pVal = m_iMessageIndex;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

STDMETHODIMP CSMSMessage::put_MessageIndex(long newVal)
{
	ESENDEX_METHOD_PROLOGUE("put_MessageIndex");
	try
	{
		m_iMessageIndex = newVal;
		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}
