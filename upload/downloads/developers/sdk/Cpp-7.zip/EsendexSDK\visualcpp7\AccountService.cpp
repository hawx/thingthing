// AccountService.cpp : Implementation of CAccountService
#include "stdafx.h"
#include "EsendexSDK.h"
#include "AccountService.h"
#include "XmlUtils.h"

/////////////////////////////////////////////////////////////////////////////
// CAccountService

STDMETHODIMP CAccountService::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IAccountService
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CAccountService::Initialise(BSTR UserName, BSTR Password, BSTR Account, VARIANT IsServerSide)
{
	return CSOAPService::Initialise(UserName, Password, Account, IsServerSide);
}

STDMETHODIMP CAccountService::GetMessageLimit(long* pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetMessageLimit"); 
	try
	{
		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR((long*)pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_MESSAGE_LIMIT)));

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result and return to the caller.
		*pVal = CXmlUtils::GetElementValueLong(spDoc, L"GetMessageLimitResult");
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CAccountService::GetAccountFeatures(long *pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetAccountFeatures"); 
	try
	{
		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR((long*)pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_ACCOUNT_FEATURES)));

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result and return to the caller.
		_bstr_t bstrAccountFeatures = CXmlUtils::GetElementValue(spDoc, L"GetAccountFeaturesResult");

		*pVal = ParseAccountFeatures(bstrAccountFeatures);
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

STDMETHODIMP CAccountService::Dummy(ACCOUNT_FEATURES x)
{
	return E_NOTIMPL;
}

STDMETHODIMP CAccountService::GetAccountState(IAccountState **pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetAccountState"); 
	try
	{
		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR((long*)pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_ACCOUNT_STATE)));

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName));

		//Get the result node.
		MSXML::IXMLDOMNodePtr spNode = CXmlUtils::GetElementByName(spDoc, L"GetAccountStateResult");

		CHECK_HR(GetAccountStateFromNode(spNode, pVal));

	
	
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}

HRESULT CAccountService::GetAccountStateFromNode(MSXML::IXMLDOMNodePtr spXmlElement, IAccountState** pVal)
{
	//Create a message object.
	CComPtr<IAccountState> spAccountState;
	CHECK_HR(spAccountState.CoCreateInstance(__uuidof(AccountState)));

	spXmlElement = spXmlElement->firstChild;
	while (spXmlElement!=NULL)
	{
		if (wcscmp(spXmlElement->baseName, L"ID")==0)
			spAccountState->put_ID(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"Reference")==0)
			spAccountState->put_Reference(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"Address")==0)
			spAccountState->put_Address(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"ServiceAlias")==0)
			spAccountState->put_ServiceAlias(spXmlElement->text);
		else if (wcscmp(spXmlElement->baseName, L"MessageLimit")==0)
			spAccountState->put_MessageLimit(_wtol(spXmlElement->text));
		else if (wcscmp(spXmlElement->baseName, L"Features")==0)
			spAccountState->put_Features(ParseAccountFeatures(spXmlElement->text));
		else
			ATLASSERT(!"Unknown message field");
		spXmlElement = spXmlElement->nextSibling;
	}
	*pVal = spAccountState.Detach();
	return S_OK;
}

long CAccountService::ParseAccountFeatures(BSTR pwszFeatures)
{
	//Split the features out.
	long nRetVal = 0;
	WCHAR* pwszToken = wcstok( pwszFeatures, L" " );
	while( pwszToken != NULL )
	{
		/* While there are tokens in "string" */
		if (wcscmp(pwszToken, L"Inbox")==0)
			nRetVal |= ACCOUNT_FEATURE_INBOX;
		else if (wcscmp(pwszToken, L"ServiceAliasing")==0)
			nRetVal |= ACCOUNT_FEATURE_SERVICE_ALIASING;
	  pwszToken = wcstok( NULL, L" " );
	}
	return nRetVal;
}



