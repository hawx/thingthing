// SendMessage.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <objbase.h>
#include <iostream>

#import "..\bin\EsendexSdk2.DLL"

#define ESENDEX_USERNAME L"test@test.com"
#define ESENDEX_PASSWORD L"test"
#define ESENDEX_ACCOUNT L"123"
#define ESENDEX_RECIPIENT L"123"

//Forward declarations for error reporting functions.
static int ReportError(const char* pszMessage, HRESULT hr);
static int ReportError(const char* pszMessage);
static void SendWorker();

int main(int argc, char* argv[])
{
	//Intialize COM
	HRESULT hr = CoInitialize(NULL);
	if (SUCCEEDED(hr))
	{
		//Send the message.
		SendWorker();
		//Unitialize COM.
		CoUninitialize();
	}
	else
	{
		ReportError("Failed to initialize COM subsystem", hr);
	}
	return 0;
}

//Worker function that initialises the SendService component
//and uses it to send a message.
void SendWorker()
{
	HRESULT hr;
	
	//Instantiate the Esendex Service.
	EsendexLib::ISendService2Ptr spSendService;
	hr = spSendService.CreateInstance(__uuidof(EsendexLib::SendService2));
	if (FAILED(hr))
		ReportError("Failed to create SendService object", hr);

	try
	{
		//Pass credentials to the service.
		spSendService->Initialise(ESENDEX_USERNAME, ESENDEX_PASSWORD, ESENDEX_ACCOUNT);

		//Send a message.
		_bstr_t bstrMessageId = spSendService->SendMessage(ESENDEX_RECIPIENT, "Test", EsendexLib::MESSAGE_TYPE_TEXT);

		std::cout << "Message sent. ID is " << (const char*)bstrMessageId << std::endl;
	}
	catch(_com_error& ex)
	{
		ReportError(ex.Description());
	}
}

static int ReportError(const char* pszMessage, HRESULT hr)
{
	std::cout << "Error: " << pszMessage << " Code: " << hr << std::endl;
	return 0;
}

static int ReportError(const char* pszMessage)
{
	std::cout << "Error: " << pszMessage << std::endl;
	return 0;
}

