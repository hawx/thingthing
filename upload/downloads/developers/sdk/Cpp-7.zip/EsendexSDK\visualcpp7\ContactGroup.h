// ContactGroup.h : Declaration of the CContactGroup

#ifndef __CONTACTGROUP_H_
#define __CONTACTGROUP_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CContactGroup
class ATL_NO_VTABLE CContactGroup : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CContactGroup, &CLSID_ContactGroup>,
	public ISupportErrorInfo,
	public IDispatchImpl<IContactGroup, &IID_IContactGroup, &LIBID_EsendexLib, 2>,
	public IDomainObject,
	public ILocalObject
{
public:
	CContactGroup()
	{
		m_groupType = CONTACT_GROUP_TYPE_GROUP;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CONTACTGROUP)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CContactGroup)
	COM_INTERFACE_ENTRY(IContactGroup)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IDomainObject)
	COM_INTERFACE_ENTRY(ILocalObject)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ILocalObject
public:
	STDMETHOD(GetLocalObject)(/*[out, retval]*/ LPUNKNOWN *pVal);

// IDomainObject
public:
	STDMETHOD(get_ID)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_ID)(/*[in]*/ BSTR newVal);

	// IContactGroup
public:
	STDMETHOD(get_GroupType)(/*[out, retval]*/ CONTACT_GROUP_TYPE *pVal);
	STDMETHOD(put_GroupType)(/*[in]*/ CONTACT_GROUP_TYPE newVal);
	STDMETHOD(get_Description)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Description)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Name)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Name)(/*[in]*/ BSTR newVal);

	CComBSTR m_bstrID;
	CComBSTR m_bstrName;
	CComBSTR m_bstrDescription;
	CONTACT_GROUP_TYPE m_groupType;
};

#endif //__CONTACTGROUP_H_
