// MessengerService.cpp : Implementation of CMessengerService
#include "stdafx.h"
#include "EsendexSDK.h"
#include "MessengerService.h"
#include "XmlUtils.h"

/////////////////////////////////////////////////////////////////////////////
// CMessengerService

STDMETHODIMP CMessengerService::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IMessengerService
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CMessengerService::GetCurrentVersion(BSTR *pVal)
{
	//Set up some variables to hold class name and method name. If we throw an exception, 
	//they'll get picked up
	ESENDEX_METHOD_PROLOGUE("GetCurrentVersion"); 
	try
	{
		//Check the pointer passed in by the caller's pointer. Throw if it's null.
		//Initialize it if it's not null.
		CHECK_INIT_PTR((long*)pVal);

		//Load the XML document from the resource file.
		MSXML::IXMLDOMDocumentPtr spDoc;
		CHECK_HR(CXmlUtils::LoadXMLDocFromResource(spDoc, MAKEINTRESOURCE(IDR_GET_CURRENT_VERSION)));

		//Post the XML to the server.
		CHECK_HR(Execute(spDoc, pszMethodName, false));

		//Get the result.
		_bstr_t bstrResult = CXmlUtils::GetElementValue(spDoc, L"GetCurrentVersionResult");

		//Return the result to the caller.
		*pVal = bstrResult.copy();
	}
	ESENDEX_CATCH_ALL();
	return S_OK;
}
