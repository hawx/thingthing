#if !defined(AFX_SENDFULLDIALOG_H__541A5A41_EF32_4E0B_A705_D4F3B340D878__INCLUDED_)
#define AFX_SENDFULLDIALOG_H__541A5A41_EF32_4E0B_A705_D4F3B340D878__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SendFullDialog.h : header file
// Esendex: Dialog box that enables a user to send an SMS message with
// additional information.

/////////////////////////////////////////////////////////////////////////////
// CSendFullDialog dialog

class CSendFullDialog : public CDialog
{
// Construction
public:
	CSendFullDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSendFullDialog)
	enum { IDD = IDD_SEND_FULL };
	CString	m_strMessage;
	CString	m_strRecipient;
	CString	m_strOriginator;
	long	m_iValidityPeriod;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSendFullDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSendFullDialog)
	virtual void OnOK();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SENDFULLDIALOG_H__541A5A41_EF32_4E0B_A705_D4F3B340D878__INCLUDED_)
