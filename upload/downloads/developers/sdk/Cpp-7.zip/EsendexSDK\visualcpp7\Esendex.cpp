// Esendex.cpp : Implementation of DLL Exports.


// Note: Proxy/Stub Information
//      To build a separate proxy/stub DLL, 
//      run nmake -f Esendexps.mk in the project directory.

#include "stdafx.h"
#include "resource.h"
#include <initguid.h>
#include "Esendex.h"

#include "Esendex_i.c"
#include "SMSMessage.h"
#include "SMSMessageCollection.h"
#include "StringCollection.h"
#include "SendService.h"
#include "InboxService.h"
#include "AccountService.h"
#include "Contact.h"
#include "ContactService.h"
#include "SignupService.h"
#include "ObjectCollection.h"
#include "ContactGroup.h"
#include "TestService.h"
#include "SignupCompletionElements.h"
#include "AccountState.h"
#include "MessengerService.h"


CComModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
OBJECT_ENTRY(CLSID_SendService, CSendService)
OBJECT_ENTRY(CLSID_StringCollection, CStringCollection)
OBJECT_ENTRY(CLSID_InboxService, CInboxService)
OBJECT_ENTRY(CLSID_Contact, CContact)
OBJECT_ENTRY(CLSID_AccountService, CAccountService)
OBJECT_ENTRY(CLSID_SMSMessage, CSMSMessage)
OBJECT_ENTRY(CLSID_SMSMessageCollection, CSMSMessageCollection)
OBJECT_ENTRY(CLSID_ContactService, CContactService)
OBJECT_ENTRY(CLSID_SignupService, CSignupService)
OBJECT_ENTRY(CLSID_ObjectCollection, CObjectCollection)
OBJECT_ENTRY(CLSID_ContactGroup, CContactGroup)
OBJECT_ENTRY(CLSID_TestService, CTestService)
OBJECT_ENTRY(CLSID_SignupCompletionElements, CSignupCompletionElements)
OBJECT_ENTRY(CLSID_AccountState, CAccountState)
OBJECT_ENTRY(CLSID_MessengerService, CMessengerService)
END_OBJECT_MAP()

/////////////////////////////////////////////////////////////////////////////
// DLL Entry Point

static HRESULT CheckVersion(log4cpp::Category& log, LPCWSTR pwszProgID)
{
	HRESULT hr;
	/*
	CComPtr<IUnknown> spUnk;
	hr = spUnk.CoCreateInstance(pwszProgID);
	if (SUCCEEDED(hr))
		
		log.debug("Created MSXML ProgID", pwszProgID);
	else
		log.debug("MSXML ProgID %", pwszProgID);
	*/

	CLSID classID;
	hr = CLSIDFromProgID(pwszProgID, &classID);
	if (SUCCEEDED(hr))		
	{
		/*
		LPOLESTR pwszClassID = NULL;
		LPCTSTR pszInProcServer32 = new TCHAR[255];
		bool bFree = true;
		hr = StringFromCLSID(classID, &pwszClassID);
		if (FAILED(hr))
		{
			bFree = false;
			pwszClassID = L"<unknown>";
		}
		USES_CONVERSION;
		HKEY key;
		bool bGot
		if (ERROR_SUCCESS==RegOpenKey(HKEY_CLASSES_ROOT, W2A(pwszClasID), &hKey))
		{
			if (ERROR_SUCCESS==RegQueryValue(hKey, "InProcServer32", &pszInProcServer32, 255))

		

		{
			log.debug("MSXML ProgID %S maps to %S", pwszProgID, pwszClassID);
			CoTaskMemFree(pwszClassID);
		}
		*/
	}
	else
		log.debug("MSXML ProgID %S is not registered", pwszProgID);
	return hr;	
}

static HRESULT CheckMSXML()
{
	char* m_pszClassName = "global";
	ESENDEX_METHOD_PROLOGUE("DllMain"); 
	try
	{
		CheckVersion(log, L"MICROSOFT.XMLDOM");
		CheckVersion(log, L"MICROSOFT.XMLDOM.1.0");
		CheckVersion(log, L"MSXML.DOMDOCUMENT");
		CheckVersion(log, L"MSXML2.DOMDOCUMENT");
		CheckVersion(log, L"MSXML2.DOMDOCUMENT.2.6");
		CheckVersion(log, L"MSXML2.DOMDOCUMENT.3.0");
		CheckVersion(log, L"MSXML2.DOMDOCUMENT.4.0");



		return S_OK;
	}
	ESENDEX_CATCH_ALL();
}

extern "C"
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID /*lpReserved*/)
{
    if (dwReason == DLL_PROCESS_ATTACH)
    {
        _Module.Init(ObjectMap, hInstance, &LIBID_EsendexLib);
        DisableThreadLibraryCalls(hInstance);

		try 
		{
			log4cpp::PropertyConfigurator::configure("c:\\EsendexLogging.properties");
		}
		catch(log4cpp::ConfigureFailure& f) 
		{
			
			//std::cout << "Configure Problem " << f.what() << std::endl;
			//return -1;
			OutputDebugString("Failed to configure log4cpp ");
			OutputDebugString(f.what());
			OutputDebugString("\n");
		}

		//CheckMSXML();
    }
    else if (dwReason == DLL_PROCESS_DETACH)
	{
		log4cpp::Category::shutdown();
        _Module.Term();
	}
    return TRUE;    // ok
}


/////////////////////////////////////////////////////////////////////////////
// Used to determine whether the DLL can be unloaded by OLE

STDAPI DllCanUnloadNow(void)
{
    return (_Module.GetLockCount()==0) ? S_OK : S_FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// Returns a class factory to create an object of the requested type

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
    return _Module.GetClassObject(rclsid, riid, ppv);
}

/////////////////////////////////////////////////////////////////////////////
// DllRegisterServer - Adds entries to the system registry

STDAPI DllRegisterServer(void)
{
    // registers object, typelib and all interfaces in typelib
    return _Module.RegisterServer(TRUE);
}

/////////////////////////////////////////////////////////////////////////////
// DllUnregisterServer - Removes entries from the system registry

STDAPI DllUnregisterServer(void)
{
    return _Module.UnregisterServer(TRUE);
}


