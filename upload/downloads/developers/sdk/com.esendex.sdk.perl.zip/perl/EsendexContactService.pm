﻿# EsendexContactService Class
# Copyright Esendex 2005/2006
# Questions : please contact support@esendex.com http://www.esendex.com/support
package EsendexContactService;
use FormPostClass;

# Global scalar to reference locations of Contact Services
$addContactUri = 'https://www.esendex.com/secure/messenger/formpost/AddContact.aspx';
$addContactGroupUri = 'https://www.esendex.com/secure/messenger/formpost/AddContactGroup.aspx';
$deleteContactUri = 'https://www.esendex.com/secure/messenger/formpost/DeleteContact.aspx';
$deleteContactGroupUri = 'https://www.esendex.com/secure/messenger/formpost/DeleteContactGroup.aspx';
$getContactUri =  'https://www.esendex.com/secure/messenger/formpost/GetContact.aspx';
$getContactGroupUri = 'https://www.esendex.com/secure/messenger/formpost/GetContactGroup.aspx';
$getContactGroupMembersUri = 'https://www.esendex.com/secure/messenger/formpost/GetContactGroupMembers.aspx';
$updateContactUri = 'https://www.esendex.com/secure/messenger/formpost/UpdateContact.aspx';
$updateContactGroupUri = 'https://www.esendex.com/secure/messenger/formpost/UpdateContactGroup.aspx';

# Class constructor
sub new
{
	my ($class, $username, $password, $account) = @_;
	my $self = 
	{
		username 	=> $username,
		password 	=> $password,
		account		=> $account
	};
	bless ($self, $class);
	return $self;
}

# Add a contact method
sub addContact
{
	my $response = undef;
	
	if(@_ == 3)
	{
		my ($object, $quickName, $mobileNumber) = @_;
		my $post = new FormPostClass();
		$response = $post->formPostAddContact
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'},
			$addContactUri,
			$quickName,
			$mobileNumber
		);
	}
	elsif (@_ == 13)
	{
		my ($object, $contactID, $quickName, $firstName, $lastName,	$telephoneNumber, $mobileNumber,
				$streetAddress1, $streetAddress2, $town, $county, $postcode, $country) = @_;
		my $post = new FormPostClass();
		$response = $post->formPostAddContact
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'},
			$addContactUri,
			$contactID,
			$quickName,
			$firstName,
			$lastName,
			$telephoneNumber, 
			$mobileNumber,
			$streetAddress1,
			$streetAddress2,
			$town,
			$county,
			$postcode,
			$country
		);
	}	else 
	{
		$response = "Error : Incorrect number of arguments supplied to addContact method";
	}
	return $response;
}

# Delete contact method
sub deleteContact
{
	my $response;

	if(@_ == 2)
	{
		my ($object, $contactID) = @_;
		my $post = new FormPostClass();
		$response = $post->formPostDeleteContact
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'},
			$deleteContactUri,
			$contactID
		);
	}
	else
	{
		$response = 'Error : Incorrect number of arguments supplied to deleteContact method.'
	}
	return $response;
}

# Get contact method
sub getContact
{
	my @response;

	if(@_ == 2)
	{
		my ($object, $contactID) = @_;
		my $post = new FormPostClass();
		@response = $post->formPostGetContact
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'},
			$getContactUri,
			$contactID
		);
	}
	else
	{
		push(@response,
		{
			Error => 'Incorrect number of arguments supplied to getContact method'
		});
	}
	return @response;
}

# Get contact group method
sub getContactGroup
{
	my @response;

	if(@_ == 2)
	{
		my ($object, $groupID) = @_;
		my $post = new FormPostClass();
		@response = $post->formPostGetContactGroup
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'},
			$getContactGroupUri,
			$groupID
		);
	}
	else
	{
		@response =
		(
		{
			Error => 'Incorrect number of arguments supplied to getContactGroup method'
		}
		);
	}
	return @response;
}

# Get contact group members method
sub getContactGroupMembers
{
	my @response;

	if(@_ == 2)
	{
		my ($object, $groupID) = @_;
		my $post = new FormPostClass();
		@response = $post->formPostGetContactGroupMembers
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'},
			$getContactGroupMembersUri,
			$groupID
		);
	}
	else
	{
		@response =
		({
			Error => 'Incorrect number of arguments supplied to getContactGroupMembers method'
		});
	}
	return @response;
}

# Update contact method
sub updateContact
{
	my $response = undef;
	
	if(@_ == 4)
	{
		my ($object, $contactID, $quickName, $mobileNumber) = @_;
		my $post = new FormPostClass();
		$response = $post->formPostUpdateContact
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'},
			$updateContactUri,
			$contactID,
			$quickName,
			$mobileNumber
		);
	}
	elsif (@_ == 13)
	{
		my ($object, $contactID, $quickName, $firstName, $lastName,	$telephoneNumber, $mobileNumber,
				$streetAddress1, $streetAddress2, $town, $county, $postcode, $country) = @_;
		my $post = new FormPostClass();
		$response = $post->formPostUpdateContact
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'},
			$updateContactUri,
			$contactID,
			$quickName,
			$firstName,
			$lastName,
			$telephoneNumber, 
			$mobileNumber,
			$streetAddress1,
			$streetAddress2,
			$town,
			$county,
			$postcode,
			$country
		);
	}	else 
	{
		$response = "Error : Incorrect number of arguments supplied to updateContact method";
	}
	return $response;
}

# Update contact group method
sub updateContactGroup
{
	my $response;

	if(@_ == 5)
	{
		my ($object, $groupID, $name, $description, $memberIDs) = @_;
		my $post = new FormPostClass();
		$response = $post->formPostUpdateContactGroup
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'},
			$updateContactGroupUri,
			$groupID,
			$name,
			$description,
			$memberIDs
		);
	}
	elsif(@_ == 3)
	{
		my ($object, $groupID, $name) = @_;
		my $post = new FormPostClass();
		$response = $post->formPostUpdateContactGroup
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'},
			$updateContactGroupUri,
			$groupID,
			$name
		);
	}
	else
	{
		$response = 'Error : Incorrect number of arguments supplied to updateContactGroup method.'
	}
	return $response;
}

# Add contact group method
sub addContactGroup
{
	my $response;

	if(@_ == 5)
	{
		my ($object, $groupID, $name, $description, $memberIDs) = @_;
		my $post = new FormPostClass();
		$response = $post->formPostAddContactGroup
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'},
			$addContactGroupUri,
			$groupID,
			$name,
			$description,
			$memberIDs
		);
	}
	elsif(@_ == 2)
	{
		my ($object, $name) = @_;
		my $post = new FormPostClass();
		$response = $post->formPostAddContactGroup
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'},
			$addContactGroupUri,
			$name
		);
	}
	else
	{
		$response = 'Error : Incorrect number of arguments supplied to updateContactGroup method.'
	}
	return $response;
}

# Delete contact group method
sub deleteContactGroup
{
	my $response;

	if(@_ == 3)
	{
		my ($object, $groupID, $includeMembers) = @_;
		my $post = new FormPostClass();
		$response = $post->formPostDeleteContactGroup
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'},
			$deleteContactGroupUri,
			$groupID,
			$includeMembers
		);
	}
	else
	{
		$response = 'Error : Incorrect number of arguments supplied to deleteContactGroup method.'
	}
	return $response;
}

1;