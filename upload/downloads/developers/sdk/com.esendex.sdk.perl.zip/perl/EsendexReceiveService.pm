﻿# Esendex Receive Service Class
# Copyright Esendex 2005/2006
# Questions : please contact support@esendex.com http://www.esendex.com/support
package EsendexReceiveService;
use FormPostClass;

# Global scalar to reference location of Receive Service
$getInboxUri = 'https://www.esendex.com/secure/messenger/formpost/GetInboxMessage.aspx';
$deleteMessageUri = 'https://www.esendex.com/secure/messenger/formpost/DeleteInboxMessage.aspx';

# Class constructor
sub new
{
	my ($class, $username, $password, $account) = @_;
	my $self = 
	{
		username 	=> $username,
		password 	=> $password,
		account		=> $account
	};
	bless ($self, $class);
	return $self;
}

# Get inbox method
sub getInbox
{
	my @message = undef;

	if(@_ == 1)
	{
		my ($object) = @_;
		my $response = new FormPostClass();
		@message = $response -> formPostGetInbox
		(
			$object->{'username'},
			$object->{'password'},
			$object->{'account'},
			$getInboxUri
		);
	} else {
		$#message = -1; 
	};
	return @message;
}

# Delete message method
sub deleteMessage
{
	my $response = undef;
	
	if(@_ == 2)
	{
		my ($object, $messageID) = @_;
		my $message = new FormPostClass();
		$response = $message -> formPostDeleteMessage
		(
			$object->{'username'},
			$object->{'password'},
			$object->{'account'},
			$deleteMessageUri,
			$messageID
		);
	} else {
		$response = "Error : Incorrect number of arguments supplied to deleteMessage"; 
	};
	return $response;
}
1;