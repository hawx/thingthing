# FormPostClass handles all HTTP Form Posts
# Copyright Esendex 2006
# Questions : please contact support@esendex.com http://www.esendex.com/support
package FormPostClass;
use LWP::UserAgent;
use Encode;
use strict;

# Class Constructor
sub new
{
	my ($class) = @_;
	my $self =
	{
		name => 'esendex'
	};
	bless($self, $class);
	return $self;
};

# Post Simple Message to Form Post interface
# Overloaded to handle varying numbers of arguments

sub formPostMessage
{
	shift;
	my $response = undef;
	
	if(@_ == 6)
	{
		my ($username, $password, $account, $uri, $recipient,	$body ) = @_;
	    my $userAgent = &createUserAgent;
		# Make the request to the server
        
		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				Recipient => $recipient,
				Body => $body,
				PlainText => '1'
			]
		);
	} elsif (@_ == 9)
	{
		my ($username, $password, $account, $uri, $recipient, 
				$originator, $body, $type, $validityPeriod ) = @_;
		
		# Make the request to the server
		
	    my $userAgent = &createUserAgent;
        
		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				Recipient => $recipient,
				Originator => $originator,
				Body => $body,
				Type => $type,
				ValidityPeriod => $validityPeriod,
				PlainText => '1'
			]
		);
	}
	  
	# Response	
	$response =  $response -> as_string;
	return parseDefaultReturnResponse($response);
}


# Post Wap Messge method
# Overloaded to take varying number of arguments
sub formPostWapMessage
{
	shift;
	my $response = undef;
	
	if(@_ == 7)
	{
		my ($username, $password, $account, $uri, $recipient, 
			 	$href, $body ) = @_;
		
		# Make the request to the server
		
	    my $userAgent = &createUserAgent;
		
		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				Recipient => $recipient,
				Href => $href,
				Text => $body,
				PlainText => '1'
			]
		);
		
		# Response	
		$response =  $response -> as_string;
		$response = parseDefaultReturnResponse($response);
		
	} elsif(@_ == 8)
	{
		my ($username, $password, $account, $uri, $recipient, 
			 	$href, $body, $validityPeriod ) = @_;

		# Make the request to the server
		
	    my $userAgent = &createUserAgent;
		
		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				Recipient => $recipient,
				Href => $href,
				Text => $body,
				ValidityPeriod => $validityPeriod,
				PlainText => '1'
			]
		);
		# Response	
		$response =  $response -> as_string;
		$response = parseDefaultReturnResponse($response);
	} 
	return $response;
}

# Post Scheduled Message At to Form Post interface
# Overloaded to handle varying numbers of arguments
sub formPostScheduledMessageAt
{
	shift;
	my $response = undef;
	
	if(@_ == 7)
	{
		my ($username, $password, $account, $uri, $recipient,	$body, $submitAt ) = @_;
	
		# Make the request to the server
		
	    my $userAgent = &createUserAgent;
		
		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				Recipient => $recipient,
				Body => $body,
				PlainText => '1',
				SubmitAt => $submitAt
			]
		);
	} elsif (@_ == 10)
	{
		my ($username, $password, $account, $uri, $recipient, 
				$originator, $body, $type, $validityPeriod, $submitAt ) = @_;
		
		# Make the request to the server
		
	    my $userAgent = &createUserAgent;
		
		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				Recipient => $recipient,
				Originator => $originator,
				Body => $body,
				Type => $type,
				ValidityPeriod => $validityPeriod,
				PlainText => '1',
				SubmitAt => $submitAt
			]
		);
	}
	  
	# Response	
	$response =  $response -> as_string;
	return parseDefaultReturnResponse($response);
}

# Post Scheduled Message In to Form Post interface
# Overloaded to handle varying numbers of arguments
sub formPostScheduledMessageIn
{
	shift;
	my $response = undef;
	
	if(@_ == 9)
	{
		my ($username, $password, $account, $uri, $recipient,	$body, $days, $hours, $minutes ) = @_;
	
		# Make the request to the server
		
	    my $userAgent = &createUserAgent;
		
		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				Recipient => $recipient,
				Body => $body,
				PlainText => '1',
				Days => $days,
				Hours => $hours,
				Minutes => $minutes
			]
		);
	} elsif (@_ == 12)
	{
		my ($username, $password, $account, $uri, $recipient, 
				$originator, $body, $type, $validityPeriod, $days, $hours, $minutes ) = @_;
		
		# Make the request to the server
		
	    my $userAgent = &createUserAgent;
		
		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				Recipient => $recipient,
				Originator => $originator,
				Body => $body,
				Type => $type,
				ValidityPeriod => $validityPeriod,
				PlainText => '1',
				Days => $days,
				Hours => $hours,
				Minutes => $minutes
			]
		);
	}
	  
	# Response	
	$response =  $response -> as_string;
	return parseDefaultReturnResponse($response);
}

# Post Get Message status
sub formPostGetMessageStatus
{
	shift;
	my ($username, $password, $account, $uri, $id) = @_;
	
	# Make the request to the server
	
    my $userAgent = &createUserAgent;
	
	my $response = $userAgent -> post($uri, 
		[
			Username => $username,
			Password => $password,
			Account => $account,
			MessageID => $id,
			PlainText => '1'
		]
	);
	# Response	
	$response = $response->as_string;
	return parseDefaultReturnResponse($response);
}

# Post Get Inbox method
sub formPostGetInbox
{
	shift;
	my ($username, $password, $account, $uri) = @_;
	
	my $userAgent = &createUserAgent;
	
	my $response = $userAgent -> post($uri, 
		[
			Username => $username,
			Password => $password,
			Account => $account,
			PlainText => '1'
		]
	);
	# Response	
	$response = $response->as_string;
	my @messages = parseGetInboxResponse($response);
	return @messages;
}

# Post Delete message method
sub formPostDeleteMessage
{
	shift;
	my ($username, $password, $account, $uri, $messageID) = @_;
	
	my $userAgent = &createUserAgent;
	
	my $response = $userAgent -> post($uri, 
		[
			Username => $username,
			Password => $password,
			Account => $account,
			MessageID => $messageID,
			PlainText => '1'
		]
	);
	# Response	
	$response = $response->as_string;
	return parseDefaultResponse($response);
}

# Post Add Contact method
sub formPostAddContact
{
	shift;
	my $response;
	
	if(@_ == 16)
	{
		my ($username, $password, $account, $uri, $contactID, $quickName, $firstName, 
				$lastName,	$telephoneNumber, $mobileNumber, $streetAddress1, $streetAddress2,
				$town, $county, $postcode, $country) = @_;
	
	    my $userAgent = &createUserAgent;
        
		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				ContactID => $contactID,
				QuickName => $quickName,
				FirstName => $firstName,
				LastName => $lastName,
				TelephoneNumber => $telephoneNumber,
				MobileNumber => $mobileNumber,
				StreetAddress1 => $streetAddress1,
				StreetAddress2 => $streetAddress2,
				Town => $town,
				County => $county,
				PostCode => $postcode,
				Country => $country,
				PlainText => '1'
			]
		);
	}
	elsif(@_ == 6)
	{
		my ($username, $password, $account, $uri, $quickName, $mobileNumber) = @_;
	
	    my $userAgent = &createUserAgent;

		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				QuickName => $quickName,
				MobileNumber => $mobileNumber,
				PlainText => '1'
			]
		);
	}
	# Response	
	$response = $response->as_string;
	return parseDefaultReturnResponse($response);
}

# Post delete contact message
sub formPostDeleteContact
{
	shift;
	my ($username, $password, $account, $uri, $contactID) = @_;
	my $response;
	
    my $userAgent = &createUserAgent;

	$response = $userAgent -> post($uri, 
		[
			Username => $username,
			Password => $password,
			Account => $account,
			ContactID => $contactID,
			PlainText => '1'
		]
	);
	# Response	
	$response = $response->as_string;
	return parseDefaultResponse($response);
}

# Post get contact
sub formPostGetContact
{
	shift;
	my ($username, $password, $account, $uri, $contactID) = @_;
	my $response;
	my $userAgent = new LWP::UserAgent;
	
    my $userAgent = &createUserAgent;

	
	$response = $userAgent -> post($uri, 
		[
			Username => $username,
			Password => $password,
			Account => $account,
			ContactID => $contactID,
			PlainText => '1'
		]
	);
	# Response	
	$response = $response->as_string;
	return parseGetContactResponse($response);
}

# Post get contact group
sub formPostGetContactGroup
{
	shift;
	my ($username, $password, $account, $uri, $groupID) = @_;
	my $response;
	my $userAgent = new LWP::UserAgent;
	
    my $userAgent = &createUserAgent;
	
	$response = $userAgent -> post($uri, 
		[
			Username => $username,
			Password => $password,
			Account => $account,
			GroupID => $groupID,
			PlainText => '1'
		]
	);
	# Response	
	$response = $response->as_string;
	return parseGetContactGroupResponse($response);
}

# Post get contact group members
sub formPostGetContactGroupMembers
{
	shift;
	my ($username, $password, $account, $uri, $groupID) = @_;
	my $response;
	my $userAgent = new LWP::UserAgent;
	
    my $userAgent = &createUserAgent;

	$response = $userAgent -> post($uri, 
		[
			Username => $username,
			Password => $password,
			Account => $account,
			GroupID => $groupID,
			PlainText => '1'
		]
	);
	# Response	
	$response = $response->as_string;
	return parseGetContactGroupMembersResponse($response);
}

# Post Update Contact method
sub formPostUpdateContact
{
	shift;
	my $response;
	
	if(@_ == 16)
	{
		my ($username, $password, $account, $uri, $contactID, $quickName, $firstName, 
				$lastName,	$telephoneNumber, $mobileNumber, $streetAddress1, $streetAddress2,
				$town, $county, $postcode, $country) = @_;
	
	    my $userAgent = &createUserAgent;

		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				ContactID => $contactID,
				QuickName => $quickName,
				FirstName => $firstName,
				LastName => $lastName,
				TelephoneNumber => $telephoneNumber,
				MobileNumber => $mobileNumber,
				StreetAddress1 => $streetAddress1,
				StreetAddress2 => $streetAddress2,
				Town => $town,
				County => $county,
				PostCode => $postcode,
				Country => $country,
				PlainText => '1'
			]
		);
	}
	elsif(@_ == 7)
	{
		my ($username, $password, $account, $uri, $contactID, $quickName, $mobileNumber) = @_;
	
	    my $userAgent = &createUserAgent;

		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				ContactID => $contactID,
				QuickName => $quickName,
				MobileNumber => $mobileNumber,
				PlainText => '1'
			]
		);
	}
	# Response	
	$response = $response->as_string;
	return parseDefaultResponse($response);
}

# Overloaded to take varying number of arguments
sub formPostUpdateContactGroup
{
	shift;
	my $response = undef;
	
	if(@_ == 6)
	{
		my ($username, $password, $account, $uri, $groupID, $name) = @_;
		
		# Make the request to the server
		
	    my $userAgent = &createUserAgent;

		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				GroupID => $groupID,
				Name => $name,
				PlainText => '1'
			]
		);
		
		# Response	
		$response =  $response -> as_string;
		$response = parseDefaultResponse($response);
		
	} elsif(@_ == 8)
	{
		my ($username, $password, $account, $uri, $groupID, $name, $description, $memberIDs) = @_;
		
		# Make the request to the server
		
	    my $userAgent = &createUserAgent;
		
		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				GroupID => $groupID,
				Name => $name,
				Description => $description,
				MemberIDs => $memberIDs,
				PlainText => '1'
			]
		);
		# Response	
		$response =  $response -> as_string;
		$response = parseDefaultResponse($response);
	} 
	return $response;
}

# Post Add contact method
sub formPostAddContactGroup
{
	shift;
	my $response = undef;
	
	if(@_ == 5)
	{
		my ($username, $password, $account, $uri, $name) = @_;
		
		# Make the request to the server
		
	    my $userAgent = &createUserAgent;

		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				Name => $name,
				PlainText => '1'
			]
		);
		# Response	
		$response =  $response -> as_string;	
	} 
	elsif(@_ == 8)
	{
		my ($username, $password, $account, $uri, $groupID, $name, $description, $memberIDs) = @_;
		
		# Make the request to the server
		
	    my $userAgent = &createUserAgent;
		
		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				GroupID => $groupID,
				Name => $name,
				Description => $description,
				MemberIDs => $memberIDs,
				PlainText => '1'
			]
		);
		# Response	
		$response =  $response -> as_string;
	} 
	else
	{
		$response = "Error : formPostAddContactGroup method argument error.";
	}
	return parseDefaultReturnResponse($response);;
}

# Overloaded to take varying number of arguments
sub formPostDeleteContactGroup
{
	shift;
	my $response = undef;
	
	if(@_ == 6)
	{
		my ($username, $password, $account, $uri, $groupID, $includeMembers) = @_;
		
		# Make the request to the server
		
	    my $userAgent = &createUserAgent;
		
		$response = $userAgent -> post($uri, 
			[
				Username => $username,
				Password => $password,
				Account => $account,
				GroupID => $groupID,
				IncludeMembers => $includeMembers,
				PlainText => '1'
			]
		);
		$response =  $response -> as_string;
	} 
	else
	{
		$response = "Error : formPostDeleteContactGroup method argument error.";
	}
	# Response	
	return parseDefaultResponse($response);;
}

sub createUserAgent
{
	my $userAgent = new LWP::UserAgent;
	$userAgent -> timeout([10]);
	$userAgent -> agent('esendex-perl-sdk/1.0.0 ' . $userAgent->agent);
    return $userAgent;
}

# Parse the get inbox response to get messages
sub parseGetInboxResponse
{
	my $string = shift;
	my @messages;
	my $flag = 0;
	
	if($string =~ m/Result=OK/)
	{
		my @response = split(/\n/, $string);

		for(my $i = 0; $i <= $#response; $i++)
		{
			$response[$i] =~ s/\+/ /g;
			$response[$i] =~ s/%3a/:/g;
			$response[$i] =~ s/%3f/?/g;
			$response[$i] =~ s/%2c/,/g;
			$response[$i] =~ s/%22/\"/g;
			$response[$i] =~ s/%40/@/g;
			$response[$i] =~ s/%2f/\//g;
			$response[$i] =~ s/%3b/;/g;
			$response[$i] =~ s/%2b/\+/g;
			$response[$i] =~ s/%26/&/g;
			$response[$i] =~ s/%25/%/g;
			$response[$i] =~ s/%3d/=/g;
			$response[$i] =~ s/%3c/</g;
			$response[$i] =~ s/%3e/>/g;
			$response[$i] =~ s/%24/\$/g;
			$response[$i] =~ s/%c2%a3/£/g;
			$response[$i] =~ s/%5e/^/g;
			
			# Push every message as a hash onto the array and return it
			if($response[$i] =~ /^ID=(.*)&Originator=(.*)&Recipient=(.*)&Body=(.*)&ReceivedAt=(.*)&Type=(.*)&IndexID=(.*)$/)
			{
				$flag = 1;
				push (@messages,
				{
					messageID => $1,
					originator => $2,
					recipient => $3,
					body => $4,
					receivedAt => $5,
					type => $6,
					indexID => $7
				});
			}
		}
	} 
	elsif($string =~ m/Result=Error/)
	{
		$flag = 1;
		$string =~ s/\+/ /g;
		$string =~ m/Message=(.*)$/;
		push (@messages,
				{
					Error => $1,
				});
	}
	
	if($flag == 1)
	{
		return @messages;
	}
	else
	{
		$#messages = -1;
		return @messages;
	}
}


# Parse the get contact response to get messages
sub parseGetContactResponse
{
	my $string = shift;
	my @messages;
	my $flag = 0;
	
	if($string =~ m/Result=OK/)
	{
		my @response = split(/\n/, $string);

		for(my $i = 0; $i <= $#response; $i++)
		{
			$response[$i] =~ s/\+/ /g;
			$response[$i] =~ s/%3a/:/g;
			$response[$i] =~ s/%3f/?/g;
			$response[$i] =~ s/%2c/,/g;
			$response[$i] =~ s/%22/\"/g;
			$response[$i] =~ s/%40/@/g;
			$response[$i] =~ s/%2f/\//g;
			$response[$i] =~ s/%3b/;/g;
			$response[$i] =~ s/%2b/\+/g;
			$response[$i] =~ s/%26/&/g;
			$response[$i] =~ s/%25/%/g;
			$response[$i] =~ s/%3d/=/g;
			$response[$i] =~ s/%3c/</g;
			$response[$i] =~ s/%3e/>/g;
			$response[$i] =~ s/%24/\$/g;
			$response[$i] =~ s/%c2%a3/£/g;
			$response[$i] =~ s/%5e/^/g;
			
			# Push every message as a hash onto the array and return it
			if($response[$i] =~ /^ID=(.*)&QuickName=(.*)&FirstName=(.*)&LastName=(.*)&TelephoneNumber=(.*)&MobileNumber=(.*)&StreetAddress1=(.*)&StreetAddress2=(.*)&Town=(.*)&County=(.*)&Postcode=(.*)&Country=(.*)&EmailAddress=(.*)&ContactType=(.*)$/)
			{
				$flag = 1;
				push (@messages,
				{
					ID => $1,
					QuickName => $2,
					FirstName => $3,
					LastName => $4,
					TelephoneNumber => $5,
					MobileNumber => $6,
					StreetAddress1 => $7,
					StreetAddress2 => $8,
					Town => $9,
					County => $10,
					Postcode => $11,
					Country => $12,
					EmailAddress => $13,
					ContactType => $14
					
				});
			}
		}
	} 
	elsif($string =~ m/Result=Error/)
	{
		$flag = 1;
		$string =~ s/\+/ /g;
		$string =~ m/Message=(.*)$/;
		push (@messages,
				{
					Error => $1
				});
	}
	
	if($flag == 1)
	{
		return @messages;
	}
	else
	{
		$#messages = -1;
		return @messages;
	}
}

# Parse the get contact group response
sub parseGetContactGroupResponse
{
	my $string = shift;
	my @messages;
	my $flag = 0;
	
	if($string =~ m/Result=OK/)
	{
		my @response = split(/\n/, $string);

		for(my $i = 0; $i <= $#response; $i++)
		{
			$response[$i] =~ s/\+/ /g;
			$response[$i] =~ s/%3a/:/g;
			$response[$i] =~ s/%3f/?/g;
			$response[$i] =~ s/%2c/,/g;
			$response[$i] =~ s/%22/\"/g;
			$response[$i] =~ s/%40/@/g;
			$response[$i] =~ s/%2f/\//g;
			$response[$i] =~ s/%3b/;/g;
			$response[$i] =~ s/%2b/\+/g;
			$response[$i] =~ s/%26/&/g;
			$response[$i] =~ s/%25/%/g;
			$response[$i] =~ s/%3d/=/g;
			$response[$i] =~ s/%3c/</g;
			$response[$i] =~ s/%3e/>/g;
			$response[$i] =~ s/%24/\$/g;
			$response[$i] =~ s/%c2%a3/£/g;
			$response[$i] =~ s/%5e/^/g;
			
			# Push every message as a hash onto the array and return it
			if($response[$i] =~ /^ID=(.*)&Name=(.*)&Description=(.*)&GroupType=(.*)$/)
			{
				$flag = 1;
				push (@messages,
				{
					ID => $1,
					Name => $2,
					Description => $3,
					GroupType => $4
				});
			}
		}
	} 
	elsif($string =~ m/Result=Error/)
	{
		$flag = 1;
		$string =~ s/\+/ /g;
		$string =~ m/Message=(.*)$/;
		push (@messages,
				{
					Error => $1
				});
	}
	
	if($flag == 1)
	{
		return @messages;
	}
	else
	{
		$#messages = -1;
		return @messages;
	}
}

# Parse the get contact group response
sub parseGetContactGroupMembersResponse
{
	my $string = shift;
	my @messages;
	my $flag = 0;
	
	if($string =~ m/Result=OK/)
	{
		my @response = split(/\n/, $string);

		for(my $i = 0; $i <= $#response; $i++)
		{
			$response[$i] =~ s/\+/ /g;
			$response[$i] =~ s/%3a/:/g;
			$response[$i] =~ s/%3f/?/g;
			$response[$i] =~ s/%2c/,/g;
			$response[$i] =~ s/%22/\"/g;
			$response[$i] =~ s/%40/@/g;
			$response[$i] =~ s/%2f/\//g;
			$response[$i] =~ s/%3b/;/g;
			$response[$i] =~ s/%2b/\+/g;
			$response[$i] =~ s/%26/&/g;
			$response[$i] =~ s/%25/%/g;
			$response[$i] =~ s/%3d/=/g;
			$response[$i] =~ s/%3c/</g;
			$response[$i] =~ s/%3e/>/g;
			$response[$i] =~ s/%24/\$/g;
			$response[$i] =~ s/%c2%a3/£/g;
			$response[$i] =~ s/%5e/^/g;
			
			# Push every message as a hash onto the array and return it
			if($response[$i] =~ /^ID=(.*)&QuickName=(.*)&FirstName=(.*)&LastName=(.*)&TelephoneNumber=(.*)&MobileNumber=(.*)&StreetAddress1=(.*)&StreetAddress2=(.*)&Town=(.*)&County=(.*)&Postcode=(.*)&Country=(.*)/)
			{
				$flag = 1;
				push (@messages,
				{
					ID => $1,
					QuickName => $2,
					FirstName => $3,
					LastName => $4,
					TelephoneNumber => $5,
					MobileNumber => $6,
					StreetAddress1 => $7,
					StreetAddress2 => $8,
					Town => $9,
					County => $10,
					Postcode => $11,
					Country => $12
				});
			}
		}
	} 
	elsif($string =~ m/Result=Error/)
	{
		$flag = 1;
		$string =~ s/\+/ /g;
		$string =~ m/Message=(.*)$/;
		push (@messages,
				{
					Error => $1
				});
	}
	
	if($flag == 1)
	{
		return @messages;
	}
	else
	{
		$#messages = -1;
		return @messages;
	}
}

# Parse the default response (used in several methods)
sub parseDefaultResponse
{
	my ($string) = @_;
	my $response = undef;
	
	if($string =~ m/Result=OK/)
	{
		$response = 'Success';
	}
	elsif($string =~ m/Result=Error/)
	{
		# Clean and return Message value
		$string =~ s/\+/ /g;
		$string =~ m/Message=(.*)$/;
		$response = "Error : $1";
	}
	else
	{
		$response = $string;
	}
	
	return $response;
}

# Parse the returned response to addContact
sub parseDefaultReturnResponse
{
	my ($string) = @_;
	my $response = undef;
	
	if($string =~ m/Result=OK/)
	{
		# Clean and return GroupID value
		$string =~ s/\+/ /g;
		$string =~ s/%2c/,/g;
		$string =~ m/(GroupID|MessageIDs|MessageStatus|ContactID)=(.*)$/;
		$response = $2;
	}
	elsif($string =~ m/Result=Error/)
	{
		# Clean and return Message value
		$string =~ s/\+/ /g;
		$string =~ m/Message=(.*)$/;
		$response = "Error : $1";
	}
	else
	{
		$response = $string;
	}
	
	return $response;
}

# Required Return True
1;