﻿# EsendexScheduledSendService Class
# Copyright Esendex 2005/2006
# Questions : please contact support@esendex.com http://www.esendex.com/support
package EsendexScheduledSendService;
use FormPostClass;

# Global scalar to reference locations of Scheduled Send Services
$scheduledSendSmsUri = "https://www.esendex.com/secure/messenger/formpost/ScheduledSendSMS.aspx";
$queryStatusUri = "https://www.esendex.com/secure/messenger/formpost/QueryStatus.aspx";

# Class constructor
sub new
{
	my ($class, $username, $password, $account) = @_;
	my $self = 
	{
		username 	=> $username,
		password 	=> $password,
		account		=> $account
	};
	bless ($self, $class);
	return $self;
}

# SendScheduledMessageAt
# Overloaded to handle varying number of arguments
sub sendScheduledMessageAt
{
	my $response = undef;

	# Checks which method to call depending on number of arguments supplied
	if(@_ == 4)
	{
		my ($object, $recipient, $body, $submitAt) = @_;
		my $post = new FormPostClass();
		
		$response = $post -> formPostScheduledMessageAt
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'}, 
			$scheduledSendSmsUri, 
			$recipient,	
			$body,
			$submitAt 
		);
	} elsif(@_ == 7)
	{
		my ($object, $recipient, $originator, $body, $type, $validityPeriod, $submitAt) = @_;
		my $post = new FormPostClass();
		
		$response = $post -> formPostScheduledMessageAt
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'}, 
			$scheduledSendSmsUri, 
			$recipient,	
			$originator, 
			$body, 
			$type, 
			$validityPeriod,
			$submitAt
		);
	} else
	{
		$response = "Error : You have not supplied the correct amount of arguments for this method.";
	};
																	
	return $response;
}

# SendScheduledMessageIn
# Overloaded to handle varying number of arguments
sub sendScheduledMessageIn
{
	my $response = undef;

	# Checks which method to call depending on number of arguments supplied
	if(@_ == 6)
	{
		my ($object, $recipient, $body, $days, $hours, $minutes) = @_;
		my $post = new FormPostClass();
		
		$response = $post -> formPostScheduledMessageIn
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'}, 
			$scheduledSendSmsUri, 
			$recipient,	
			$body,
			$days,
			$hours,
			$minutes 
		);
	} elsif(@_ == 9)
	{
		my ($object, $recipient, $originator, $body, $type, $validityPeriod, $days, $hours, $minutes) = @_;
		my $post = new FormPostClass();
		
		$response = $post -> formPostScheduledMessageIn
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'}, 
			$scheduledSendSmsUri, 
			$recipient,	
			$originator, 
			$body, 
			$type, 
			$validityPeriod,
			$days,
			$hours,
			$minutes 
		);
	} else
	{
		$response = "Error : You have not supplied the correct amount of arguments for this method.";
	};
																	
	return $response;
}


# Get Message Status method
# If MessageID starts 'Error', return the error
sub getMessageStatus
{
	my ($object, $id) = @_;
	my $response = undef;
	
	if($id =~ m/Error/)
	{
		$response = $id;
	} else {
		my $post = new FormPostClass();
		$response = $post -> formPostGetMessageStatus
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'},
			$queryStatusUri,
			$id
		);
	}
	return $response;
}

1;