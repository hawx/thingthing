﻿# Example usage of EsendexSendService Class
# Copyright Esendex 2005
# Questions : please contact support@esendex.com http://www.esendex.com/support
use EsendexSendService;
use strict;

my $username = ''; # your Esendex username, for example joe.blogs@esendex.com
my $password = ''; # your Esendex password, for example joe1234
my $account = ''; # your Esendex account reference, for example EX123456789

my $recipient = ''; # the number of the person receiving the message
my $originator = ''; # the alias the message should appear to come from
my $body = ''; # the content of the message
my $type = ''; # the type of the message i.e. text 
my $validityPeriod = ''; # the validity period of the messge in hours

# Create instance of the EsendexSendService object
my $message = new EsendexSendService($username, $password, $account );

# Send message
my $response = $message -> sendMessage
(	 
	$recipient, 
	$originator, 
	$body, 
	$type, 
	$validityPeriod
);

# Get message status using sendMessage response
print ("Get message status example:\n");
$response = $message -> getMessageStatus($response);
print ("$response\n");