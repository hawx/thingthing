﻿# Example usage of EsendexContactService Class
# Copyright Esendex 2005
# Questions : please contact support@esendex.com http://www.esendex.com/support
use EsendexContactService;
use strict;

my $username = ''; # your Esendex username, for example joe.blogs@esendex.com
my $password = ''; # your Esendex password, for example joe1234
my $account = ''; # your Esendex account reference, for example EX123456789

my $groupID = ''; # the ID of the Contact Group to get. Leave blank to get all groups.

# Create instance of the EsendexContactService object
my $contactObject = new EsendexContactService($username, $password, $account );

# Get group info in array
my @groupDetails = $contactObject -> getContactGroup($groupID);

# 1. if an error was returned (failed authentication) - output error
# 2. if the array is not null (contains contact group info) - output info
if(exists($groupDetails[0]{'Error'}))
{
	print "Error : ".$groupDetails[0]{'Error'}."\n";
}
elsif($#groupDetails != -1)
{
	for(my $i = 0; $i <= $#groupDetails; $i++)
	{
	 	print $groupDetails[$i]{'GroupID'}."\n" if defined($groupDetails[$i]{'GroupID'});
	 	print $groupDetails[$i]{'Name'}."\n" if defined($groupDetails[$i]{'Name'});
	 	print $groupDetails[$i]{'Description'}."\n" if defined($groupDetails[$i]{'Description'});
	 	print $groupDetails[$i]{'GroupType'}."\n" if defined($groupDetails[$i]{'GroupType'});
	}
} 
else 
{
	print "Empty";
}