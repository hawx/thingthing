﻿# Esendex Account Event Handler
# Copyright Esendex 2005 
# Questions : please contact support@esendex.com http://www.esendex.com/support
#
# This code can be used as a base for creating a Form Post Perl Account Event Handler. 
# Place code in the CODE REQUIRED sections to handle the different notifications as 
# required. handleMessageReceived shows some example output code.
use CGI;

$object = new CGI();

# Authenticate username and password if required
#my $username = getFormVariable('username');
#my $password = getFormVariable('password');

my $notificationType = getFormVariable('notificationType');

if($notificationType eq 'MessageReceived')
{
	handleMessageReceived();
} 
elsif($notificationType eq 'MessageEvent')
{
	handleMessageEvent(); 
}
elsif($notificationType eq 'MessageError')
{
 	handleMessageError();
}
elsif($notificationType eq 'SubscriptionError')
{
	handleSubscriptionEvent();
}
else
{
	# CODE REQUIRED Handle unknown notification type
}



# Get form variables
sub getFormVariable
{
	return $object->param(shift);
}

# MessageReceived event
sub handleMessageReceived
{	
	my $inboundMessageID = getFormVariable('id') ;
	my $originator = getFormVariable('originator') ;
	my $recipient = getFormVariable('recipient') ;
	my $body = getFormVariable('body') ;
	my $messageType = getFormVariable('type') ;
	my $receivedAt = getFormVariable('receivedAt') ;

	# CODE REQUIRED	Add code for when a message is received : Below shows some example output
	print $object->header;
	print ("<p><strong>handleMessageReceived</strong></p>");
	print ("$inboundMessageID, $originator, $recipient, $body, $messageType, $receivedAt");

}

# MessageEvent event
sub handleMessageEvent
{
	my $eventMessageID = getFormVariable('id') ;
	my $eventType = getFormVariable('eventType') ;
	my $eventOccurredAt = getFormVariable('occurredAt') ;

	# CODE REQUIRED Add code for when a message event is fired 

}

# MessageError event
sub handleMessageError
{
	my $errorMessageID = getFormVariable('id') ;
	my $errorType = getFormVariable('errorType') ;
	my $errorOccurredAt = getFormVariable('occurredAt') ;
	my $errorDetail = getFormVariable('detail') ;

	# CODE REQUIRED Add code to handle message errors
	 
}

# Subscription event
sub handleSubscriptionEvent
{
	my $mobileNumber = getFormVariable('mobileNumber') ;
	my $contactID = getFormVariable('contactID') ;
	my $subcriptionEventOccurredAt = getFormVariable('occurredAt') ;
	my $eventType = getFormVariable('eventType') ;

	# CODE REQUIRED Add code to handle premium rate subscription events (Only needed for premium rate accounts)
	
}