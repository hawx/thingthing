﻿# Example usage of EsendexContactService Class
# Copyright Esendex 2005
# Questions : please contact support@esendex.com http://www.esendex.com/support
use EsendexContactService;
use strict;

my $username = ''; # your Esendex username, for example joe.blogs@esendex.com
my $password = ''; # your Esendex password, for example joe1234
my $account = ''; # your Esendex account reference, for example EX123456789

my $groupID = ''; # the ID of the contact group. To delete mutiple groups separate each ID with a comma
my $includeMembers = ''; # if it contains value group members will also be deleted


# Create instance of the EsendexContactService object
my $contactObject = new EsendexContactService($username, $password, $account );

# delete contact group example
print ("Delete contact group example:\n");
my $response = $contactObject -> deleteContactGroup
(	
	$groupID,
	$includeMembers
);

# Print the response of deleteContactGroup method
print ("$response\n");
