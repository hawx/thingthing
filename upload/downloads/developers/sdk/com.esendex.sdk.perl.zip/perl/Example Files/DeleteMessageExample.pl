﻿# Example usage of EsendexReceiveService Class
# Copyright Esendex 2005
# Questions : please contact support@esendex.com http://www.esendex.com/support
use EsendexReceiveService;
use strict;

my $username = ''; # your Esendex username, for example joe.blogs@esendex.com
my $password = ''; # your Esendex password, for example joe1234
my $account = ''; # your Esendex account reference, for example EX123456789

my $messageID = '' # the ID of the message you want to delete

# Create instance of the EsendexReceiveService object
my $response = new EsendexReceiveService($username, $password, $account);

# Delete message example
my $example = $response -> deleteMessage($messageID);
print "$example\n";