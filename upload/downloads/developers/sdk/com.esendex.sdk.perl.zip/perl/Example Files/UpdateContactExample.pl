﻿# Example usage of EsendexContactService Class
# Copyright Esendex 2005
# Questions : please contact support@esendex.com http://www.esendex.com/support
use EsendexContactService;
use strict;

my $username = ''; # your Esendex username, for example joe.blogs@esendex.com
my $password = ''; # your Esendex password, for example joe1234
my $account = ''; # your Esendex account reference, for example EX123456789

my $contactID = ''; # the ID of the contact to update, if blank it will be created
my $quickName = ''; # the number of the person receiving the message
my $firstName = ''; # the first name of the contact being updated
my $lastName = ''; # the last name of the contact being updated
my $telephoneNumber = ''; # the telephone number of the contact being updated
my $mobileNumber = ''; # the mobile number of the contact being updated
my $streetAddress1 = ''; # the street address of the contact being updated
my $streetAddress2 = ''; # the street2 address of the contact being updated
my $town = ''; # the town address of the contact being updated
my $county = ''; # the county address of the contact being updated
my $postCode = ''; # the post code of the contact being updated
my $country = ''; # the country of the contact being updated

# Create instance of the EsendexContactService object
my $contactObject = new EsendexContactService($username, $password, $account );

# Update contact example
print ("Update contact example:\n");
my $response = $contactObject -> updateContact
(	
	$contactID,
	$quickName,
	$mobileNumber
);

# Print the response of updateContact method
print ("$response\n");