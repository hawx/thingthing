﻿# Example usage of EsendexContactService Class
# Copyright Esendex 2005
# Questions : please contact support@esendex.com http://www.esendex.com/support
use EsendexContactService;
use strict;

my $username = ''; # your Esendex username, for example joe.blogs@esendex.com
my $password = ''; # your Esendex password, for example joe1234
my $account = ''; # your Esendex account reference, for example EX123456789

my $contactID = ''; # the ID of the contact to delete

# Create instance of the EsendexContactService object
my $contactObject = new EsendexContactService($username, $password, $account );

# delete contact example
print ("Delete contact example:\n");
my $response = $contactObject -> deleteContact
(	
	$contactID
);

# Print the response of deleteContact method
print ("$response\n");