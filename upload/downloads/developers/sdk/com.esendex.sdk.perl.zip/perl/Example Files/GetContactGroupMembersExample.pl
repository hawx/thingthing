﻿# Example usage of EsendexContactService Class
# Copyright Esendex 2005
# Questions : please contact support@esendex.com http://www.esendex.com/support
use EsendexContactService;
use strict;

my $username = ''; # your Esendex username, for example joe.blogs@esendex.com
my $password = ''; # your Esendex password, for example joe1234
my $account = ''; # your Esendex account reference, for example EX123456789

my $groupID = ''; # the ID of the group

# Create instance of the EsendexContactService object
my $contactObject = new EsendexContactService($username, $password, $account );

# Get group members info in hash
my @groupDetails = $contactObject -> getContactGroupMembers($groupID);

# 1. if an error was returned (failed authentication) - output error
# 2. if the array is not null (contains contact group info) - output info
if(exists($groupDetails[0]{'Error'}))
{
	print "Error : ".$groupDetails[0]{'Error'}."\n";
}
elsif($#groupDetails != -1)
{
	for(my $i = 0; $i <= $#groupDetails; $i++)
	{
	 	print $groupDetails[$i]{'ID'}."\n" if defined($groupDetails[$i]{'ID'});
	 	print $groupDetails[$i]{'QuickName'}."\n" if defined($groupDetails[$i]{'QuickName'});
	 	print $groupDetails[$i]{'FirstName'}."\n" if defined($groupDetails[$i]{'FirstName'});
	 	print $groupDetails[$i]{'LastName'}."\n" if defined($groupDetails[$i]{'LastName'});
	 	print $groupDetails[$i]{'TelephoneNumber'}."\n" if defined($groupDetails[$i]{'TelephoneNumber'});
	 	print $groupDetails[$i]{'MobileNumber'}."\n" if defined($groupDetails[$i]{'MobileNumber'});
	 	print $groupDetails[$i]{'StreetAddress1'}."\n" if defined($groupDetails[$i]{'StreetAddress1'});
	 	print $groupDetails[$i]{'StreetAddress2'}."\n" if defined($groupDetails[$i]{'StreetAddress2'});
	 	print $groupDetails[$i]{'Town'}."\n" if defined($groupDetails[$i]{'Town'});
	 	print $groupDetails[$i]{'County'}."\n" if defined($groupDetails[$i]{'County'});
	 	print $groupDetails[$i]{'Postcode'}."\n" if defined($groupDetails[$i]{'Postcode'});
	 	print $groupDetails[$i]{'Country'}."\n" if defined($groupDetails[$i]{'Country'});
	}
} 
else 
{
	print "Empty";
}