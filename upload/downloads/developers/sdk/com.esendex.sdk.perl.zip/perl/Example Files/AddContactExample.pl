﻿# Example usage of EsendexContactService Class
# Copyright Esendex 2005
# Questions : please contact support@esendex.com http://www.esendex.com/support
use EsendexContactService;
use strict;

my $username = ''; # your Esendex username, for example joe.blogs@esendex.com
my $password = ''; # your Esendex password, for example joe1234
my $account = ''; # your Esendex account reference, for example EX123456789

my $contactID = ''; # the ID of the contact to add
my $quickName = ''; # the number of the person receiving the message
my $firstName = ''; # the first name of the contact being added
my $lastName = ''; # the last name of the contact being added
my $telephoneNumber = ''; # the telephone number of the contact being added
my $mobileNumber = ''; # the mobile number of the contact being added
my $streetAddress1 = ''; # the street address of the contact being added
my $streetAddress2 = ''; # the street2 address of the contact being added
my $town = ''; # the town address of the contact being added
my $county = ''; # the county address of the contact being added
my $postCode = ''; # the post code of the contact being added
my $country = ''; # the country of the contact being added

# Create instance of the EsendexContactService object
my $contactObject = new EsendexContactService($username, $password, $account );

# Add contact example
print ("Add contact example:\n");
my $response = $contactObject -> addContact
(	
	$contactID,
	$quickName,
	$firstName,
	$lastName,
	$telephoneNumber, 
	$mobileNumber,
	$streetAddress1,
	$streetAddress2,
	$town,
	$county,
	$postCode,
	$country
);

# Print the response of addContact method
print ("$response\n");