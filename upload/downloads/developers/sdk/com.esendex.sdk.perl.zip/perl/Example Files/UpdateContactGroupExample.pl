﻿# Example usage of EsendexContactService Class
# Copyright Esendex 2005
# Questions : please contact support@esendex.com http://www.esendex.com/support
use EsendexContactService;
use strict;

my $username = ''; # your Esendex username, for example joe.blogs@esendex.com
my $password = ''; # your Esendex password, for example joe1234
my $account = ''; # your Esendex account reference, for example EX123456789

my $groupID = ''; # the ID of the contact group to update
my $name = ''; # a unique name for the contact group in your account
my $description = ''; # a description for the group
my $memberIDs = ''; # a comma separated collection of contact IDs to assign to the group


# Create instance of the EsendexContactService object
my $contactObject = new EsendexContactService($username, $password, $account );

# Update contact group example
print ("Update contact group example:\n");
my $response = $contactObject -> updateContactGroup
(	
	$groupID,
	$name
);

# Print the response of updateContactGroup method
print ("$response\n");