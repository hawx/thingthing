﻿# Example usage of EsendexReceiveService Class
# Copyright Esendex 2005
# Questions : please contact support@esendex.com http://www.esendex.com/support
use EsendexReceiveService;
use strict;

my $username = ''; # your Esendex username, for example joe.blogs@esendex.com
my $password = ''; # your Esendex password, for example joe1234
my $account = ''; # your Esendex account reference, for example EX123456789

# Create instance of the EsendexReceiveService object
my $response = new EsendexReceiveService($username, $password, $account);

# Get inbox messages in array of hashes
my @messages = $response -> getInbox();

# 1. if an error was returned (failed authentication) - output error
# 2. if the array is not null (contains messages) - output messages
# 3. if a null array was returned (empty inbox) - output "Inbox empty" 
if(exists($messages[0]{'Error'}))
{
	print "Error : ".$messages[0]{'Error'}."\n";
}
elsif($#messages != -1)
{
	for(my $i = 0; $i <= $#messages; $i++)
	{
	 print $messages[$i]{'messageID'}."\n" if defined($messages[$i]{'messageID'});
	 print $messages[$i]{'originator'}."\n" if defined($messages[$i]{'originator'});
	 print $messages[$i]{'body'}."\n" if defined($messages[$i]{'body'});
	 print $messages[$i]{'receivedAt'}."\n" if defined($messages[$i]{'receivedAt'});
	 print $messages[$i]{'recipient'}."\n" if defined($messages[$i]{'recipient'});
	 print $messages[$i]{'type'}."\n" if defined($messages[$i]{'type'});
	 print $messages[$i]{'indexID'}."\n" if defined($messages[$i]{'indexID'});
	}
} 
else 
{
	print "Inbox Empty";
}
