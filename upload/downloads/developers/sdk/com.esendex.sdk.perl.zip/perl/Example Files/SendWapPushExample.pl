# Example usage of EsendexSendService Class
# Copyright Esendex 2005
# Questions : please contact support@esendex.com http://www.esendex.com/support
use EsendexSendService;
use strict;

my $username = ''; # your Esendex username, for example joe.blogs@esendex.com
my $password = ''; # your Esendex password, for example joe1234
my $account = ''; # your Esendex account reference, for example EX123456789

my $recipient = ''; # the number of the person receiving the message
my $body = ''; # the content of the message
my $validityPeriod = ''; # the validity period of the messge in hours

my $href = ''; # the URL of the content being pushed

# Create instance of the EsendexSendService object
my $message = new EsendexSendService($username, $password, $account );

# Send WAP message example
print ("Send WAP message test:\n");
my $response = $message -> sendWapPushMessage
(	 
	$recipient,
	$href,
	$body,  
	$validityPeriod
);
print $response;
