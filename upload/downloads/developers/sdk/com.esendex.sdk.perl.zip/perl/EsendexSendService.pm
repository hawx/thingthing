# EsendexSendService Class
# Copyright Esendex 2005/2006
# Questions : please contact support@esendex.com http://www.esendex.com/support
package EsendexSendService;
use FormPostClass;

# Global scalar to reference locations of Send Services
$sendSmsUri = "https://www.esendex.com/secure/messenger/formpost/SendSMS.aspx";
$sendWapUri = "https://www.esendex.com/secure/messenger/formpost/SendWAPPushSMS.aspx";
$queryStatusUri = "https://www.esendex.com/secure/messenger/formpost/QueryStatus.aspx";

# Class constructor
sub new
{
	my ($class, $username, $password, $account) = @_;
	my $self = 
	{
		username 	=> $username,
		password 	=> $password,
		account		=> $account
	};
	bless ($self, $class);
	return $self;
}

# Send Message method
# Overloaded to handle varying number of arguments
sub sendMessage
{
	my $response = undef;

	# Checks which method to call depending on number of arguments supplied
	if(@_ == 3)
	{
		my ($object, $recipient, $body) = @_;
		my $post = new FormPostClass();
		
		$response = $post -> formPostMessage
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'}, 
			$sendSmsUri, 
			$recipient,	
			$body, 
		);
	} elsif(@_ == 6)
	{
		my ($object, $recipient, $originator, $body, $type, $validityPeriod) = @_;
		my $post = new FormPostClass();
		
		$response = $post -> formPostMessage
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'}, 
			$sendSmsUri, 
			$recipient,	
			$originator, 
			$body, 
			$type, 
			$validityPeriod
		);
	} else
	{
		$response = "Error : You have not supplied the correct amount of arguments for this method.";
	};
																	
	return $response;
}

# Send Wap Push Message Method
# Overloaded to handle varying number of arguments
sub sendWapPushMessage
{
	my $response = undef;
	
	# Checks which method to call depending on number of arguments supplied
	if(@_ == 4)
	{
		my ($object, $recipient, $href, $text) = @_;
		my $post = new FormPostClass();
		
		$response = $post -> formPostWapMessage
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'}, 
			$sendWapUri, 
			$recipient,	
			$href, 
			$text
		);
	} elsif(@_ == 5)
	{
		my ($object, $recipient, $href, $text, $validityPeriod) = @_;
		my $post = new FormPostClass();
		
		$response = $post -> formPostWapMessage
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'}, 
			$sendWapUri, 
			$recipient,	
			$href, 
			$text,  
			$validityPeriod
		);
	} else
	{
		$response = "Error : You have not supplied the correct amount of arguments for this method.";
	}													
	return $response;
}

# Get Message Status method
# If MessageID starts 'Error', return the error
sub getMessageStatus
{
	my ($object, $id) = @_;
	my $response = undef;
	
	if($id =~ m/Error/)
	{
		$response = $id;
	} else {
		my $post = new FormPostClass();
		$response = $post -> formPostGetMessageStatus
		(
			$object->{'username'}, 
			$object->{'password'}, 
			$object->{'account'},
			$queryStatusUri,
			$id
		);
	}
	return $response;
}

1;