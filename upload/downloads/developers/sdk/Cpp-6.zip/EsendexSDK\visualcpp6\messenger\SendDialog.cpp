// SendDialog.cpp : implementation file
// Esendex: Dialog box that enables a user to send an SMS message.

#include "stdafx.h"
#include "EsendexMessenger.h"
#include "SendDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSendDialog dialog


CSendDialog::CSendDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CSendDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSendDialog)
	m_strMessage = _T("");
	m_strRecipient = _T("");
	//}}AFX_DATA_INIT
}


void CSendDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSendDialog)
	DDX_Text(pDX, IDC_MESSAGE, m_strMessage);
	DDX_Text(pDX, IDC_RECIPIENT, m_strRecipient);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSendDialog, CDialog)
	//{{AFX_MSG_MAP(CSendDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSendDialog message handlers

void CSendDialog::OnOK() 
{
	try
	{
		//Esendex: Retrieve the latest values from the dialog box controls.
		UpdateData(TRUE);

		//Esendex: Initialise the SendService component.
		EsendexLib::ISendService2Ptr spSendService;
		spSendService.CreateInstance(__uuidof(EsendexLib::SendService2));
		CEsendexMessengerApp* pApp = (CEsendexMessengerApp*)AfxGetApp();
		spSendService->Initialise((LPCTSTR)pApp->m_strUsername, (LPCTSTR)pApp->m_strPassword, (LPCTSTR)pApp->m_strAccount);

		//Esendex: Send the message.
		spSendService->SendMessage((LPCTSTR)m_strRecipient, (LPCTSTR)m_strMessage, EsendexLib::MESSAGE_TYPE_TEXT);
		
		//Esendex: Notify the user that the message was sent.
		AfxMessageBox("Message sent", MB_OK|MB_ICONINFORMATION);

		//Esendex: Close the dialog box.
		CDialog::OnOK();
	}
	catch(_com_error& ex)
	{
		//Esendex: The COM component may throw an _com_error, which we catch here and report to the user.
		CString strMessage;
		strMessage.Format("There was a problem sending the message\n\n%s", (TCHAR*)ex.Description());
		AfxMessageBox(strMessage, MB_OK|MB_ICONERROR);
	}
}

void CSendDialog::OnCancel() 
{
	CDialog::OnCancel();
}
