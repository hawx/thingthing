// InboxDlg.h : header file
// Esendex: Dialog box that displays the contents of an Esendex user's inbox.

#if !defined(AFX_INBOXDLG_H__5DC55B55_C6AB_4596_8EAD_B78751FBABA4__INCLUDED_)
#define AFX_INBOXDLG_H__5DC55B55_C6AB_4596_8EAD_B78751FBABA4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CInboxDlg dialog

class CInboxDlg : public CDialog
{
// Construction
public:
	CInboxDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CInboxDlg)
	enum { IDD = IDD_INBOX_DIALOG };
	CListCtrl	m_wndList;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInboxDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CInboxDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDelete();
	afx_msg void OnSend();
	afx_msg void OnRefresh();
	afx_msg void OnSendFull();
	afx_msg void OnAccount();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void PopulateList();

	EsendexLib::IObjectCollectionPtr m_spMessages;
	EsendexLib::IInboxService2Ptr m_spInbox;
	void InitialiseInboxService();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INBOXDLG_H__5DC55B55_C6AB_4596_8EAD_B78751FBABA4__INCLUDED_)
