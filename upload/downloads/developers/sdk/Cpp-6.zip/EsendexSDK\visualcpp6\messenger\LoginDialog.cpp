// LoginDialog.cpp : implementation file
// Esendex: Dialog box that enables a user to enter their Esendex account information.

#include "stdafx.h"
#include "EsendexMessenger.h"
#include "LoginDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLoginDialog dialog


CLoginDialog::CLoginDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CLoginDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLoginDialog)
	m_strAccount = _T("");
	m_strUsername = _T("");
	m_strPassword = _T("");
	//}}AFX_DATA_INIT
}


void CLoginDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLoginDialog)
	DDX_Text(pDX, IDC_ACCOUNT, m_strAccount);
	DDX_Text(pDX, IDC_PASSWORD, m_strPassword);
	DDX_Text(pDX, IDC_USERNAME, m_strUsername);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLoginDialog, CDialog)
	//{{AFX_MSG_MAP(CLoginDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLoginDialog message handlers

//Esendex: Store the users login details in the CInboxApplication class.
void CLoginDialog::OnOK() 
{
	UpdateData(TRUE);
	CEsendexMessengerApp* pApp = (CEsendexMessengerApp*)AfxGetApp();
	pApp->m_strUsername = m_strUsername;
	pApp->m_strPassword = m_strPassword;
	pApp->m_strAccount = m_strAccount;
	CDialog::OnOK();
}
